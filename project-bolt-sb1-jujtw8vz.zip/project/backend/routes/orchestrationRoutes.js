const express = require('express');
const router = express.Router();
const { orchestrationController } = require('../controllers');

// Execute API endpoint by slug - This is the main runtime endpoint
router.all('/execute/:projectSlug/:apiSlug', orchestrationController.executeApiEndpointBySlug);

// Get API documentation by slug
router.get('/docs/:projectSlug/:apiSlug', orchestrationController.getApiDocumentationBySlug);

// List all executable APIs for a project by slug
router.get('/apis/:projectSlug', orchestrationController.listProjectApisBySlug);

module.exports = router;