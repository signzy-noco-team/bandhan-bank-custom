const express = require('express');
const router = express.Router();
const { apiStatsController } = require('../controllers');

// Get API statistics with filtering
router.get('/', apiStatsController.getApiStats);

// Get dashboard statistics
router.get('/dashboard', apiStatsController.getDashboardStats);

// Get API performance trends
router.get('/trends', apiStatsController.getApiPerformanceTrends);

// Get top performing APIs
router.get('/top-apis', apiStatsController.getTopPerformingApis);

// Get error analysis
router.get('/errors', apiStatsController.getErrorAnalysis);

// Record API execution for statistics
router.post('/record', apiStatsController.recordApiExecution);

module.exports = router;