const express = require('express');
const router = express.Router();
const { apiExecutionController } = require('../controllers');

// Get all API executions with filtering
router.get('/', apiExecutionController.getAllApiExecutions);

// Get execution statistics
router.get('/stats', apiExecutionController.getExecutionStats);

// Get recent executions
router.get('/recent', apiExecutionController.getRecentExecutions);

// Get executions for specific API endpoint
router.get('/api-endpoint/:apiEndpointId', apiExecutionController.getExecutionsByApiEndpoint);

// Get API execution by execution ID (unique identifier)
router.get('/execution/:executionId', apiExecutionController.getApiExecutionByExecutionId);

// Get API execution by database ID
router.get('/:id', apiExecutionController.getApiExecutionById);

// Create new API execution
router.post('/', apiExecutionController.createApiExecution);

// Update API execution
router.put('/:id', apiExecutionController.updateApiExecution);

// Delete API execution
router.delete('/:id', apiExecutionController.deleteApiExecution);

module.exports = router;