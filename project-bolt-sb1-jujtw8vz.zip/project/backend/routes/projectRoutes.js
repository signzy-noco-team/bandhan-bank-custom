const express = require('express');
const router = express.Router();
const { projectController } = require('../controllers');

// Get all projects
router.get('/', projectController.getAllProjects);

// Get project by ID
router.get('/:id', projectController.getProjectById);

// Create new project
router.post('/', projectController.createProject);

// Update project
router.put('/:id', projectController.updateProject);

// Delete project
router.delete('/:id', projectController.deleteProject);

// Get project statistics
router.get('/:id/stats', projectController.getProjectStats);

// Check project slug availability
router.get('/check-slug/:slug', projectController.checkSlugAvailability);

// Get project by slug
router.get('/slug/:slug', projectController.getProjectBySlug);
module.exports = router;