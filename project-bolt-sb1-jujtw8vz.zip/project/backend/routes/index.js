const express = require('express');
const router = express.Router();

// Import route modules
const projectRoutes = require('./projectRoutes');
const apiEndpointRoutes = require('./apiEndpointRoutes');
const apiExecutionRoutes = require('./apiExecutionRoutes');
const queueRoutes = require('./queueRoutes');
const apiStatsRoutes = require('./apiStatsRoutes');
const orchestrationRoutes = require('./orchestrationRoutes');

// API version prefix
const API_VERSION = '/api/v1';

// Mount routes
router.use(`${API_VERSION}/projects`, projectRoutes);
router.use(`${API_VERSION}/api-endpoints`, apiEndpointRoutes);
router.use(`${API_VERSION}/api-executions`, apiExecutionRoutes);
router.use(`${API_VERSION}/queue`, queueRoutes);
router.use(`${API_VERSION}/stats`, apiStatsRoutes);

// Runtime orchestration routes (no version prefix for clean URLs)
router.use('/', orchestrationRoutes);

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'API Orchestrator Backend is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API documentation endpoint
router.get(`${API_VERSION}/docs`, (req, res) => {
  res.json({
    title: 'API Orchestrator Backend',
    version: '1.0.0',
    description: 'Backend API for API Orchestration System',
    endpoints: {
      projects: {
        base: `${API_VERSION}/projects`,
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        description: 'Manage API orchestration projects'
      },
      apiEndpoints: {
        base: `${API_VERSION}/api-endpoints`,
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        description: 'Manage API endpoints and upstream configurations'
      },
      apiExecutions: {
        base: `${API_VERSION}/api-executions`,
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        description: 'Manage API execution history and tracking'
      },
      queue: {
        base: `${API_VERSION}/queue`,
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        description: 'Manage queue jobs and processing'
      },
      stats: {
        base: `${API_VERSION}/stats`,
        methods: ['GET', 'POST'],
        description: 'API performance statistics and analytics'
      }
    }
  });
});

// 404 handler for API routes
router.use(`${API_VERSION}/*`, (req, res) => {
  res.status(404).json({
    error: 'API endpoint not found',
    message: `The requested endpoint ${req.originalUrl} does not exist`,
    availableEndpoints: [
      `${API_VERSION}/projects`,
      `${API_VERSION}/api-endpoints`,
      `${API_VERSION}/api-executions`,
      `${API_VERSION}/queue`,
      `${API_VERSION}/stats`
    ]
  });
});

module.exports = router;