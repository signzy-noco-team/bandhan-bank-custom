const express = require('express');
const router = express.Router();
const { queueController } = require('../controllers');

// Get all queue jobs with filtering
router.get('/jobs', queueController.getAllQueueJobs);

// Get queue statistics
router.get('/stats', queueController.getQueueStats);

// Get next jobs to process
router.get('/next', queueController.getNextJobsToProcess);

// Get queue job by ID
router.get('/jobs/:id', queueController.getQueueJobById);

// Create new queue job
router.post('/jobs', queueController.createQueueJob);

// Update queue job status
router.put('/jobs/:id/status', queueController.updateQueueJobStatus);

// Retry failed queue job
router.post('/jobs/:id/retry', queueController.retryQueueJob);

// Delete queue job
router.delete('/jobs/:id', queueController.deleteQueueJob);

module.exports = router;