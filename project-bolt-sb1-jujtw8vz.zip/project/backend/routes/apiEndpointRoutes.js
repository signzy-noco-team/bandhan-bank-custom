const express = require('express');
const router = express.Router();
const { apiEndpointController } = require('../controllers');

// Get all API endpoints for a project
router.get('/project/:projectId', apiEndpointController.getApiEndpointsByProject);

// Get available upstream APIs for a project
router.get('/project/:projectId/available', apiEndpointController.getAvailableUpstreamApis);

// Get API endpoint by ID
router.get('/:id', apiEndpointController.getApiEndpointById);

// Create new API endpoint
router.post('/', apiEndpointController.createApiEndpoint);

// Update API endpoint
router.put('/:id', apiEndpointController.updateApiEndpoint);

// Delete API endpoint
router.delete('/:id', apiEndpointController.deleteApiEndpoint);

// Get API execution history
router.get('/:id/executions', apiEndpointController.getApiExecutionHistory);

// Test API endpoint
router.post('/:id/test', apiEndpointController.testApiEndpoint);

// Check API slug availability within project
router.get('/project/:projectId/check-slug/:slug', apiEndpointController.checkSlugAvailability);
module.exports = router;