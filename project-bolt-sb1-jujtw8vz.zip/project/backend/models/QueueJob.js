const mongoose = require('mongoose');

const queueJobSchema = new mongoose.Schema({
  queueName: {
    type: String,
    required: true,
    index: true
  },
  jobType: {
    type: String,
    required: true,
    enum: ['API_CALL', 'TRANSFORM', 'STORE_DATA', 'NOTIFICATION']
  },
  apiEndpointId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ApiEndpoint'
  },
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  priority: {
    type: Number,
    default: 1,
    min: 1,
    max: 10
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'retrying', 'cancelled'],
    default: 'pending',
    index: true
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  result: mongoose.Schema.Types.Mixed,
  error: {
    message: String,
    stack: String,
    code: String
  },
  attempts: {
    type: Number,
    default: 0
  },
  maxAttempts: {
    type: Number,
    default: 3
  },
  delay: {
    type: Number,
    default: 0
  },
  scheduledAt: {
    type: Date,
    default: Date.now
  },
  startedAt: Date,
  completedAt: Date,
  processingTime: Number,
  retryDelays: [{
    attempt: Number,
    delay: Number,
    scheduledAt: Date
  }],
  metadata: {
    executionId: String,
    parentJobId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'QueueJob'
    },
    tags: [String]
  }
}, {
  timestamps: true
});

// Compound indexes for efficient querying
queueJobSchema.index({ queueName: 1, status: 1, priority: -1, scheduledAt: 1 });
queueJobSchema.index({ projectId: 1, status: 1, createdAt: -1 });
queueJobSchema.index({ apiEndpointId: 1, status: 1 });
queueJobSchema.index({ status: 1, scheduledAt: 1 });

// Virtual for next retry time
queueJobSchema.virtual('nextRetryAt').get(function() {
  if (this.status === 'failed' && this.attempts < this.maxAttempts) {
    const baseDelay = this.delay || 1000;
    const exponentialDelay = baseDelay * Math.pow(2, this.attempts);
    return new Date(Date.now() + exponentialDelay);
  }
  return null;
});

// Virtual for processing duration
queueJobSchema.virtual('duration').get(function() {
  if (this.startedAt && this.completedAt) {
    return this.completedAt.getTime() - this.startedAt.getTime();
  }
  return null;
});

queueJobSchema.set('toJSON', { virtuals: true });
queueJobSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('QueueJob', queueJobSchema);