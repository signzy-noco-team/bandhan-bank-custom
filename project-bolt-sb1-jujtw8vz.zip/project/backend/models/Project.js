const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
    maxlength: 50,
    validate: {
      validator: function(v) {
        return /^[a-z0-9-]+$/.test(v);
      },
      message: 'Slug can only contain lowercase letters, numbers, and hyphens'
    }
  },
  description: {
    type: String,
    trim: true,
    maxlength: 500
  },
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  },
  globalVariables: [{
    name: {
      type: String,
      required: true
    },
    value: {
      type: String,
      required: true
    },
    type: {
      type: String,
      enum: ['string', 'number', 'boolean', 'json'],
      default: 'string'
    },
    description: String,
    encrypted: {
      type: Boolean,
      default: false
    }
  }],
  databaseConnections: [{
    name: {
      type: String,
      required: true
    },
    type: {
      type: String,
      enum: ['mongodb', 'postgresql', 'mysql', 'redis'],
      required: true
    },
    connectionString: {
      type: String,
      required: true
    },
    database: String,
    encrypted: {
      type: Boolean,
      default: true
    }
  }],
  defaultSettings: {
    timeout: {
      type: Number,
      default: 5000
    },
    retries: {
      type: Number,
      default: 3
    },
    enableLogging: {
      type: Boolean,
      default: true
    },
    logLevel: {
      type: String,
      enum: ['debug', 'info', 'warn', 'error'],
      default: 'info'
    }
  },
  rateLimiting: {
    enabled: {
      type: Boolean,
      default: false
    },
    requestsPerMinute: {
      type: Number,
      default: 60
    }
  },
  authentication: {
    enabled: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      enum: ['apikey', 'jwt', 'oauth'],
      default: 'apikey'
    },
    config: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    }
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Virtual for API count
projectSchema.virtual('apiCount', {
  ref: 'ApiEndpoint',
  localField: '_id',
  foreignField: 'projectId',
  count: true
});

// Ensure virtual fields are serialized
projectSchema.set('toJSON', { virtuals: true });
projectSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Project', projectSchema);