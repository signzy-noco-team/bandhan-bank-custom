const mongoose = require('mongoose');

const upstreamApiCallSchema = new mongoose.Schema({
  apiEndpointId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ApiEndpoint',
    required: true
  },
  condition: {
    type: String,
    default: ''
  },
  nextSteps: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ApiEndpoint'
  }],
  order: {
    type: Number,
    default: 0
  },
  customHeaders: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  customBody: String,
  customTimeout: Number,
  customRetries: Number
});

const ruleSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  condition: {
    type: String,
    required: true
  },
  action: {
    type: String,
    enum: ['continue', 'stop', 'redirect', 'transform'],
    required: true
  },
  parameters: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  order: {
    type: Number,
    default: 0
  }
});

const transformationSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['xml-to-json', 'text-to-json', 'json-to-xml', 'custom'],
    required: true
  },
  configuration: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  order: {
    type: Number,
    default: 0
  }
});

const storageFieldSchema = new mongoose.Schema({
  sourceField: {
    type: String,
    required: true
  },
  targetField: {
    type: String,
    required: true
  },
  transform: String
});

const storageConfigSchema = new mongoose.Schema({
  enabled: {
    type: Boolean,
    default: false
  },
  database: String,
  collection: String,
  fields: [storageFieldSchema],
  condition: String
});

const queueConfigSchema = new mongoose.Schema({
  enabled: {
    type: Boolean,
    default: false
  },
  queueName: String,
  priority: {
    type: Number,
    default: 1
  },
  delay: {
    type: Number,
    default: 0
  }
});

const apiEndpointSchema = new mongoose.Schema({
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100
  },
  slug: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    maxlength: 50,
    validate: {
      validator: function(v) {
        return /^[a-z0-9-]+$/.test(v);
      },
      message: 'Slug can only contain lowercase letters, numbers, and hyphens'
    }
  },
  path: {
    type: String,
    required: true,
    validate: {
      validator: function(v) {
        return v.startsWith('/');
      },
      message: 'Path must start with /'
    }
  },
  method: {
    type: String,
    enum: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    required: true
  },
  description: {
    type: String,
    trim: true,
    maxlength: 500
  },
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  },
  configuration: {
    upstreamApis: [upstreamApiCallSchema],
    rules: [ruleSchema],
    transformations: [transformationSchema],
    storage: storageConfigSchema,
    queueConfig: queueConfigSchema
  },
  variables: [{
    name: {
      type: String,
      required: true
    },
    value: {
      type: String,
      required: true
    },
    type: {
      type: String,
      enum: ['string', 'number', 'boolean', 'json'],
      default: 'string'
    },
    description: String,
    encrypted: {
      type: Boolean,
      default: false
    }
  }],
  headers: [{
    key: {
      type: String,
      required: true
    },
    value: {
      type: String,
      required: true
    },
    description: String
  }],
  requestBody: String,
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Index for better query performance
apiEndpointSchema.index({ projectId: 1, status: 1 });
apiEndpointSchema.index({ path: 1, method: 1 });
apiEndpointSchema.index({ projectId: 1, slug: 1 }, { unique: true });

module.exports = mongoose.model('ApiEndpoint', apiEndpointSchema);