const mongoose = require('mongoose');

const apiStatsSchema = new mongoose.Schema({
  apiEndpointId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ApiEndpoint',
    required: true
  },
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  period: {
    type: String,
    enum: ['hour', 'day', 'week', 'month'],
    required: true
  },
  metrics: {
    totalCalls: {
      type: Number,
      default: 0
    },
    successfulCalls: {
      type: Number,
      default: 0
    },
    failedCalls: {
      type: Number,
      default: 0
    },
    averageResponseTime: {
      type: Number,
      default: 0
    },
    minResponseTime: {
      type: Number,
      default: 0
    },
    maxResponseTime: {
      type: Number,
      default: 0
    },
    totalResponseTime: {
      type: Number,
      default: 0
    },
    upstreamCallsCount: {
      type: Number,
      default: 0
    },
    transformationsCount: {
      type: Number,
      default: 0
    },
    storageOperationsCount: {
      type: Number,
      default: 0
    },
    queueJobsCount: {
      type: Number,
      default: 0
    }
  },
  statusCodes: {
    '200': { type: Number, default: 0 },
    '201': { type: Number, default: 0 },
    '400': { type: Number, default: 0 },
    '401': { type: Number, default: 0 },
    '403': { type: Number, default: 0 },
    '404': { type: Number, default: 0 },
    '500': { type: Number, default: 0 },
    'others': { type: Number, default: 0 }
  },
  errorTypes: [{
    type: String,
    count: Number,
    lastOccurrence: Date
  }],
  upstreamApiStats: [{
    apiName: String,
    totalCalls: Number,
    successfulCalls: Number,
    failedCalls: Number,
    averageResponseTime: Number
  }]
}, {
  timestamps: true
});

// Compound indexes for efficient querying
apiStatsSchema.index({ apiEndpointId: 1, period: 1, date: -1 });
apiStatsSchema.index({ projectId: 1, period: 1, date: -1 });
apiStatsSchema.index({ date: -1, period: 1 });

// Virtual for success rate
apiStatsSchema.virtual('successRate').get(function() {
  if (this.metrics.totalCalls === 0) return 0;
  return (this.metrics.successfulCalls / this.metrics.totalCalls) * 100;
});

// Virtual for error rate
apiStatsSchema.virtual('errorRate').get(function() {
  if (this.metrics.totalCalls === 0) return 0;
  return (this.metrics.failedCalls / this.metrics.totalCalls) * 100;
});

apiStatsSchema.set('toJSON', { virtuals: true });
apiStatsSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('ApiStats', apiStatsSchema);