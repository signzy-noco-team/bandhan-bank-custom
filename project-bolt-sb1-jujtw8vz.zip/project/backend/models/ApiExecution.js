const mongoose = require('mongoose');

const upstreamCallSchema = new mongoose.Schema({
  apiId: String,
  name: String,
  url: String,
  method: String,
  requestHeaders: mongoose.Schema.Types.Mixed,
  requestBody: mongoose.Schema.Types.Mixed,
  responseStatus: Number,
  responseHeaders: mongoose.Schema.Types.Mixed,
  responseBody: mongoose.Schema.Types.Mixed,
  responseTime: Number,
  success: Boolean,
  error: String,
  retryCount: {
    type: Number,
    default: 0
  },
  executedAt: {
    type: Date,
    default: Date.now
  }
});

const ruleExecutionSchema = new mongoose.Schema({
  ruleId: String,
  name: String,
  condition: String,
  action: String,
  conditionResult: Boolean,
  parameters: mongoose.Schema.Types.Mixed,
  executedAt: {
    type: Date,
    default: Date.now
  }
});

const transformationExecutionSchema = new mongoose.Schema({
  transformationId: String,
  name: String,
  type: String,
  inputData: mongoose.Schema.Types.Mixed,
  outputData: mongoose.Schema.Types.Mixed,
  success: Boolean,
  error: String,
  executedAt: {
    type: Date,
    default: Date.now
  }
});

const storageOperationSchema = new mongoose.Schema({
  database: String,
  collection: String,
  operation: {
    type: String,
    enum: ['insert', 'update', 'delete']
  },
  data: mongoose.Schema.Types.Mixed,
  success: Boolean,
  error: String,
  executedAt: {
    type: Date,
    default: Date.now
  }
});

const apiExecutionSchema = new mongoose.Schema({
  apiEndpointId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ApiEndpoint',
    required: true
  },
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  executionId: {
    type: String,
    required: true,
    unique: true
  },
  requestData: {
    method: String,
    path: String,
    headers: mongoose.Schema.Types.Mixed,
    body: mongoose.Schema.Types.Mixed,
    query: mongoose.Schema.Types.Mixed,
    params: mongoose.Schema.Types.Mixed
  },
  responseData: {
    status: Number,
    headers: mongoose.Schema.Types.Mixed,
    body: mongoose.Schema.Types.Mixed
  },
  execution: {
    upstreamCalls: [upstreamCallSchema],
    ruleExecutions: [ruleExecutionSchema],
    transformationExecutions: [transformationExecutionSchema],
    storageOperations: [storageOperationSchema]
  },
  metrics: {
    totalExecutionTime: Number,
    upstreamCallsCount: Number,
    rulesExecutedCount: Number,
    transformationsCount: Number,
    storageOperationsCount: Number
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'timeout'],
    default: 'pending'
  },
  success: Boolean,
  error: String,
  startedAt: {
    type: Date,
    default: Date.now
  },
  completedAt: Date
}, {
  timestamps: true
});

// Indexes for better query performance
apiExecutionSchema.index({ apiEndpointId: 1, createdAt: -1 });
apiExecutionSchema.index({ projectId: 1, createdAt: -1 });
apiExecutionSchema.index({ executionId: 1 });
apiExecutionSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('ApiExecution', apiExecutionSchema);