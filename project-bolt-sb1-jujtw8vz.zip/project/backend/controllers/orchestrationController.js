const { ApiEndpoint, ApiExecution, Project, QueueJob } = require('../models');
const axios = require('axios');

// Generate unique execution ID
const generateExecutionId = () => {
  return `exec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

// Replace template variables in strings
const replaceTemplateVariables = (template, context) => {
  if (!template || typeof template !== 'string') return template;
  
  return template.replace(/\{\{([^}]+)\}\}/g, (match, variable) => {
    const keys = variable.trim().split('.');
    let value = context;
    
    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return match; // Return original if not found
      }
    }
    
    return value !== undefined ? value : match;
  });
};

// Evaluate JavaScript condition
const evaluateCondition = (condition, context) => {
  if (!condition) return true;
  
  try {
    // Create a safe evaluation context
    const func = new Function('request', 'response', 'context', 'upstream', `return ${condition}`);
    return func(context.request, context.response, context.context, context.upstream);
  } catch (error) {
    console.error('Condition evaluation error:', error);
    return false;
  }
};

// Execute upstream API call
const executeUpstreamCall = async (upstreamCall, context, apiEndpoint) => {
  const startTime = Date.now();
  const callResult = {
    apiId: upstreamCall.apiEndpointId,
    name: `Upstream API ${upstreamCall.apiEndpointId}`,
    url: 'https://api.example.com/endpoint', // This would be resolved from apiEndpointId
    method: 'GET',
    requestHeaders: {},
    requestBody: null,
    responseStatus: null,
    responseHeaders: {},
    responseBody: null,
    responseTime: 0,
    success: false,
    error: null,
    retryCount: 0,
    executedAt: new Date()
  };

  try {
    // Replace template variables in headers
    const headers = {};
    if (upstreamCall.customHeaders) {
      for (const [key, value] of Object.entries(upstreamCall.customHeaders)) {
        headers[key] = replaceTemplateVariables(value, context);
      }
    }

    // Replace template variables in body
    let body = null;
    if (upstreamCall.customBody) {
      const bodyTemplate = replaceTemplateVariables(upstreamCall.customBody, context);
      try {
        body = JSON.parse(bodyTemplate);
      } catch (e) {
        body = bodyTemplate;
      }
    }

    // Mock API call (in real implementation, this would call actual external APIs)
    const mockResponse = {
      status: 200,
      statusText: 'OK',
      headers: { 'content-type': 'application/json' },
      data: {
        success: true,
        message: 'Mock upstream API response',
        timestamp: new Date().toISOString(),
        requestId: generateExecutionId()
      }
    };

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 200));

    callResult.requestHeaders = headers;
    callResult.requestBody = body;
    callResult.responseStatus = mockResponse.status;
    callResult.responseHeaders = mockResponse.headers;
    callResult.responseBody = mockResponse.data;
    callResult.responseTime = Date.now() - startTime;
    callResult.success = mockResponse.status >= 200 && mockResponse.status < 300;

    return callResult;
  } catch (error) {
    callResult.responseTime = Date.now() - startTime;
    callResult.success = false;
    callResult.error = error.message;
    
    // Retry logic
    const maxRetries = upstreamCall.customRetries || 3;
    if (callResult.retryCount < maxRetries) {
      callResult.retryCount++;
      console.log(`Retrying upstream call ${upstreamCall.id}, attempt ${callResult.retryCount}`);
      return executeUpstreamCall(upstreamCall, context, apiEndpoint);
    }
    
    return callResult;
  }
};

// Execute rule
const executeRule = (rule, context) => {
  const ruleResult = {
    ruleId: rule.id,
    name: rule.name,
    condition: rule.condition,
    action: rule.action,
    conditionResult: false,
    parameters: rule.parameters,
    executedAt: new Date()
  };

  try {
    ruleResult.conditionResult = evaluateCondition(rule.condition, context);
    return ruleResult;
  } catch (error) {
    console.error('Rule execution error:', error);
    ruleResult.conditionResult = false;
    return ruleResult;
  }
};

// Execute transformation
const executeTransformation = (transformation, data) => {
  const transformResult = {
    transformationId: transformation.id,
    name: transformation.name,
    type: transformation.type,
    inputData: data,
    outputData: null,
    success: false,
    error: null,
    executedAt: new Date()
  };

  try {
    let output = data;

    switch (transformation.type) {
      case 'xml-to-json':
        // Mock XML to JSON transformation
        output = { converted: 'xml-to-json', original: data };
        break;
      case 'text-to-json':
        // Mock text to JSON transformation
        output = { converted: 'text-to-json', original: data };
        break;
      case 'json-to-xml':
        // Mock JSON to XML transformation
        output = `<xml>${JSON.stringify(data)}</xml>`;
        break;
      case 'custom':
        // Mock custom transformation
        if (transformation.configuration.script) {
          // In real implementation, execute the custom script safely
          output = { ...data, transformed: true, timestamp: new Date().toISOString() };
        }
        break;
      default:
        output = data;
    }

    transformResult.outputData = output;
    transformResult.success = true;
    return transformResult;
  } catch (error) {
    transformResult.error = error.message;
    transformResult.success = false;
    return transformResult;
  }
};

// Execute storage operation
const executeStorageOperation = async (storageConfig, data, context) => {
  const storageResult = {
    database: storageConfig.database,
    collection: storageConfig.collection,
    operation: 'insert',
    data: null,
    success: false,
    error: null,
    executedAt: new Date()
  };

  try {
    if (!storageConfig.enabled) {
      storageResult.success = true;
      return storageResult;
    }

    // Check storage condition
    if (storageConfig.condition && !evaluateCondition(storageConfig.condition, context)) {
      storageResult.success = true;
      storageResult.data = { skipped: 'condition not met' };
      return storageResult;
    }

    // Map fields according to configuration
    const mappedData = {};
    for (const field of storageConfig.fields) {
      let value = data;
      const sourcePath = field.sourceField.split('.');
      
      for (const key of sourcePath) {
        if (value && typeof value === 'object' && key in value) {
          value = value[key];
        } else {
          value = null;
          break;
        }
      }

      // Apply transformation if specified
      if (field.transform && value !== null) {
        try {
          const transformFunc = new Function('value', `return ${field.transform}`);
          value = transformFunc(value);
        } catch (e) {
          console.error('Field transformation error:', e);
        }
      }

      mappedData[field.targetField] = value;
    }

    // Mock database operation
    storageResult.data = {
      ...mappedData,
      _id: generateExecutionId(),
      createdAt: new Date()
    };
    storageResult.success = true;

    return storageResult;
  } catch (error) {
    storageResult.error = error.message;
    storageResult.success = false;
    return storageResult;
  }
};

// Main orchestration function
const orchestrateApiExecution = async (apiEndpoint, requestData) => {
  const executionId = generateExecutionId();
  const startTime = Date.now();
  
  const executionContext = {
    request: requestData,
    response: null,
    context: {
      executionId,
      timestamp: new Date().toISOString(),
      retryCount: 0
    },
    upstream: {}
  };

  const execution = {
    upstreamCalls: [],
    ruleExecutions: [],
    transformationExecutions: [],
    storageOperations: []
  };

  let finalResponse = { success: true, data: {} };
  let executionSuccess = true;

  try {
    // Execute upstream API calls in order
    for (const upstreamCall of apiEndpoint.configuration.upstreamApis.sort((a, b) => a.order - b.order)) {
      // Check condition before executing
      if (upstreamCall.condition && !evaluateCondition(upstreamCall.condition, executionContext)) {
        console.log(`Skipping upstream call ${upstreamCall.id} - condition not met`);
        continue;
      }

      const callResult = await executeUpstreamCall(upstreamCall, executionContext, apiEndpoint);
      execution.upstreamCalls.push(callResult);

      // Add response to context for next calls
      executionContext.upstream[upstreamCall.apiEndpointId] = {
        response: callResult.responseBody,
        status: callResult.responseStatus,
        success: callResult.success
      };

      if (!callResult.success) {
        executionSuccess = false;
        finalResponse.success = false;
        finalResponse.error = `Upstream call failed: ${callResult.error}`;
      }
    }

    // Execute rules
    for (const rule of apiEndpoint.configuration.rules) {
      const ruleResult = executeRule(rule, executionContext);
      execution.ruleExecutions.push(ruleResult);

      // Handle rule actions
      if (ruleResult.conditionResult) {
        switch (rule.action) {
          case 'stop':
            finalResponse.success = false;
            finalResponse.message = `Execution stopped by rule: ${rule.name}`;
            executionSuccess = false;
            break;
          case 'redirect':
            // Handle redirect logic
            break;
          case 'transform':
            // Handle transformation logic
            break;
        }
      }
    }

    // Execute transformations
    let transformedData = finalResponse.data;
    for (const transformation of apiEndpoint.configuration.transformations) {
      const transformResult = executeTransformation(transformation, transformedData);
      execution.transformationExecutions.push(transformResult);
      
      if (transformResult.success) {
        transformedData = transformResult.outputData;
      }
    }
    finalResponse.data = transformedData;

    // Execute storage operations
    if (apiEndpoint.configuration.storage.enabled) {
      const storageResult = await executeStorageOperation(
        apiEndpoint.configuration.storage,
        finalResponse.data,
        executionContext
      );
      execution.storageOperations.push(storageResult);
    }

  } catch (error) {
    console.error('Orchestration error:', error);
    executionSuccess = false;
    finalResponse.success = false;
    finalResponse.error = error.message;
  }

  const endTime = Date.now();
  const totalExecutionTime = endTime - startTime;

  // Create execution record
  const apiExecution = new ApiExecution({
    apiEndpointId: apiEndpoint._id,
    projectId: apiEndpoint.projectId,
    executionId,
    requestData: {
      method: requestData.method || 'POST',
      path: apiEndpoint.path,
      headers: requestData.headers || {},
      body: requestData.body || {},
      query: requestData.query || {},
      params: requestData.params || {}
    },
    responseData: {
      status: finalResponse.success ? 200 : 500,
      headers: { 'content-type': 'application/json' },
      body: finalResponse
    },
    execution,
    metrics: {
      totalExecutionTime,
      upstreamCallsCount: execution.upstreamCalls.length,
      rulesExecutedCount: execution.ruleExecutions.length,
      transformationsCount: execution.transformationExecutions.length,
      storageOperationsCount: execution.storageOperations.length
    },
    status: executionSuccess ? 'completed' : 'failed',
    success: executionSuccess,
    error: executionSuccess ? null : finalResponse.error,
    startedAt: new Date(startTime),
    completedAt: new Date(endTime)
  });

  await apiExecution.save();

  return {
    executionId,
    success: executionSuccess,
    response: finalResponse,
    executionTime: totalExecutionTime,
    execution: apiExecution
  };
};

// Execute API endpoint
const executeApiEndpoint = async (req, res) => {
  try {
    const { projectId, path } = req.params;
    const { method = 'POST' } = req.query;

    // Find the API endpoint
    const apiEndpoint = await ApiEndpoint.findOne({
      projectId,
      path: `/${path}`,
      method: method.toUpperCase(),
      status: 'active'
    }).populate('projectId');

    if (!apiEndpoint) {
      return res.status(404).json({
        error: 'API endpoint not found',
        message: `${method.toUpperCase()} /${path} not found in project ${projectId}`
      });
    }

    // Check if API should be queued
    if (apiEndpoint.configuration.queueConfig?.enabled) {
      // Create queue job instead of immediate execution
      const queueJob = new QueueJob({
        queueName: apiEndpoint.configuration.queueConfig.queueName,
        jobType: 'API_CALL',
        apiEndpointId: apiEndpoint._id,
        projectId: apiEndpoint.projectId,
        priority: apiEndpoint.configuration.queueConfig.priority || 1,
        data: {
          requestData: {
            method: req.method,
            headers: req.headers,
            body: req.body,
            query: req.query,
            params: req.params
          }
        },
        delay: apiEndpoint.configuration.queueConfig.delay || 0
      });

      await queueJob.save();

      return res.status(202).json({
        message: 'API call queued for processing',
        queueJobId: queueJob._id,
        estimatedProcessingTime: `${apiEndpoint.configuration.queueConfig.delay || 0}s`
      });
    }

    // Execute immediately
    const requestData = {
      method: req.method,
      headers: req.headers,
      body: req.body,
      query: req.query,
      params: req.params
    };

    const result = await orchestrateApiExecution(apiEndpoint, requestData);

    res.status(result.success ? 200 : 500).json({
      executionId: result.executionId,
      success: result.success,
      data: result.response.data,
      message: result.response.message,
      error: result.response.error,
      executionTime: result.executionTime,
      metadata: {
        upstreamCalls: result.execution.metrics.upstreamCallsCount,
        rulesExecuted: result.execution.metrics.rulesExecutedCount,
        transformations: result.execution.metrics.transformationsCount,
        storageOperations: result.execution.metrics.storageOperationsCount
      }
    });

  } catch (error) {
    console.error('API execution error:', error);
    res.status(500).json({
      error: 'API execution failed',
      message: error.message
    });
  }
};

// Get API endpoint documentation
const getApiDocumentation = async (req, res) => {
  try {
    const { projectId, path } = req.params;

    const apiEndpoint = await ApiEndpoint.findOne({
      projectId,
      path: `/${path}`,
      status: 'active'
    }).populate('projectId');

    if (!apiEndpoint) {
      return res.status(404).json({
        error: 'API endpoint not found'
      });
    }

    const documentation = {
      name: apiEndpoint.name,
      description: apiEndpoint.description,
      method: apiEndpoint.method,
      path: apiEndpoint.path,
      projectName: apiEndpoint.projectId.name,
      configuration: {
        upstreamApis: apiEndpoint.configuration.upstreamApis.length,
        rules: apiEndpoint.configuration.rules.length,
        transformations: apiEndpoint.configuration.transformations.length,
        storageEnabled: apiEndpoint.configuration.storage.enabled,
        queueEnabled: apiEndpoint.configuration.queueConfig?.enabled || false
      },
      usage: {
        endpoint: `${req.protocol}://${req.get('host')}/execute/${projectId}/${path.replace(/^\//, '')}`,
        method: apiEndpoint.method,
        headers: {
          'Content-Type': 'application/json'
        },
        exampleRequest: {
          body: JSON.parse(apiEndpoint.requestBody || '{}')
        }
      }
    };

    res.json(documentation);
  } catch (error) {
    console.error('Documentation error:', error);
    res.status(500).json({
      error: 'Failed to get API documentation',
      message: error.message
    });
  }
};

// List all executable APIs for a project
const listProjectApis = async (req, res) => {
  try {
    const { projectId } = req.params;

    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const apis = await ApiEndpoint.find({
      projectId,
      status: 'active'
    }).select('name description path method createdAt updatedAt');

    const apiList = apis.map(api => ({
      name: api.name,
      description: api.description,
      method: api.method,
      path: api.path,
      endpoint: `${req.protocol}://${req.get('host')}/execute/${projectId}${api.path}`,
      documentation: `${req.protocol}://${req.get('host')}/docs/${projectId}${api.path}`
    }));

    res.json({
      project: {
        id: project._id,
        name: project.name,
        description: project.description
      },
      apis: apiList,
      totalApis: apiList.length
    });
  } catch (error) {
    console.error('List APIs error:', error);
    res.status(500).json({
      error: 'Failed to list project APIs',
      message: error.message
    });
  }
};

module.exports = {
  executeApiEndpointBySlug,
  getApiDocumentationBySlug,
  listProjectApisBySlug,
  orchestrateApiExecution
};