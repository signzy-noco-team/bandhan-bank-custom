const { ApiEndpoint, Project, ApiExecution } = require('../models');

// Get all API endpoints for a project
const getApiEndpointsByProject = async (req, res) => {
  try {
    const { projectId } = req.params;

    // Verify project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const apiEndpoints = await ApiEndpoint.find({ projectId })
      .sort({ createdAt: -1 });

    res.json(apiEndpoints);
  } catch (error) {
    console.error('Error fetching API endpoints:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API endpoints',
      message: error.message 
    });
  }
};

// Get API endpoint by ID
const getApiEndpointById = async (req, res) => {
  try {
    const { id } = req.params;

    const apiEndpoint = await ApiEndpoint.findById(id)
      .populate('projectId', 'name description');

    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    res.json(apiEndpoint);
  } catch (error) {
    console.error('Error fetching API endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API endpoint',
      message: error.message 
    });
  }
};

// Create new API endpoint
const createApiEndpoint = async (req, res) => {
  try {
    const {
      projectId,
      name,
      slug,
      path,
      method,
      description,
      status,
      configuration,
      variables,
      headers,
      requestBody
    } = req.body;

    // Validate required fields
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'API name is required' });
    }

    if (!slug || slug.trim().length === 0) {
      return res.status(400).json({ error: 'API slug is required' });
    }
    if (!path || !path.startsWith('/')) {
      return res.status(400).json({ error: 'API path is required and must start with /' });
    }

    if (!method) {
      return res.status(400).json({ error: 'HTTP method is required' });
    }

    // Verify project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Check for duplicate slug in the same project
    const existingApi = await ApiEndpoint.findOne({ 
      projectId, 
      slug: slug.toLowerCase().trim()
    });
    
    if (existingApi) {
      return res.status(400).json({ 
        error: 'API slug already exists',
        message: 'An API with this slug already exists in this project. Please choose a different slug.'
      });
    }

    const apiEndpoint = new ApiEndpoint({
      projectId,
      name: name.trim(),
      slug: slug.toLowerCase().trim(),
      path: path.trim(),
      method,
      description: description?.trim(),
      status: status || 'active',
      configuration: configuration || {
        upstreamApis: [],
        rules: [],
        transformations: [],
        storage: {
          enabled: false,
          database: '',
          collection: '',
          fields: []
        }
      },
      variables: variables || [],
      headers: headers || [],
      requestBody: requestBody || ''
    });

    const savedApiEndpoint = await apiEndpoint.save();
    res.status(201).json(savedApiEndpoint);
  } catch (error) {
    console.error('Error creating API endpoint:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to create API endpoint',
      message: error.message 
    });
  }
};

// Update API endpoint
const updateApiEndpoint = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Remove fields that shouldn't be updated directly
    delete updateData._id;
    delete updateData.createdAt;
    delete updateData.__v;

    // If updating slug, check for duplicates
    if (updateData.slug) {
      const currentApi = await ApiEndpoint.findById(id);
      if (!currentApi) {
        return res.status(404).json({ error: 'API endpoint not found' });
      }


      const existingApi = await ApiEndpoint.findOne({ 
        _id: { $ne: id },
        projectId: currentApi.projectId,
        slug: updateData.slug.toLowerCase().trim()
      });

      if (existingApi) {
        return res.status(400).json({ 
          error: 'API slug already exists',
          message: 'An API with this slug already exists in this project. Please choose a different slug.'
        });
      }
      
      updateData.slug = updateData.slug.toLowerCase().trim();
    }

    const apiEndpoint = await ApiEndpoint.findByIdAndUpdate(
      id,
      { ...updateData, updatedAt: new Date() },
      { new: true, runValidators: true }
    ).populate('projectId', 'name description');

    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    res.json(apiEndpoint);
  } catch (error) {
    console.error('Error updating API endpoint:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to update API endpoint',
      message: error.message 
    });
  }
};

// Delete API endpoint
const deleteApiEndpoint = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if API is referenced by other APIs as upstream
    const referencingApis = await ApiEndpoint.find({
      'configuration.upstreamApis.apiEndpointId': id
    });

    if (referencingApis.length > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete API endpoint',
        message: `This API is referenced by ${referencingApis.length} other API(s) as upstream. Remove references first.`,
        referencingApis: referencingApis.map(api => ({ id: api._id, name: api.name }))
      });
    }

    const apiEndpoint = await ApiEndpoint.findByIdAndDelete(id);
    
    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    res.json({ 
      message: 'API endpoint deleted successfully',
      deletedApiEndpoint: apiEndpoint 
    });
  } catch (error) {
    console.error('Error deleting API endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to delete API endpoint',
      message: error.message 
    });
  }
};

// Get API endpoint execution history
const getApiExecutionHistory = async (req, res) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 20, status } = req.query;

    const apiEndpoint = await ApiEndpoint.findById(id);
    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    const filter = { apiEndpointId: id };
    if (status) {
      filter.status = status;
    }

    const executions = await ApiExecution.find(filter)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await ApiExecution.countDocuments(filter);

    res.json({
      executions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching execution history:', error);
    res.status(500).json({ 
      error: 'Failed to fetch execution history',
      message: error.message 
    });
  }
};

// Test API endpoint
const testApiEndpoint = async (req, res) => {
  try {
    const { id } = req.params;
    const { testData } = req.body;

    const apiEndpoint = await ApiEndpoint.findById(id);
    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    // This would typically trigger the actual API orchestration
    // For now, return a mock response
    const mockResponse = {
      executionId: `test-${Date.now()}`,
      status: 'completed',
      success: true,
      startTime: new Date(),
      endTime: new Date(Date.now() + 1000),
      executionTime: 1000,
      upstreamCalls: apiEndpoint.configuration.upstreamApis.length,
      rulesExecuted: apiEndpoint.configuration.rules.length,
      transformations: apiEndpoint.configuration.transformations.length,
      response: {
        status: 200,
        data: {
          message: 'API test completed successfully',
          timestamp: new Date().toISOString(),
          testData: testData || {}
        }
      }
    };

    res.json(mockResponse);
  } catch (error) {
    console.error('Error testing API endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to test API endpoint',
      message: error.message 
    });
  }
};

// Get available APIs for upstream selection
const getAvailableUpstreamApis = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { excludeId } = req.query;

    const filter = { 
      projectId, 
      status: 'active' 
    };

    // Exclude the current API to prevent self-reference
    if (excludeId) {
      filter._id = { $ne: excludeId };
    }

    const availableApis = await ApiEndpoint.find(filter)
      .select('_id name path method description')
      .sort({ name: 1 });

    res.json(availableApis);
  } catch (error) {
    console.error('Error fetching available upstream APIs:', error);
    res.status(500).json({ 
      error: 'Failed to fetch available upstream APIs',
      message: error.message 
    });
  }
};

// Check API slug availability within project
const checkSlugAvailability = async (req, res) => {
  try {
    const { projectId, slug } = req.params;
    const { excludeId } = req.query;

    // Verify project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const filter = { 
      projectId, 
      slug: slug.toLowerCase().trim() 
    };
    
    if (excludeId) {
      filter._id = { $ne: excludeId };
    }

    const existingApi = await ApiEndpoint.findOne(filter);
    
    res.json({
      available: !existingApi,
      slug: slug.toLowerCase().trim(),
      projectId
    });
  } catch (error) {
    console.error('Error checking API slug availability:', error);
    res.status(500).json({ 
      error: 'Failed to check slug availability',
      message: error.message 
    });
  }
};

module.exports = {
  getApiEndpointsByProject,
  getApiEndpointById,
  createApiEndpoint,
  updateApiEndpoint,
  deleteApiEndpoint,
  getApiExecutionHistory,
  testApiEndpoint,
  getAvailableUpstreamApis,
  checkSlugAvailability
};