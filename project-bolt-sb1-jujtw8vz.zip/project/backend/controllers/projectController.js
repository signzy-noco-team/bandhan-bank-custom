const { Project, ApiEndpoint } = require('../models');

// Get all projects
const getAllProjects = async (req, res) => {
  try {
    const projects = await Project.find()
      .populate('apiCount')
      .sort({ createdAt: -1 });
    
    res.json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ 
      error: 'Failed to fetch projects',
      message: error.message 
    });
  }
};

// Get project by ID
const getProjectById = async (req, res) => {
  try {
    const { id } = req.params;
    
    const project = await Project.findById(id)
      .populate('apiCount');
    
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    
    res.json(project);
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({ 
      error: 'Failed to fetch project',
      message: error.message 
    });
  }
};

// Create new project
const createProject = async (req, res) => {
  try {
    const {
      name,
      slug,
      description,
      status,
      globalVariables,
      databaseConnections,
      defaultSettings,
      rateLimiting,
      authentication
    } = req.body;

    // Validate required fields
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'Project name is required' });
    }

    if (!slug || slug.trim().length === 0) {
      return res.status(400).json({ error: 'Project slug is required' });
    }

    // Check if slug already exists
    const existingProject = await Project.findOne({ slug: slug.toLowerCase().trim() });
    if (existingProject) {
      return res.status(400).json({ 
        error: 'Slug already exists',
        message: 'A project with this slug already exists. Please choose a different slug.'
      });
    }
    const project = new Project({
      name: name.trim(),
      slug: slug.toLowerCase().trim(),
      description: description?.trim(),
      status: status || 'active',
      globalVariables: globalVariables || [],
      databaseConnections: databaseConnections || [],
      defaultSettings: {
        timeout: defaultSettings?.timeout || 5000,
        retries: defaultSettings?.retries || 3,
        enableLogging: defaultSettings?.enableLogging !== false,
        logLevel: defaultSettings?.logLevel || 'info'
      },
      rateLimiting: {
        enabled: rateLimiting?.enabled || false,
        requestsPerMinute: rateLimiting?.requestsPerMinute || 60
      },
      authentication: {
        enabled: authentication?.enabled || false,
        type: authentication?.type || 'apikey',
        config: authentication?.config || {}
      }
    });

    const savedProject = await project.save();
    res.status(201).json(savedProject);
  } catch (error) {
    console.error('Error creating project:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to create project',
      message: error.message 
    });
  }
};

// Update project
const updateProject = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Remove fields that shouldn't be updated directly
    delete updateData._id;
    delete updateData.createdAt;
    delete updateData.__v;

    // If updating slug, check for duplicates
    if (updateData.slug) {
      const existingProject = await Project.findOne({ 
        slug: updateData.slug.toLowerCase().trim(),
        _id: { $ne: id }
      });
      
      if (existingProject) {
        return res.status(400).json({ 
          error: 'Slug already exists',
          message: 'A project with this slug already exists. Please choose a different slug.'
        });
      }
      
      updateData.slug = updateData.slug.toLowerCase().trim();
    }
    const project = await Project.findByIdAndUpdate(
      id,
      { ...updateData, updatedAt: new Date() },
      { new: true, runValidators: true }
    ).populate('apiCount');

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json(project);
  } catch (error) {
    console.error('Error updating project:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to update project',
      message: error.message 
    });
  }
};

// Delete project
const deleteProject = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if project has APIs
    const apiCount = await ApiEndpoint.countDocuments({ projectId: id });
    if (apiCount > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete project with existing APIs',
        message: `Project has ${apiCount} API(s). Delete all APIs first.`
      });
    }

    const project = await Project.findByIdAndDelete(id);
    
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({ 
      message: 'Project deleted successfully',
      deletedProject: project 
    });
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({ 
      error: 'Failed to delete project',
      message: error.message 
    });
  }
};

// Get project statistics
const getProjectStats = async (req, res) => {
  try {
    const { id } = req.params;

    const project = await Project.findById(id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const apiCount = await ApiEndpoint.countDocuments({ projectId: id });
    const activeApiCount = await ApiEndpoint.countDocuments({ 
      projectId: id, 
      status: 'active' 
    });

    const stats = {
      totalApis: apiCount,
      activeApis: activeApiCount,
      inactiveApis: apiCount - activeApiCount,
      globalVariables: project.globalVariables.length,
      databaseConnections: project.databaseConnections.length,
      authenticationEnabled: project.authentication.enabled,
      rateLimitingEnabled: project.rateLimiting.enabled
    };

    res.json(stats);
  } catch (error) {
    console.error('Error fetching project stats:', error);
    res.status(500).json({ 
      error: 'Failed to fetch project statistics',
      message: error.message 
    });
  }
};

module.exports = {
  getAllProjects,
  getProjectById,
  createProject,
  updateProject,
  deleteProject,
  getProjectStats
};