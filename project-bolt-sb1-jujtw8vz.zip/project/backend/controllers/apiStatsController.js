const { ApiStats, ApiEndpoint, Project, ApiExecution } = require('../models');

// Get API statistics with filtering
const getApiStats = async (req, res) => {
  try {
    const { 
      projectId, 
      apiEndpointId, 
      period = 'day', 
      startDate, 
      endDate,
      page = 1,
      limit = 20
    } = req.query;

    const filter = { period };
    
    if (projectId) filter.projectId = projectId;
    if (apiEndpointId) filter.apiEndpointId = apiEndpointId;
    
    if (startDate || endDate) {
      filter.date = {};
      if (startDate) filter.date.$gte = new Date(startDate);
      if (endDate) filter.date.$lte = new Date(endDate);
    }

    const stats = await ApiStats.find(filter)
      .populate('apiEndpointId', 'name path method')
      .populate('projectId', 'name')
      .sort({ date: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await ApiStats.countDocuments(filter);

    res.json({
      stats,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching API stats:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API statistics',
      message: error.message 
    });
  }
};

// Get aggregated statistics for dashboard
const getDashboardStats = async (req, res) => {
  try {
    const { projectId, period = 'day', days = 7 } = req.query;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - parseInt(days));

    const matchFilter = {
      period,
      date: { $gte: startDate, $lte: endDate }
    };

    if (projectId) {
      matchFilter.projectId = projectId;
    }

    const aggregatedStats = await ApiStats.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: null,
          totalCalls: { $sum: '$metrics.totalCalls' },
          successfulCalls: { $sum: '$metrics.successfulCalls' },
          failedCalls: { $sum: '$metrics.failedCalls' },
          avgResponseTime: { $avg: '$metrics.averageResponseTime' },
          totalUpstreamCalls: { $sum: '$metrics.upstreamCallsCount' },
          totalTransformations: { $sum: '$metrics.transformationsCount' },
          totalStorageOperations: { $sum: '$metrics.storageOperationsCount' }
        }
      }
    ]);

    const stats = aggregatedStats[0] || {
      totalCalls: 0,
      successfulCalls: 0,
      failedCalls: 0,
      avgResponseTime: 0,
      totalUpstreamCalls: 0,
      totalTransformations: 0,
      totalStorageOperations: 0
    };

    // Calculate success rate
    stats.successRate = stats.totalCalls > 0 
      ? (stats.successfulCalls / stats.totalCalls) * 100 
      : 0;

    // Calculate error rate
    stats.errorRate = stats.totalCalls > 0 
      ? (stats.failedCalls / stats.totalCalls) * 100 
      : 0;

    res.json(stats);
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ 
      error: 'Failed to fetch dashboard statistics',
      message: error.message 
    });
  }
};

// Get API performance trends
const getApiPerformanceTrends = async (req, res) => {
  try {
    const { 
      apiEndpointId, 
      projectId, 
      period = 'day', 
      days = 30 
    } = req.query;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - parseInt(days));

    const matchFilter = {
      period,
      date: { $gte: startDate, $lte: endDate }
    };

    if (apiEndpointId) matchFilter.apiEndpointId = apiEndpointId;
    if (projectId) matchFilter.projectId = projectId;

    const trends = await ApiStats.find(matchFilter)
      .populate('apiEndpointId', 'name path method')
      .sort({ date: 1 })
      .select('date metrics successRate errorRate apiEndpointId');

    res.json(trends);
  } catch (error) {
    console.error('Error fetching performance trends:', error);
    res.status(500).json({ 
      error: 'Failed to fetch performance trends',
      message: error.message 
    });
  }
};

// Get top performing APIs
const getTopPerformingApis = async (req, res) => {
  try {
    const { 
      projectId, 
      period = 'day', 
      days = 7, 
      sortBy = 'totalCalls',
      limit = 10 
    } = req.query;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - parseInt(days));

    const matchFilter = {
      period,
      date: { $gte: startDate, $lte: endDate }
    };

    if (projectId) {
      matchFilter.projectId = projectId;
    }

    const sortField = `metrics.${sortBy === 'successRate' ? 'successfulCalls' : sortBy}`;

    const topApis = await ApiStats.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: '$apiEndpointId',
          totalCalls: { $sum: '$metrics.totalCalls' },
          successfulCalls: { $sum: '$metrics.successfulCalls' },
          failedCalls: { $sum: '$metrics.failedCalls' },
          avgResponseTime: { $avg: '$metrics.averageResponseTime' },
          upstreamCallsCount: { $sum: '$metrics.upstreamCallsCount' }
        }
      },
      {
        $addFields: {
          successRate: {
            $cond: [
              { $gt: ['$totalCalls', 0] },
              { $multiply: [{ $divide: ['$successfulCalls', '$totalCalls'] }, 100] },
              0
            ]
          }
        }
      },
      { $sort: { [sortBy]: -1 } },
      { $limit: parseInt(limit) },
      {
        $lookup: {
          from: 'apiendpoints',
          localField: '_id',
          foreignField: '_id',
          as: 'apiEndpoint'
        }
      },
      { $unwind: '$apiEndpoint' }
    ]);

    res.json(topApis);
  } catch (error) {
    console.error('Error fetching top performing APIs:', error);
    res.status(500).json({ 
      error: 'Failed to fetch top performing APIs',
      message: error.message 
    });
  }
};

// Get error analysis
const getErrorAnalysis = async (req, res) => {
  try {
    const { 
      projectId, 
      apiEndpointId, 
      period = 'day', 
      days = 7 
    } = req.query;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - parseInt(days));

    const matchFilter = {
      period,
      date: { $gte: startDate, $lte: endDate }
    };

    if (projectId) matchFilter.projectId = projectId;
    if (apiEndpointId) matchFilter.apiEndpointId = apiEndpointId;

    const errorAnalysis = await ApiStats.aggregate([
      { $match: matchFilter },
      { $unwind: '$errorTypes' },
      {
        $group: {
          _id: '$errorTypes.type',
          count: { $sum: '$errorTypes.count' },
          lastOccurrence: { $max: '$errorTypes.lastOccurrence' }
        }
      },
      { $sort: { count: -1 } },
      { $limit: 20 }
    ]);

    // Get status code distribution
    const statusCodeStats = await ApiStats.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: null,
          status200: { $sum: '$statusCodes.200' },
          status201: { $sum: '$statusCodes.201' },
          status400: { $sum: '$statusCodes.400' },
          status401: { $sum: '$statusCodes.401' },
          status403: { $sum: '$statusCodes.403' },
          status404: { $sum: '$statusCodes.404' },
          status500: { $sum: '$statusCodes.500' },
          others: { $sum: '$statusCodes.others' }
        }
      }
    ]);

    res.json({
      errorTypes: errorAnalysis,
      statusCodes: statusCodeStats[0] || {}
    });
  } catch (error) {
    console.error('Error fetching error analysis:', error);
    res.status(500).json({ 
      error: 'Failed to fetch error analysis',
      message: error.message 
    });
  }
};

// Record API execution for statistics
const recordApiExecution = async (req, res) => {
  try {
    const {
      apiEndpointId,
      projectId,
      executionData,
      period = 'day'
    } = req.body;

    // Validate required fields
    if (!apiEndpointId || !projectId || !executionData) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['apiEndpointId', 'projectId', 'executionData']
      });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Find or create stats record for today
    let stats = await ApiStats.findOne({
      apiEndpointId,
      projectId,
      date: today,
      period
    });

    if (!stats) {
      stats = new ApiStats({
        apiEndpointId,
        projectId,
        date: today,
        period,
        metrics: {
          totalCalls: 0,
          successfulCalls: 0,
          failedCalls: 0,
          averageResponseTime: 0,
          minResponseTime: Number.MAX_VALUE,
          maxResponseTime: 0,
          totalResponseTime: 0,
          upstreamCallsCount: 0,
          transformationsCount: 0,
          storageOperationsCount: 0
        },
        statusCodes: {},
        errorTypes: []
      });
    }

    // Update metrics
    stats.metrics.totalCalls += 1;
    
    if (executionData.success) {
      stats.metrics.successfulCalls += 1;
    } else {
      stats.metrics.failedCalls += 1;
    }

    // Update response time metrics
    if (executionData.responseTime) {
      stats.metrics.totalResponseTime += executionData.responseTime;
      stats.metrics.averageResponseTime = stats.metrics.totalResponseTime / stats.metrics.totalCalls;
      stats.metrics.minResponseTime = Math.min(stats.metrics.minResponseTime, executionData.responseTime);
      stats.metrics.maxResponseTime = Math.max(stats.metrics.maxResponseTime, executionData.responseTime);
    }

    // Update other metrics
    if (executionData.upstreamCallsCount) {
      stats.metrics.upstreamCallsCount += executionData.upstreamCallsCount;
    }
    if (executionData.transformationsCount) {
      stats.metrics.transformationsCount += executionData.transformationsCount;
    }
    if (executionData.storageOperationsCount) {
      stats.metrics.storageOperationsCount += executionData.storageOperationsCount;
    }

    // Update status codes
    if (executionData.statusCode) {
      const statusKey = executionData.statusCode.toString();
      if (['200', '201', '400', '401', '403', '404', '500'].includes(statusKey)) {
        stats.statusCodes[statusKey] = (stats.statusCodes[statusKey] || 0) + 1;
      } else {
        stats.statusCodes.others = (stats.statusCodes.others || 0) + 1;
      }
    }

    // Update error types
    if (executionData.error) {
      const existingError = stats.errorTypes.find(e => e.type === executionData.error.type);
      if (existingError) {
        existingError.count += 1;
        existingError.lastOccurrence = new Date();
      } else {
        stats.errorTypes.push({
          type: executionData.error.type,
          count: 1,
          lastOccurrence: new Date()
        });
      }
    }

    await stats.save();
    res.json({ message: 'API execution recorded successfully', stats });
  } catch (error) {
    console.error('Error recording API execution:', error);
    res.status(500).json({ 
      error: 'Failed to record API execution',
      message: error.message 
    });
  }
};

module.exports = {
  getApiStats,
  getDashboardStats,
  getApiPerformanceTrends,
  getTopPerformingApis,
  getErrorAnalysis,
  recordApiExecution
};