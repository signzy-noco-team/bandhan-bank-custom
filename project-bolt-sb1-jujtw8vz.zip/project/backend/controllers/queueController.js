const { QueueJob, ApiEndpoint, Project } = require('../models');

// Get all queue jobs with filtering
const getAllQueueJobs = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 20, 
      status, 
      queueName, 
      projectId,
      jobType 
    } = req.query;

    const filter = {};
    
    if (status) filter.status = status;
    if (queueName) filter.queueName = queueName;
    if (projectId) filter.projectId = projectId;
    if (jobType) filter.jobType = jobType;

    const jobs = await QueueJob.find(filter)
      .populate('apiEndpointId', 'name path method')
      .populate('projectId', 'name')
      .sort({ priority: -1, scheduledAt: 1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await QueueJob.countDocuments(filter);

    res.json({
      jobs,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching queue jobs:', error);
    res.status(500).json({ 
      error: 'Failed to fetch queue jobs',
      message: error.message 
    });
  }
};

// Get queue job by ID
const getQueueJobById = async (req, res) => {
  try {
    const { id } = req.params;

    const job = await QueueJob.findById(id)
      .populate('apiEndpointId', 'name path method description')
      .populate('projectId', 'name description');

    if (!job) {
      return res.status(404).json({ error: 'Queue job not found' });
    }

    res.json(job);
  } catch (error) {
    console.error('Error fetching queue job:', error);
    res.status(500).json({ 
      error: 'Failed to fetch queue job',
      message: error.message 
    });
  }
};

// Create new queue job
const createQueueJob = async (req, res) => {
  try {
    const {
      queueName,
      jobType,
      apiEndpointId,
      projectId,
      priority,
      data,
      delay,
      maxAttempts,
      metadata
    } = req.body;

    // Validate required fields
    if (!queueName || !jobType || !projectId || !data) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['queueName', 'jobType', 'projectId', 'data']
      });
    }

    // Verify project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Verify API endpoint exists if provided
    if (apiEndpointId) {
      const apiEndpoint = await ApiEndpoint.findById(apiEndpointId);
      if (!apiEndpoint) {
        return res.status(404).json({ error: 'API endpoint not found' });
      }
    }

    const scheduledAt = delay ? new Date(Date.now() + delay * 1000) : new Date();

    const queueJob = new QueueJob({
      queueName,
      jobType,
      apiEndpointId,
      projectId,
      priority: priority || 1,
      data,
      maxAttempts: maxAttempts || 3,
      delay: delay || 0,
      scheduledAt,
      metadata: metadata || {}
    });

    const savedJob = await queueJob.save();
    res.status(201).json(savedJob);
  } catch (error) {
    console.error('Error creating queue job:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to create queue job',
      message: error.message 
    });
  }
};

// Update queue job status
const updateQueueJobStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, result, error } = req.body;

    const updateData = { status };
    
    if (status === 'processing' && !req.body.startedAt) {
      updateData.startedAt = new Date();
    }
    
    if (status === 'completed' || status === 'failed') {
      updateData.completedAt = new Date();
      
      if (result) updateData.result = result;
      if (error) updateData.error = error;
      
      // Calculate processing time
      const job = await QueueJob.findById(id);
      if (job && job.startedAt) {
        updateData.processingTime = new Date() - job.startedAt;
      }
    }

    const job = await QueueJob.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    ).populate('apiEndpointId', 'name path method')
     .populate('projectId', 'name');

    if (!job) {
      return res.status(404).json({ error: 'Queue job not found' });
    }

    res.json(job);
  } catch (error) {
    console.error('Error updating queue job:', error);
    res.status(500).json({ 
      error: 'Failed to update queue job',
      message: error.message 
    });
  }
};

// Retry failed queue job
const retryQueueJob = async (req, res) => {
  try {
    const { id } = req.params;

    const job = await QueueJob.findById(id);
    if (!job) {
      return res.status(404).json({ error: 'Queue job not found' });
    }

    if (job.status !== 'failed') {
      return res.status(400).json({ 
        error: 'Only failed jobs can be retried',
        currentStatus: job.status 
      });
    }

    if (job.attempts >= job.maxAttempts) {
      return res.status(400).json({ 
        error: 'Job has exceeded maximum retry attempts',
        attempts: job.attempts,
        maxAttempts: job.maxAttempts
      });
    }

    const updatedJob = await QueueJob.findByIdAndUpdate(
      id,
      {
        status: 'pending',
        attempts: 0,
        error: null,
        startedAt: null,
        completedAt: null,
        scheduledAt: new Date()
      },
      { new: true }
    ).populate('apiEndpointId', 'name path method')
     .populate('projectId', 'name');

    res.json(updatedJob);
  } catch (error) {
    console.error('Error retrying queue job:', error);
    res.status(500).json({ 
      error: 'Failed to retry queue job',
      message: error.message 
    });
  }
};

// Delete queue job
const deleteQueueJob = async (req, res) => {
  try {
    const { id } = req.params;

    const job = await QueueJob.findById(id);
    if (!job) {
      return res.status(404).json({ error: 'Queue job not found' });
    }

    if (job.status === 'processing') {
      return res.status(400).json({ 
        error: 'Cannot delete job that is currently processing',
        status: job.status 
      });
    }

    await QueueJob.findByIdAndDelete(id);

    res.json({ 
      message: 'Queue job deleted successfully',
      deletedJob: { id: job._id, queueName: job.queueName, jobType: job.jobType }
    });
  } catch (error) {
    console.error('Error deleting queue job:', error);
    res.status(500).json({ 
      error: 'Failed to delete queue job',
      message: error.message 
    });
  }
};

// Get queue statistics
const getQueueStats = async (req, res) => {
  try {
    const { queueName, projectId } = req.query;

    const matchFilter = {};
    if (queueName) matchFilter.queueName = queueName;
    if (projectId) matchFilter.projectId = projectId;

    const stats = await QueueJob.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: '$queueName',
          totalJobs: { $sum: 1 },
          pending: { $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] } },
          processing: { $sum: { $cond: [{ $eq: ['$status', 'processing'] }, 1, 0] } },
          completed: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
          failed: { $sum: { $cond: [{ $eq: ['$status', 'failed'] }, 1, 0] } },
          retrying: { $sum: { $cond: [{ $eq: ['$status', 'retrying'] }, 1, 0] } },
          avgProcessingTime: { 
            $avg: { 
              $cond: [
                { $ne: ['$processingTime', null] }, 
                '$processingTime', 
                null
              ] 
            } 
          }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json(stats);
  } catch (error) {
    console.error('Error fetching queue stats:', error);
    res.status(500).json({ 
      error: 'Failed to fetch queue statistics',
      message: error.message 
    });
  }
};

// Get next jobs to process
const getNextJobsToProcess = async (req, res) => {
  try {
    const { queueName, limit = 10 } = req.query;

    const filter = {
      status: 'pending',
      scheduledAt: { $lte: new Date() }
    };

    if (queueName) {
      filter.queueName = queueName;
    }

    const jobs = await QueueJob.find(filter)
      .populate('apiEndpointId', 'name path method configuration')
      .populate('projectId', 'name globalVariables')
      .sort({ priority: -1, scheduledAt: 1 })
      .limit(parseInt(limit));

    res.json(jobs);
  } catch (error) {
    console.error('Error fetching next jobs:', error);
    res.status(500).json({ 
      error: 'Failed to fetch next jobs',
      message: error.message 
    });
  }
};

module.exports = {
  getAllQueueJobs,
  getQueueJobById,
  createQueueJob,
  updateQueueJobStatus,
  retryQueueJob,
  deleteQueueJob,
  getQueueStats,
  getNextJobsToProcess
};