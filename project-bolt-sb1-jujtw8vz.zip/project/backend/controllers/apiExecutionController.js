const { ApiExecution, ApiEndpoint, Project } = require('../models');

// Get all API executions with filtering
const getAllApiExecutions = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 20, 
      status, 
      apiEndpointId, 
      projectId,
      startDate,
      endDate 
    } = req.query;

    const filter = {};
    
    if (status) filter.status = status;
    if (apiEndpointId) filter.apiEndpointId = apiEndpointId;
    if (projectId) filter.projectId = projectId;
    
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const executions = await ApiExecution.find(filter)
      .populate('apiEndpointId', 'name path method')
      .populate('projectId', 'name')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await ApiExecution.countDocuments(filter);

    res.json({
      executions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching API executions:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API executions',
      message: error.message 
    });
  }
};

// Get API execution by ID
const getApiExecutionById = async (req, res) => {
  try {
    const { id } = req.params;

    const execution = await ApiExecution.findById(id)
      .populate('apiEndpointId', 'name path method description')
      .populate('projectId', 'name description');

    if (!execution) {
      return res.status(404).json({ error: 'API execution not found' });
    }

    res.json(execution);
  } catch (error) {
    console.error('Error fetching API execution:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API execution',
      message: error.message 
    });
  }
};

// Get API execution by execution ID
const getApiExecutionByExecutionId = async (req, res) => {
  try {
    const { executionId } = req.params;

    const execution = await ApiExecution.findOne({ executionId })
      .populate('apiEndpointId', 'name path method description')
      .populate('projectId', 'name description');

    if (!execution) {
      return res.status(404).json({ error: 'API execution not found' });
    }

    res.json(execution);
  } catch (error) {
    console.error('Error fetching API execution:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API execution',
      message: error.message 
    });
  }
};

// Get executions for specific API endpoint
const getExecutionsByApiEndpoint = async (req, res) => {
  try {
    const { apiEndpointId } = req.params;
    const { 
      page = 1, 
      limit = 20, 
      status,
      startDate,
      endDate 
    } = req.query;

    // Verify API endpoint exists
    const apiEndpoint = await ApiEndpoint.findById(apiEndpointId);
    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    const filter = { apiEndpointId };
    
    if (status) filter.status = status;
    
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const executions = await ApiExecution.find(filter)
      .populate('apiEndpointId', 'name path method')
      .populate('projectId', 'name')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await ApiExecution.countDocuments(filter);

    res.json({
      executions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching API executions:', error);
    res.status(500).json({ 
      error: 'Failed to fetch API executions',
      message: error.message 
    });
  }
};

// Create new API execution
const createApiExecution = async (req, res) => {
  try {
    const {
      apiEndpointId,
      projectId,
      executionId,
      requestData,
      responseData,
      execution,
      metrics,
      status,
      success,
      error
    } = req.body;

    // Validate required fields
    if (!apiEndpointId || !projectId || !executionId) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['apiEndpointId', 'projectId', 'executionId']
      });
    }

    // Verify API endpoint exists
    const apiEndpoint = await ApiEndpoint.findById(apiEndpointId);
    if (!apiEndpoint) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }

    // Verify project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Check if execution ID already exists
    const existingExecution = await ApiExecution.findOne({ executionId });
    if (existingExecution) {
      return res.status(400).json({ 
        error: 'Execution ID already exists',
        executionId 
      });
    }

    const apiExecution = new ApiExecution({
      apiEndpointId,
      projectId,
      executionId,
      requestData: requestData || {},
      responseData: responseData || {},
      execution: execution || {
        upstreamCalls: [],
        ruleExecutions: [],
        transformationExecutions: [],
        storageOperations: []
      },
      metrics: metrics || {
        totalExecutionTime: 0,
        upstreamCallsCount: 0,
        rulesExecutedCount: 0,
        transformationsCount: 0,
        storageOperationsCount: 0
      },
      status: status || 'pending',
      success: success || false,
      error: error || null
    });

    const savedExecution = await apiExecution.save();
    res.status(201).json(savedExecution);
  } catch (error) {
    console.error('Error creating API execution:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to create API execution',
      message: error.message 
    });
  }
};

// Update API execution
const updateApiExecution = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Remove fields that shouldn't be updated directly
    delete updateData._id;
    delete updateData.createdAt;
    delete updateData.__v;
    delete updateData.executionId; // Execution ID should not be changed

    // If updating status to completed or failed, set completedAt
    if (updateData.status === 'completed' || updateData.status === 'failed') {
      updateData.completedAt = new Date();
    }

    const execution = await ApiExecution.findByIdAndUpdate(
      id,
      { ...updateData, updatedAt: new Date() },
      { new: true, runValidators: true }
    ).populate('apiEndpointId', 'name path method')
     .populate('projectId', 'name');

    if (!execution) {
      return res.status(404).json({ error: 'API execution not found' });
    }

    res.json(execution);
  } catch (error) {
    console.error('Error updating API execution:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: Object.values(error.errors).map(err => err.message)
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to update API execution',
      message: error.message 
    });
  }
};

// Delete API execution
const deleteApiExecution = async (req, res) => {
  try {
    const { id } = req.params;

    const execution = await ApiExecution.findByIdAndDelete(id);
    
    if (!execution) {
      return res.status(404).json({ error: 'API execution not found' });
    }

    res.json({ 
      message: 'API execution deleted successfully',
      deletedExecution: { 
        id: execution._id, 
        executionId: execution.executionId,
        apiEndpointId: execution.apiEndpointId 
      }
    });
  } catch (error) {
    console.error('Error deleting API execution:', error);
    res.status(500).json({ 
      error: 'Failed to delete API execution',
      message: error.message 
    });
  }
};

// Get execution statistics
const getExecutionStats = async (req, res) => {
  try {
    const { 
      apiEndpointId, 
      projectId, 
      days = 7 
    } = req.query;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - parseInt(days));

    const matchFilter = {
      createdAt: { $gte: startDate, $lte: endDate }
    };

    if (apiEndpointId) matchFilter.apiEndpointId = apiEndpointId;
    if (projectId) matchFilter.projectId = projectId;

    const stats = await ApiExecution.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: null,
          totalExecutions: { $sum: 1 },
          successfulExecutions: { $sum: { $cond: ['$success', 1, 0] } },
          failedExecutions: { $sum: { $cond: ['$success', 0, 1] } },
          avgExecutionTime: { $avg: '$metrics.totalExecutionTime' },
          totalUpstreamCalls: { $sum: '$metrics.upstreamCallsCount' },
          totalTransformations: { $sum: '$metrics.transformationsCount' },
          totalStorageOperations: { $sum: '$metrics.storageOperationsCount' }
        }
      }
    ]);

    const result = stats[0] || {
      totalExecutions: 0,
      successfulExecutions: 0,
      failedExecutions: 0,
      avgExecutionTime: 0,
      totalUpstreamCalls: 0,
      totalTransformations: 0,
      totalStorageOperations: 0
    };

    // Calculate success rate
    result.successRate = result.totalExecutions > 0 
      ? (result.successfulExecutions / result.totalExecutions) * 100 
      : 0;

    res.json(result);
  } catch (error) {
    console.error('Error fetching execution stats:', error);
    res.status(500).json({ 
      error: 'Failed to fetch execution statistics',
      message: error.message 
    });
  }
};

// Get recent executions
const getRecentExecutions = async (req, res) => {
  try {
    const { limit = 10, apiEndpointId, projectId } = req.query;

    const filter = {};
    if (apiEndpointId) filter.apiEndpointId = apiEndpointId;
    if (projectId) filter.projectId = projectId;

    const executions = await ApiExecution.find(filter)
      .populate('apiEndpointId', 'name path method')
      .populate('projectId', 'name')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .select('executionId status success metrics.totalExecutionTime createdAt');

    res.json(executions);
  } catch (error) {
    console.error('Error fetching recent executions:', error);
    res.status(500).json({ 
      error: 'Failed to fetch recent executions',
      message: error.message 
    });
  }
};

module.exports = {
  getAllApiExecutions,
  getApiExecutionById,
  getApiExecutionByExecutionId,
  getExecutionsByApiEndpoint,
  createApiExecution,
  updateApiExecution,
  deleteApiExecution,
  getExecutionStats,
  getRecentExecutions
};