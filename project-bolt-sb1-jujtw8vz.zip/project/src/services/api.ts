import { Project, ApiEndpoint } from '../types';

// Mock data
const mockProjects: Project[] = [
  {
    id: '1',
    name: 'E-commerce API Gateway',
    description: 'API orchestration for e-commerce platform',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
    status: 'active',
    apiCount: 12,
  },
  {
    id: '2',
    name: 'Payment Processing',
    description: 'Payment gateway integration and processing',
    createdAt: '2024-01-14T09:30:00Z',
    updatedAt: '2024-01-14T09:30:00Z',
    status: 'active',
    apiCount: 8,
  },
  {
    id: '3',
    name: 'User Management System',
    description: 'Authentication and user management APIs',
    createdAt: '2024-01-13T14:15:00Z',
    updatedAt: '2024-01-13T14:15:00Z',
    status: 'inactive',
    apiCount: 15,
  },
];

const mockApis: ApiEndpoint[] = [
  {
    id: '1',
    projectId: '1',
    name: 'Create Order',
    path: '/api/orders',
    method: 'POST',
    description: 'Creates a new order with payment processing',
    configuration: {
      upstreamApis: [
        {
          id: 'upstream-call-1',
          apiEndpointId: 'user-service-api-1',
          order: 1,
          customHeaders: { 'Authorization': 'Bearer {{"USER_SERVICE_TOKEN"}}' },
          customTimeout: 3000,
          customRetries: 2,
          condition: 'request.userId && request.userId.length > 0',
          nextSteps: ['upstream-call-2']
        },
        {
          id: 'upstream-call-2',
          apiEndpointId: 'payment-gateway-api-1',
          order: 2,
          customHeaders: { 'Authorization': 'Bearer {{"PAYMENT_TOKEN"}}', 'Content-Type': 'application/json' },
          customBody: '{"amount": "{{"request.amount"}}", "currency": "USD", "customer": "{{"upstream.user-service.response.customerId"}}"}',
          customTimeout: 10000,
          customRetries: 3,
          condition: 'upstream["user-service"].response.status === 200',
          nextSteps: ['upstream-call-3']
        },
        {
          id: 'upstream-call-3',
          apiEndpointId: 'notification-service-api-1',
          order: 3,
          customHeaders: { 'Authorization': 'Bearer {{"NOTIFICATION_TOKEN"}}', 'Content-Type': 'application/json' },
          customBody: '{"to": "{{"upstream.user-service.response.email"}}", "template": "order_confirmation", "data": {"orderId": "{{"upstream.payment-gateway.response.orderId"}}"}}',
          customTimeout: 5000,
          customRetries: 1,
          condition: 'upstream["payment-gateway"].response.status === 200',
          nextSteps: []
        }
      ],
      rules: [],
      transformations: [],
      storage: {
        enabled: true,
        database: 'ecommerce',
        collection: 'orders',
        fields: [],
      },
    },
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
    status: 'active',
  },
  {
    id: '2',
    projectId: '1',
    name: 'Get User Profile',
    path: '/api/users/:id',
    method: 'GET',
    description: 'Retrieves user profile with aggregated data',
    configuration: {
      upstreamApis: [
        {
          id: 'upstream-call-4',
          apiEndpointId: 'user-db-service-api-1',
          order: 1,
          customHeaders: { 'Authorization': 'Bearer {{"DB_SERVICE_TOKEN"}}' },
          customTimeout: 2000,
          customRetries: 2,
          condition: 'request.params.id',
          nextSteps: ['upstream-call-5']
        },
        {
          id: 'upstream-call-5',
          apiEndpointId: 'preferences-service-api-1',
          order: 2,
          customHeaders: { 'Authorization': 'Bearer {{"PREFERENCES_TOKEN"}}' },
          customTimeout: 3000,
          customRetries: 1,
          condition: 'upstream["user-database-service"].response.status === 200',
          nextSteps: []
        }
      ],
      rules: [],
      transformations: [],
      storage: {
        enabled: false,
        database: '',
        collection: '',
        fields: [],
      },
    },
    createdAt: '2024-01-15T10:30:00Z',
    updatedAt: '2024-01-15T10:30:00Z',
    status: 'active',
  },
];

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const projectService = {
  getAll: async (): Promise<Project[]> => {
    await delay(500);
    return mockProjects;
  },

  getById: async (id: string): Promise<Project | null> => {
    await delay(300);
    return mockProjects.find(p => p.id === id) || null;
  },

  create: async (data: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'apiCount'>): Promise<Project> => {
    await delay(800);
    const newProject: Project = {
      ...data,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      apiCount: 0,
    };
    mockProjects.push(newProject);
    return newProject;
  },

  update: async (id: string, data: Partial<Project>): Promise<Project> => {
    await delay(600);
    const index = mockProjects.findIndex(p => p.id === id);
    if (index === -1) throw new Error('Project not found');
    
    mockProjects[index] = {
      ...mockProjects[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    return mockProjects[index];
  },

  delete: async (id: string): Promise<void> => {
    await delay(400);
    const index = mockProjects.findIndex(p => p.id === id);
    if (index === -1) throw new Error('Project not found');
    mockProjects.splice(index, 1);
  },
};

export const apiService = {
  getByProjectId: async (projectId: string): Promise<ApiEndpoint[]> => {
    await delay(400);
    return mockApis.filter(api => api.projectId === projectId);
  },

  getById: async (id: string): Promise<ApiEndpoint | null> => {
    await delay(300);
    return mockApis.find(api => api.id === id) || null;
  },

  create: async (data: Omit<ApiEndpoint, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiEndpoint> => {
    await delay(800);
    const newApi: ApiEndpoint = {
      ...data,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockApis.push(newApi);
    return newApi;
  },

  update: async (id: string, data: Partial<ApiEndpoint>): Promise<ApiEndpoint> => {
    await delay(600);
    const index = mockApis.findIndex(api => api.id === id);
    if (index === -1) throw new Error('API not found');
    
    mockApis[index] = {
      ...mockApis[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    return mockApis[index];
  },

  delete: async (id: string): Promise<void> => {
    await delay(400);
    const index = mockApis.findIndex(api => api.id === id);
    if (index === -1) throw new Error('API not found');
    mockApis.splice(index, 1);
  },
};