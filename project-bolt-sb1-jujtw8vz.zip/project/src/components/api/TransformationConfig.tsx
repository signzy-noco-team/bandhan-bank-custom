import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Edit, Code, RefreshCw } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Modal } from '../ui/Modal';
import { MonacoEditor } from './MonacoEditor';
import { Transformation } from '../../types';

interface TransformationConfigProps {
  transformations: Transformation[];
  onChange: (transformations: Transformation[]) => void;
}

export const TransformationConfig: React.FC<TransformationConfigProps> = ({
  transformations,
  onChange,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [editingTransformation, setEditingTransformation] = useState<Transformation | null>(null);
  const [formData, setFormData] = useState<Partial<Transformation>>({
    type: 'json-to-xml',
    configuration: {},
  });

  const handleAddTransformation = () => {
    setEditingTransformation(null);
    setFormData({
      type: 'json-to-xml',
      configuration: {},
    });
    setShowModal(true);
  };

  const handleEditTransformation = (transformation: Transformation) => {
    setEditingTransformation(transformation);
    setFormData(transformation);
    setShowModal(true);
  };

  const handleSaveTransformation = () => {
    if (!formData.name || !formData.type) return;

    const newTransformation: Transformation = {
      id: editingTransformation?.id || Math.random().toString(36).substr(2, 9),
      name: formData.name!,
      type: formData.type!,
      configuration: formData.configuration || {},
    };

    if (editingTransformation) {
      onChange(transformations.map(t => t.id === editingTransformation.id ? newTransformation : t));
    } else {
      onChange([...transformations, newTransformation]);
    }

    setShowModal(false);
  };

  const handleDeleteTransformation = (id: string) => {
    onChange(transformations.filter(t => t.id !== id));
  };

  const transformationTypes = [
    { value: 'xml-to-json', label: 'XML to JSON', description: 'Convert XML response to JSON' },
    { value: 'text-to-json', label: 'Text to JSON', description: 'Parse text response into JSON structure' },
    { value: 'json-to-xml', label: 'JSON to XML', description: 'Convert JSON response to XML' },
    { value: 'custom', label: 'Custom Script', description: 'Custom JavaScript transformation' },
  ];

  const typeColors = {
    'xml-to-json': 'bg-green-600',
    'text-to-json': 'bg-blue-600',
    'json-to-xml': 'bg-yellow-600',
    'custom': 'bg-purple-600',
  };

  const getDefaultConfig = (type: string) => {
    switch (type) {
      case 'xml-to-json':
        return {
          preserveAttributes: true,
          arrayElements: ['items', 'products'],
          textKey: '_text',
          attributeKey: '_attributes'
        };
      case 'text-to-json':
        return {
          delimiter: '\n',
          keyMapping: {
            'line1': 'title',
            'line2': 'description'
          }
        };
      case 'json-to-xml':
        return {
          rootElement: 'root',
          arrayWrapper: 'items',
          includeHeader: true
        };
      case 'custom':
        return {
          script: `// Custom transformation script
function transform(input, context) {
  // Your transformation logic here
  return {
    ...input,
    transformed: true,
    timestamp: new Date().toISOString()
  };
}`
        };
      default:
        return {};
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-white">Response Transformations</h3>
          <p className="text-gray-400 text-sm">Configure data format conversions and custom transformations</p>
        </div>
        <Button onClick={handleAddTransformation} icon={<Plus className="w-4 h-4" />}>
          Add Transformation
        </Button>
      </div>

      <AnimatePresence>
        {transformations.length === 0 ? (
          <Card className="text-center py-12">
            <RefreshCw className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">No transformations configured</p>
            <Button onClick={handleAddTransformation}>Add Your First Transformation</Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {transformations.map((transformation, index) => (
              <motion.div
                key={transformation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="relative group">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="text-sm text-gray-400">#{index + 1}</span>
                        <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${typeColors[transformation.type]}`}>
                          {transformation.type.toUpperCase()}
                        </span>
                        <h4 className="text-white font-medium">{transformation.name}</h4>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-gray-400 text-sm">
                          {transformationTypes.find(t => t.value === transformation.type)?.description}
                        </p>
                        
                        {Object.keys(transformation.configuration).length > 0 && (
                          <div className="flex items-start space-x-2">
                            <span className="text-gray-400 text-sm mt-1">Config:</span>
                            <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs flex-1">
                              {JSON.stringify(transformation.configuration, null, 2).substring(0, 100)}...
                            </code>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditTransformation(transformation)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteTransformation(transformation.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingTransformation ? 'Edit Transformation' : 'Add Transformation'}
        size="xl"
      >
        <div className="space-y-6">
          <Input
            label="Transformation Name"
            placeholder="XML to JSON Converter"
            value={formData.name || ''}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />

          <Select
            label="Transformation Type"
            options={transformationTypes}
            value={formData.type || 'json-to-xml'}
            onChange={(e) => {
              const newType = e.target.value as any;
              setFormData({ 
                ...formData, 
                type: newType,
                configuration: getDefaultConfig(newType)
              });
            }}
          />

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Configuration
            </label>
            <MonacoEditor
              value={JSON.stringify(formData.configuration || {}, null, 2)}
              onChange={(value) => {
                try {
                  setFormData({ ...formData, configuration: JSON.parse(value) });
                } catch (e) {
                  // Invalid JSON, keep previous value
                }
              }}
              language={formData.type === 'custom' ? 'javascript' : 'json'}
              height="300px"
            />
          </div>

          <div className="bg-gray-900 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-300 mb-2">Transformation Examples:</h4>
            <div className="space-y-2 text-xs text-gray-400">
              <div><strong>XML to JSON:</strong> Converts XML responses to JSON with configurable attribute handling</div>
              <div><strong>Text to JSON:</strong> Parses structured text (CSV, logs) into JSON objects</div>
              <div><strong>JSON to XML:</strong> Converts JSON responses to XML format with custom root elements</div>
              <div><strong>Custom Script:</strong> JavaScript function for complex data transformations</div>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveTransformation}>
              {editingTransformation ? 'Update Transformation' : 'Add Transformation'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};