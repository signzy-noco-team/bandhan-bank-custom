import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Edit, Filter, AlertTriangle } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Textarea } from '../ui/Textarea';
import { Modal } from '../ui/Modal';
import { MonacoEditor } from './MonacoEditor';
import { Rule } from '../../types';

interface RuleConfigProps {
  rules: Rule[];
  onChange: (rules: Rule[]) => void;
}

export const RuleConfig: React.FC<RuleConfigProps> = ({
  rules,
  onChange,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [formData, setFormData] = useState<Partial<Rule>>({
    action: 'continue',
    parameters: {},
  });

  const handleAddRule = () => {
    setEditingRule(null);
    setFormData({
      action: 'continue',
      parameters: {},
    });
    setShowModal(true);
  };

  const handleEditRule = (rule: Rule) => {
    setEditingRule(rule);
    setFormData(rule);
    setShowModal(true);
  };

  const handleSaveRule = () => {
    if (!formData.name || !formData.condition) return;

    const newRule: Rule = {
      id: editingRule?.id || Math.random().toString(36).substr(2, 9),
      name: formData.name!,
      condition: formData.condition!,
      action: formData.action!,
      parameters: formData.parameters || {},
    };

    if (editingRule) {
      onChange(rules.map(rule => rule.id === editingRule.id ? newRule : rule));
    } else {
      onChange([...rules, newRule]);
    }

    setShowModal(false);
  };

  const handleDeleteRule = (id: string) => {
    onChange(rules.filter(rule => rule.id !== id));
  };

  const actionColors = {
    continue: 'bg-green-600',
    stop: 'bg-red-600',
    redirect: 'bg-blue-600',
    transform: 'bg-purple-600',
  };

  const actionIcons = {
    continue: '→',
    stop: '⏹',
    redirect: '↗',
    transform: '⚡',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-white">Rules & Conditions</h3>
          <p className="text-gray-400 text-sm">Define conditional logic for API execution flow</p>
        </div>
        <Button onClick={handleAddRule} icon={<Plus className="w-4 h-4" />}>
          Add Rule
        </Button>
      </div>

      <AnimatePresence>
        {rules.length === 0 ? (
          <Card className="text-center py-12">
            <Filter className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">No rules configured</p>
            <Button onClick={handleAddRule}>Add Your First Rule</Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {rules.map((rule, index) => (
              <motion.div
                key={rule.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="relative group">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="text-sm text-gray-400">#{index + 1}</span>
                        <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${actionColors[rule.action]} flex items-center space-x-1`}>
                          <span>{actionIcons[rule.action]}</span>
                          <span>{rule.action.toUpperCase()}</span>
                        </span>
                        <h4 className="text-white font-medium">{rule.name}</h4>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-start space-x-2">
                          <span className="text-gray-400 text-sm mt-1">Condition:</span>
                          <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs flex-1">
                            {rule.condition}
                          </code>
                        </div>
                        
                        {Object.keys(rule.parameters).length > 0 && (
                          <div className="flex items-start space-x-2">
                            <span className="text-gray-400 text-sm mt-1">Parameters:</span>
                            <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs flex-1">
                              {JSON.stringify(rule.parameters)}
                            </code>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditRule(rule)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteRule(rule.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingRule ? 'Edit Rule' : 'Add Rule'}
        size="xl"
      >
        <div className="space-y-6">
          <Input
            label="Rule Name"
            placeholder="Check user authentication"
            value={formData.name || ''}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />

          <Select
            label="Action"
            options={[
              { value: 'continue', label: 'Continue - Proceed to next step' },
              { value: 'stop', label: 'Stop - Halt execution' },
              { value: 'redirect', label: 'Redirect - Jump to specific step' },
              { value: 'transform', label: 'Transform - Modify response' },
            ]}
            value={formData.action || 'continue'}
            onChange={(e) => setFormData({ ...formData, action: e.target.value as any })}
          />

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Condition Expression
            </label>
            <div className="mb-2">
              <div className="flex items-center space-x-2 text-xs text-gray-400 mb-2">
                <AlertTriangle className="w-3 h-3" />
                <span>Use JavaScript expressions. Available variables: request, response, context</span>
              </div>
            </div>
            <MonacoEditor
              value={formData.condition || ''}
              onChange={(value) => setFormData({ ...formData, condition: value })}
              language="javascript"
              height="150px"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Action Parameters (JSON)
            </label>
            <MonacoEditor
              value={JSON.stringify(formData.parameters || {}, null, 2)}
              onChange={(value) => {
                try {
                  setFormData({ ...formData, parameters: JSON.parse(value) });
                } catch (e) {
                  // Invalid JSON, keep previous value
                }
              }}
              language="json"
              height="150px"
            />
          </div>

          <div className="bg-gray-900 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-300 mb-2">Example Conditions:</h4>
            <div className="space-y-1 text-xs text-gray-400">
              <div><code>response.status === 200</code> - Check HTTP status</div>
              <div><code>request.headers.authorization</code> - Check auth header</div>
              <div><code>response.data.user.role === 'admin'</code> - Check user role</div>
              <div><code>context.retryCount &lt; 3</code> - Check retry attempts</div>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveRule}>
              {editingRule ? 'Update Rule' : 'Add Rule'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};