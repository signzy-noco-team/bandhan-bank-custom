import React from 'react';
import { Zap, Clock, AlertCircle } from 'lucide-react';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Checkbox } from '../ui/Checkbox';
import { QueueConfig as QueueConfigType } from '../../types';

interface QueueConfigProps {
  config?: QueueConfigType;
  onChange: (config?: QueueConfigType) => void;
}

export const QueueConfig: React.FC<QueueConfigProps> = ({
  config,
  onChange,
}) => {
  const handleToggleQueue = (enabled: boolean) => {
    if (enabled) {
      onChange({
        enabled: true,
        queueName: 'api-queue',
        priority: 1,
        delay: 0,
      });
    } else {
      onChange(undefined);
    }
  };

  const handleConfigChange = (key: keyof QueueConfigType, value: any) => {
    if (!config) return;
    onChange({ ...config, [key]: value });
  };

  const priorityOptions = [
    { value: '1', label: 'Low Priority (1)' },
    { value: '5', label: 'Normal Priority (5)' },
    { value: '10', label: 'High Priority (10)' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-white">Queue Configuration</h3>
          <p className="text-gray-400 text-sm">Configure fire-and-forget API processing with queues</p>
        </div>
        <Checkbox
          label="Enable Queue Processing"
          checked={!!config?.enabled}
          onChange={(e) => handleToggleQueue(e.target.checked)}
        />
      </div>

      {config?.enabled ? (
        <div className="space-y-6">
          <Card>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Queue Name"
                  placeholder="api-processing-queue"
                  value={config.queueName}
                  onChange={(e) => handleConfigChange('queueName', e.target.value)}
                />
                <Select
                  label="Priority Level"
                  options={priorityOptions}
                  value={config.priority.toString()}
                  onChange={(e) => handleConfigChange('priority', parseInt(e.target.value))}
                />
              </div>

              <Input
                label="Delay (seconds)"
                type="number"
                placeholder="0"
                helperText="Delay before processing the queued job"
                value={config.delay || ''}
                onChange={(e) => handleConfigChange('delay', parseInt(e.target.value) || 0)}
              />
            </div>
          </Card>

          <Card>
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-white mb-2">Queue Processing Notes</h4>
                <div className="space-y-2 text-sm text-gray-400">
                  <p>• Queued APIs are processed asynchronously and don't return immediate responses</p>
                  <p>• Use queues for fire-and-forget operations like logging, notifications, or data processing</p>
                  <p>• Higher priority jobs are processed first</p>
                  <p>• Delays can be useful for rate limiting or scheduled processing</p>
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <h4 className="text-md font-medium text-white mb-4">Queue Statistics</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-gray-900 rounded-lg">
                <div className="text-2xl font-bold text-blue-400">24</div>
                <div className="text-sm text-gray-400">Pending Jobs</div>
              </div>
              <div className="text-center p-4 bg-gray-900 rounded-lg">
                <div className="text-2xl font-bold text-green-400">156</div>
                <div className="text-sm text-gray-400">Completed Today</div>
              </div>
              <div className="text-center p-4 bg-gray-900 rounded-lg">
                <div className="text-2xl font-bold text-red-400">2</div>
                <div className="text-sm text-gray-400">Failed Jobs</div>
              </div>
            </div>
          </Card>
        </div>
      ) : (
        <Card className="text-center py-12">
          <Zap className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400 mb-4">Queue processing is disabled</p>
          <p className="text-gray-500 text-sm">Enable queue processing for asynchronous API execution</p>
        </Card>
      )}
    </div>
  );
};