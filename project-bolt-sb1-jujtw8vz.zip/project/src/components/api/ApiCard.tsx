import React from 'react';
import { motion } from 'framer-motion';
import { Globe, Clock, MoreVertical, Activity, FileText } from 'lucide-react';
import { ApiEndpoint } from '../../types';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';

interface ApiCardProps {
  api: ApiEndpoint;
  onEdit: (api: ApiEndpoint) => void;
  onDelete: (api: ApiEndpoint) => void;
  onView: (api: ApiEndpoint) => void;
}

const methodColors = {
  GET: 'bg-green-600',
  POST: 'bg-blue-600',
  PUT: 'bg-yellow-600',
  DELETE: 'bg-red-600',
  PATCH: 'bg-purple-600',
};

export const ApiCard: React.FC<ApiCardProps> = ({
  api,
  onEdit,
  onDelete,
  onView,
}) => {
  return (
    <Card hover onClick={() => onView(api)} className="relative group">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${methodColors[api.method]}`}>
              {api.method}
            </span>
            <h3 className="text-lg font-semibold text-white">{api.name}</h3>
          </div>
          
          <div className="flex items-center space-x-2 mb-3">
            <Globe className="w-4 h-4 text-gray-400" />
            <code className="text-sm text-gray-300 bg-gray-900 px-2 py-1 rounded">
              {api.path}
            </code>
          </div>
          
          <p className="text-gray-400 text-sm mb-4">
            {api.description}
          </p>
          
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{new Date(api.updatedAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${
            api.status === 'active' ? 'bg-green-500' : 'bg-gray-500'
          }`} />
          
          <div className="opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                // Handle dropdown menu
              }}
            >
              <MoreVertical className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              // Navigate to executions
              window.location.href = `/projects/${api.projectId}/apis/${api.id}/executions`;
            }}
            title="View Executions"
          >
            <Activity className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              // Navigate to logs
              window.location.href = `/projects/${api.projectId}/apis/${api.id}/logs`;
            }}
            title="View Logs"
          >
            <FileText className="w-3 h-3" />
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(api);
            }}
          >
            Edit
          </Button>
          <Button
            variant="danger"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(api);
            }}
          >
            Delete
          </Button>
        </div>
      </div>
    </Card>
  );
};