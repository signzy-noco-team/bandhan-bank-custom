import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { motion } from 'framer-motion';
import { apiEndpointSchema, ApiEndpointFormData } from '../../utils/validation';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { ApiEndpoint } from '../../types';

interface ApiFormProps {
  api?: ApiEndpoint;
  onSubmit: (data: ApiEndpointFormData) => void;
  onCancel: () => void;
  loading?: boolean;
}

export const ApiForm: React.FC<ApiFormProps> = ({
  api,
  onSubmit,
  onCancel,
  loading = false,
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ApiEndpointFormData>({
    resolver: zodResolver(apiEndpointSchema),
    defaultValues: api ? {
      name: api.name,
      path: api.path,
      method: api.method,
      description: api.description,
      status: api.status,
    } : {
      method: 'GET',
      status: 'active',
    },
  });

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-6"
    >
      <Input
        label="API Name"
        placeholder="Enter API name"
        error={errors.name?.message}
        {...register('name')}
      />

      <Input
        label="API Path"
        placeholder="/api/example"
        error={errors.path?.message}
        {...register('path')}
      />

      <Select
        label="HTTP Method"
        options={[
          { value: 'GET', label: 'GET' },
          { value: 'POST', label: 'POST' },
          { value: 'PUT', label: 'PUT' },
          { value: 'DELETE', label: 'DELETE' },
          { value: 'PATCH', label: 'PATCH' },
        ]}
        error={errors.method?.message}
        {...register('method')}
      />

      <Textarea
        label="Description"
        placeholder="Enter API description"
        rows={4}
        error={errors.description?.message}
        {...register('description')}
      />

      <Select
        label="Status"
        options={[
          { value: 'active', label: 'Active' },
          { value: 'inactive', label: 'Inactive' },
        ]}
        error={errors.status?.message}
        {...register('status')}
      />

      <div className="flex justify-end space-x-4">
        <Button variant="ghost" onClick={onCancel} disabled={loading}>
          Cancel
        </Button>
        <Button type="submit" loading={loading}>
          {api ? 'Update API' : 'Create API'}
        </Button>
      </div>
    </motion.form>
  );
};