import React, { useCallback, useMemo } from 'react';
import {
  ReactFlow,
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  MiniMap,
  Handle,
  Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Card } from '../ui/Card';
import { UpstreamApi, Rule } from '../../types';

interface ApiFlowDiagramProps {
  upstreamApis: UpstreamApi[];
  rules: Rule[];
}

// Custom node component for API calls
const ApiNode: React.FC<{ data: any }> = ({ data }) => {
  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'bg-green-600';
      case 'POST': return 'bg-blue-600';
      case 'PUT': return 'bg-yellow-600';
      case 'DELETE': return 'bg-red-600';
      case 'PATCH': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="bg-gray-800 border border-blue-500 rounded-lg p-4 min-w-[220px] shadow-lg">
      <Handle type="target" position={Position.Top} className="w-3 h-3" />
      
      <div className="flex items-center space-x-2 mb-2">
        <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${getMethodColor(data.method)}`}>
          {data.method}
        </span>
        <span className="text-white font-medium text-sm">{data.name}</span>
        <span className="text-xs text-blue-400 bg-blue-900 px-1 py-0.5 rounded">EXT</span>
      </div>
      
      <div className="text-xs text-gray-300 mb-2 break-all font-mono bg-gray-900 p-1 rounded">
        {data.url}
      </div>
      
      <div className="flex items-center justify-between text-xs text-gray-500">
        <span>Timeout: {data.timeout}ms</span>
        <span>Retries: {data.retries}</span>
      </div>
      
      <Handle type="source" position={Position.Bottom} className="w-3 h-3" />
    </div>
  );
};

// Custom node component for rules/conditions
const RuleNode: React.FC<{ data: any }> = ({ data }) => {
  const getActionColor = (action: string) => {
    switch (action) {
      case 'continue': return 'bg-green-600';
      case 'stop': return 'bg-red-600';
      case 'redirect': return 'bg-blue-600';
      case 'transform': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="bg-gray-700 border border-gray-500 rounded-lg p-3 min-w-[180px]">
      <Handle type="target" position={Position.Top} className="w-3 h-3" />
      
      <div className="flex items-center space-x-2 mb-2">
        <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${getActionColor(data.action)}`}>
          {data.action.toUpperCase()}
        </span>
      </div>
      
      <div className="text-white font-medium text-sm mb-1">{data.name}</div>
      <div className="text-xs text-gray-400 break-all">
        {data.condition.length > 50 ? `${data.condition.substring(0, 50)}...` : data.condition}
      </div>
      
      <Handle type="source" position={Position.Bottom} className="w-3 h-3" />
    </div>
  );
};

// Start and End nodes
const StartNode: React.FC = () => (
  <div className="bg-green-600 border border-green-500 rounded-full w-16 h-16 flex items-center justify-center">
    <span className="text-white font-bold text-sm">START</span>
    <Handle type="source" position={Position.Bottom} className="w-3 h-3" />
  </div>
);

const EndNode: React.FC = () => (
  <div className="bg-red-600 border border-red-500 rounded-full w-16 h-16 flex items-center justify-center">
    <Handle type="target" position={Position.Top} className="w-3 h-3" />
    <span className="text-white font-bold text-sm">END</span>
  </div>
);

const nodeTypes = {
  apiNode: ApiNode,
  ruleNode: RuleNode,
  startNode: StartNode,
  endNode: EndNode,
};

export const ApiFlowDiagram: React.FC<ApiFlowDiagramProps> = ({
  upstreamApis,
  rules,
}) => {
  // Generate nodes and edges from upstream APIs and rules
  const { initialNodes, initialEdges } = useMemo(() => {
    const nodes: Node[] = [];
    const edges: Edge[] = [];

    // Start node
    nodes.push({
      id: 'start',
      type: 'startNode',
      position: { x: 250, y: 50 },
      data: {},
    });

    // API nodes
    upstreamApis.forEach((api, index) => {
      // In a real implementation, you would fetch the actual API endpoint details
      // For now, we'll use mock data based on the apiEndpointId
      const mockApiEndpoint = {
        name: `API ${api.apiEndpointId}`,
        method: 'GET',
        url: `https://api.example.com/${api.apiEndpointId}`,
      };
      
      nodes.push({
        id: api.id,
        type: 'apiNode',
        position: { x: 50 + (index * 300), y: 150 },
        data: {
          name: mockApiEndpoint.name,
          method: mockApiEndpoint.method,
          url: mockApiEndpoint.url,
          timeout: api.customTimeout || 5000,
          retries: api.customRetries || 3,
        },
      });

      // Connect start to first API or previous API to current
      if (index === 0) {
        edges.push({
          id: `start-${api.id}`,
          source: 'start',
          target: api.id,
          animated: true,
        });
      } else {
        edges.push({
          id: `${upstreamApis[index - 1].id}-${api.id}`,
          source: upstreamApis[index - 1].id,
          target: api.id,
          animated: true,
        });
      }
    });

    // Rule nodes
    rules.forEach((rule, index) => {
      const ruleNodeId = `rule-${rule.id}`;
      nodes.push({
        id: ruleNodeId,
        type: 'ruleNode',
        position: { x: 150 + (index * 250), y: 300 },
        data: {
          name: rule.name,
          action: rule.action,
          condition: rule.condition,
        },
      });

      // Connect APIs to rules (simplified connection)
      if (upstreamApis.length > 0) {
        const apiToConnect = upstreamApis[Math.min(index, upstreamApis.length - 1)];
        edges.push({
          id: `${apiToConnect.id}-${ruleNodeId}`,
          source: apiToConnect.id,
          target: ruleNodeId,
          animated: true,
          style: { stroke: '#8B5CF6' },
        });
      }
    });

    // End node
    nodes.push({
      id: 'end',
      type: 'endNode',
      position: { x: 250, y: 450 },
      data: {},
    });

    // Connect last elements to end
    if (rules.length > 0) {
      edges.push({
        id: `rule-${rules[rules.length - 1].id}-end`,
        source: `rule-${rules[rules.length - 1].id}`,
        target: 'end',
        animated: true,
      });
    } else if (upstreamApis.length > 0) {
      edges.push({
        id: `${upstreamApis[upstreamApis.length - 1].id}-end`,
        source: upstreamApis[upstreamApis.length - 1].id,
        target: 'end',
        animated: true,
      });
    } else {
      edges.push({
        id: 'start-end',
        source: 'start',
        target: 'end',
        animated: true,
      });
    }

    return { initialNodes: nodes, initialEdges: edges };
  }, [upstreamApis, rules]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  return (
    <Card className="h-96">
      <div className="h-full">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          fitView
          className="bg-gray-900"
        >
          <Controls className="bg-gray-800 border-gray-600" />
          <MiniMap 
            className="bg-gray-800 border-gray-600"
            nodeColor="#374151"
            maskColor="rgba(0, 0, 0, 0.2)"
          />
          <Background color="#374151" gap={16} />
        </ReactFlow>
      </div>
    </Card>
  );
};