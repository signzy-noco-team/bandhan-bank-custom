import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Edit, Key, Globe, Code } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { Checkbox } from '../ui/Checkbox';
import { Modal } from '../ui/Modal';
import { MonacoEditor } from './MonacoEditor';

interface ApiVariable {
  id: string;
  name: string;
  value: string;
  type: 'string' | 'number' | 'boolean' | 'json';
  description?: string;
  encrypted?: boolean;
}

interface HeaderConfig {
  id: string;
  key: string;
  value: string;
  description?: string;
}

interface ApiSettingsProps {
  variables: ApiVariable[];
  headers: HeaderConfig[];
  requestBody?: string;
  onVariablesChange: (variables: ApiVariable[]) => void;
  onHeadersChange: (headers: HeaderConfig[]) => void;
  onRequestBodyChange: (body: string) => void;
}

export const ApiSettings: React.FC<ApiSettingsProps> = ({
  variables,
  headers,
  requestBody = '',
  onVariablesChange,
  onHeadersChange,
  onRequestBodyChange,
}) => {
  const [activeTab, setActiveTab] = useState('variables');
  const [showVariableModal, setShowVariableModal] = useState(false);
  const [showHeaderModal, setShowHeaderModal] = useState(false);
  const [editingVariable, setEditingVariable] = useState<ApiVariable | null>(null);
  const [editingHeader, setEditingHeader] = useState<HeaderConfig | null>(null);
  const [variableData, setVariableData] = useState<Partial<ApiVariable>>({});
  const [headerData, setHeaderData] = useState<Partial<HeaderConfig>>({});

  const tabs = [
    { id: 'variables', label: 'Variables', icon: <Key className="w-4 h-4" /> },
    { id: 'headers', label: 'Headers', icon: <Globe className="w-4 h-4" /> },
    { id: 'body', label: 'Request Body', icon: <Code className="w-4 h-4" /> },
  ];

  const handleAddVariable = () => {
    setEditingVariable(null);
    setVariableData({ type: 'string', encrypted: false });
    setShowVariableModal(true);
  };

  const handleEditVariable = (variable: ApiVariable) => {
    setEditingVariable(variable);
    setVariableData(variable);
    setShowVariableModal(true);
  };

  const handleSaveVariable = () => {
    if (!variableData.name || !variableData.value) return;

    const newVariable: ApiVariable = {
      id: editingVariable?.id || Math.random().toString(36).substr(2, 9),
      name: variableData.name!,
      value: variableData.value!,
      type: variableData.type || 'string',
      description: variableData.description,
      encrypted: variableData.encrypted || false,
    };

    const updatedVariables = editingVariable
      ? variables.map(v => v.id === editingVariable.id ? newVariable : v)
      : [...variables, newVariable];

    onVariablesChange(updatedVariables);
    setShowVariableModal(false);
  };

  const handleDeleteVariable = (id: string) => {
    onVariablesChange(variables.filter(v => v.id !== id));
  };

  const handleAddHeader = () => {
    setEditingHeader(null);
    setHeaderData({});
    setShowHeaderModal(true);
  };

  const handleEditHeader = (header: HeaderConfig) => {
    setEditingHeader(header);
    setHeaderData(header);
    setShowHeaderModal(true);
  };

  const handleSaveHeader = () => {
    if (!headerData.key || !headerData.value) return;

    const newHeader: HeaderConfig = {
      id: editingHeader?.id || Math.random().toString(36).substr(2, 9),
      key: headerData.key!,
      value: headerData.value!,
      description: headerData.description,
    };

    const updatedHeaders = editingHeader
      ? headers.map(h => h.id === editingHeader.id ? newHeader : h)
      : [...headers, newHeader];

    onHeadersChange(updatedHeaders);
    setShowHeaderModal(false);
  };

  const handleDeleteHeader = (id: string) => {
    onHeadersChange(headers.filter(h => h.id !== id));
  };

  const variableTypeColors = {
    string: 'bg-blue-600',
    number: 'bg-green-600',
    boolean: 'bg-purple-600',
    json: 'bg-orange-600',
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <Card padding="sm">
        <div className="border-b border-gray-700">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm
                  ${activeTab === tab.id
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
                  }
                `}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'variables' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium text-white">API Variables</h3>
                    <p className="text-gray-400 text-sm">Define variables specific to this API</p>
                  </div>
                  <Button onClick={handleAddVariable} icon={<Plus className="w-4 h-4" />}>
                    Add Variable
                  </Button>
                </div>

                {variables.length === 0 ? (
                  <Card className="text-center py-12">
                    <Key className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No variables defined</p>
                    <Button onClick={handleAddVariable}>Add Your First Variable</Button>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {variables.map((variable) => (
                      <Card key={variable.id} padding="sm">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${variableTypeColors[variable.type]}`}>
                                {variable.type.toUpperCase()}
                              </span>
                              <h4 className="text-white font-medium">{variable.name}</h4>
                              {variable.encrypted && (
                                <span className="px-2 py-1 text-xs bg-yellow-600 text-white rounded">
                                  ENCRYPTED
                                </span>
                              )}
                            </div>
                            <div className="flex items-center space-x-4 text-sm">
                              <span className="text-gray-400">Value:</span>
                              <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs">
                                {variable.encrypted ? '••••••••' : variable.value}
                              </code>
                            </div>
                            {variable.description && (
                              <p className="text-gray-400 text-sm mt-1">{variable.description}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => handleEditVariable(variable)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteVariable(variable.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'headers' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium text-white">Request Headers</h3>
                    <p className="text-gray-400 text-sm">Configure HTTP headers for API requests</p>
                  </div>
                  <Button onClick={handleAddHeader} icon={<Plus className="w-4 h-4" />}>
                    Add Header
                  </Button>
                </div>

                {headers.length === 0 ? (
                  <Card className="text-center py-12">
                    <Globe className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No headers configured</p>
                    <Button onClick={handleAddHeader}>Add Your First Header</Button>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {headers.map((header) => (
                      <Card key={header.id} padding="sm">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-4 mb-2">
                              <h4 className="text-white font-medium">{header.key}</h4>
                              <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs">
                                {header.value}
                              </code>
                            </div>
                            {header.description && (
                              <p className="text-gray-400 text-sm">{header.description}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => handleEditHeader(header)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteHeader(header.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'body' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-white">Request Body Template</h3>
                  <p className="text-gray-400 text-sm">Define the request body template for POST/PUT requests</p>
                </div>

                <MonacoEditor
                  value={requestBody}
                  onChange={onRequestBodyChange}
                  language="json"
                  height="400px"
                  label="Request Body (JSON)"
                />

                <div className="bg-gray-900 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-300 mb-2">Template Variables:</h4>
                  <div className="space-y-1 text-xs text-gray-400">
                    <div><code>{'{{variable_name}}'}</code> - Use API variables</div>
                    <div><code>{'{{request.body.field}}'}</code> - Access incoming request data</div>
                    <div><code>{'{{context.timestamp}}'}</code> - Use system variables</div>
                    <div><code>{'{{upstream.api_name.response.field}}'}</code> - Use upstream API responses</div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </Card>

      {/* Variable Modal */}
      <Modal
        isOpen={showVariableModal}
        onClose={() => setShowVariableModal(false)}
        title={editingVariable ? 'Edit Variable' : 'Add Variable'}
        size="lg"
      >
        <div className="space-y-4">
          <Input
            label="Variable Name"
            placeholder="API_KEY"
            value={variableData.name || ''}
            onChange={(e) => setVariableData({ ...variableData, name: e.target.value })}
          />

          <Select
            label="Variable Type"
            options={[
              { value: 'string', label: 'String' },
              { value: 'number', label: 'Number' },
              { value: 'boolean', label: 'Boolean' },
              { value: 'json', label: 'JSON Object' },
            ]}
            value={variableData.type || 'string'}
            onChange={(e) => setVariableData({ ...variableData, type: e.target.value as any })}
          />

          {variableData.type === 'json' ? (
            <MonacoEditor
              label="Variable Value"
              value={variableData.value || '{}'}
              onChange={(value) => setVariableData({ ...variableData, value })}
              language="json"
              height="150px"
            />
          ) : (
            <Input
              label="Variable Value"
              placeholder="your-api-key-here"
              value={variableData.value || ''}
              onChange={(e) => setVariableData({ ...variableData, value: e.target.value })}
            />
          )}

          <Textarea
            label="Description (Optional)"
            placeholder="API key for external service authentication"
            value={variableData.description || ''}
            onChange={(e) => setVariableData({ ...variableData, description: e.target.value })}
          />

          <Checkbox
            label="Encrypt Value"
            description="Store this value encrypted for security"
            checked={variableData.encrypted || false}
            onChange={(e) => setVariableData({ ...variableData, encrypted: e.target.checked })}
          />

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowVariableModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveVariable}>
              {editingVariable ? 'Update Variable' : 'Add Variable'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Header Modal */}
      <Modal
        isOpen={showHeaderModal}
        onClose={() => setShowHeaderModal(false)}
        title={editingHeader ? 'Edit Header' : 'Add Header'}
        size="lg"
      >
        <div className="space-y-4">
          <Input
            label="Header Name"
            placeholder="Authorization"
            value={headerData.key || ''}
            onChange={(e) => setHeaderData({ ...headerData, key: e.target.value })}
          />

          <Input
            label="Header Value"
            placeholder="Bearer {{API_TOKEN}}"
            value={headerData.value || ''}
            onChange={(e) => setHeaderData({ ...headerData, value: e.target.value })}
          />

          <Textarea
            label="Description (Optional)"
            placeholder="Authorization header with bearer token"
            value={headerData.description || ''}
            onChange={(e) => setHeaderData({ ...headerData, description: e.target.value })}
          />

          <div className="bg-gray-900 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-300 mb-2">Common Headers:</h4>
            <div className="space-y-1 text-xs text-gray-400">
              <div><strong>Authorization:</strong> Bearer {'{{API_TOKEN}}'}</div>
              <div><strong>Content-Type:</strong> application/json</div>
              <div><strong>Accept:</strong> application/json</div>
              <div><strong>User-Agent:</strong> API-Orchestrator/1.0</div>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowHeaderModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveHeader}>
              {editingHeader ? 'Update Header' : 'Add Header'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};