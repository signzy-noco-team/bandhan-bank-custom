import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Database, Plus, Trash2, Edit } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Checkbox } from '../ui/Checkbox';
import { Textarea } from '../ui/Textarea';
import { Modal } from '../ui/Modal';
import { StorageConfig as StorageConfigType, StorageField } from '../../types';

interface StorageConfigProps {
  config: StorageConfigType;
  onChange: (config: StorageConfigType) => void;
}

export const StorageConfig: React.FC<StorageConfigProps> = ({
  config,
  onChange,
}) => {
  const [showFieldModal, setShowFieldModal] = useState(false);
  const [editingField, setEditingField] = useState<StorageField | null>(null);
  const [fieldData, setFieldData] = useState<Partial<StorageField>>({});

  const handleToggleStorage = (enabled: boolean) => {
    onChange({ ...config, enabled });
  };

  const handleConfigChange = (key: keyof StorageConfigType, value: any) => {
    onChange({ ...config, [key]: value });
  };

  const handleAddField = () => {
    setEditingField(null);
    setFieldData({});
    setShowFieldModal(true);
  };

  const handleEditField = (field: StorageField) => {
    setEditingField(field);
    setFieldData(field);
    setShowFieldModal(true);
  };

  const handleSaveField = () => {
    if (!fieldData.sourceField || !fieldData.targetField) return;

    const newField: StorageField = {
      id: editingField?.id || Math.random().toString(36).substr(2, 9),
      sourceField: fieldData.sourceField!,
      targetField: fieldData.targetField!,
      transform: fieldData.transform,
    };

    const updatedFields = editingField
      ? config.fields.map(f => f.id === editingField.id ? newField : f)
      : [...config.fields, newField];

    onChange({ ...config, fields: updatedFields });
    setShowFieldModal(false);
  };

  const handleDeleteField = (id: string) => {
    onChange({
      ...config,
      fields: config.fields.filter(f => f.id !== id)
    });
  };

  const databases = [
    { value: 'mongodb', label: 'MongoDB' },
    { value: 'postgresql', label: 'PostgreSQL' },
    { value: 'mysql', label: 'MySQL' },
    { value: 'redis', label: 'Redis' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-white">Storage Configuration</h3>
          <p className="text-gray-400 text-sm">Configure database storage for API responses</p>
        </div>
        <Checkbox
          label="Enable Storage"
          checked={config.enabled}
          onChange={(e) => handleToggleStorage(e.target.checked)}
        />
      </div>

      {config.enabled ? (
        <div className="space-y-6">
          <Card>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Database Type"
                  options={databases}
                  value={config.database}
                  onChange={(e) => handleConfigChange('database', e.target.value)}
                />
                <Input
                  label="Collection/Table Name"
                  placeholder="api_responses"
                  value={config.collection}
                  onChange={(e) => handleConfigChange('collection', e.target.value)}
                />
              </div>

              <Textarea
                label="Storage Condition (Optional)"
                placeholder="response.status === 200 && response.data.success"
                helperText="JavaScript expression to determine when to store data"
                value={config.condition || ''}
                onChange={(e) => handleConfigChange('condition', e.target.value)}
              />
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-md font-medium text-white">Field Mapping</h4>
                <p className="text-gray-400 text-sm">Map response fields to database columns</p>
              </div>
              <Button onClick={handleAddField} size="sm" icon={<Plus className="w-4 h-4" />}>
                Add Field
              </Button>
            </div>

            {config.fields.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Database className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No field mappings configured</p>
              </div>
            ) : (
              <div className="space-y-3">
                {config.fields.map((field, index) => (
                  <motion.div
                    key={field.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-3 bg-gray-900 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-400">Source:</span>
                          <code className="text-sm text-blue-400">{field.sourceField}</code>
                        </div>
                        <span className="text-gray-500">→</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-400">Target:</span>
                          <code className="text-sm text-green-400">{field.targetField}</code>
                        </div>
                        {field.transform && (
                          <>
                            <span className="text-gray-500">|</span>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-gray-400">Transform:</span>
                              <code className="text-sm text-purple-400">{field.transform}</code>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditField(field)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteField(field.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </Card>
        </div>
      ) : (
        <Card className="text-center py-12">
          <Database className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400 mb-4">Storage is disabled</p>
          <p className="text-gray-500 text-sm">Enable storage to configure database persistence</p>
        </Card>
      )}

      <Modal
        isOpen={showFieldModal}
        onClose={() => setShowFieldModal(false)}
        title={editingField ? 'Edit Field Mapping' : 'Add Field Mapping'}
        size="lg"
      >
        <div className="space-y-4">
          <Input
            label="Source Field Path"
            placeholder="response.data.user.id"
            helperText="JSONPath to the field in the API response"
            value={fieldData.sourceField || ''}
            onChange={(e) => setFieldData({ ...fieldData, sourceField: e.target.value })}
          />

          <Input
            label="Target Database Field"
            placeholder="user_id"
            helperText="Column name in the database table"
            value={fieldData.targetField || ''}
            onChange={(e) => setFieldData({ ...fieldData, targetField: e.target.value })}
          />

          <Textarea
            label="Transform Expression (Optional)"
            placeholder="value.toLowerCase()"
            helperText="JavaScript expression to transform the value before storage"
            value={fieldData.transform || ''}
            onChange={(e) => setFieldData({ ...fieldData, transform: e.target.value })}
          />

          <div className="bg-gray-900 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-300 mb-2">Examples:</h4>
            <div className="space-y-1 text-xs text-gray-400">
              <div><strong>Source:</strong> <code>response.data.user.email</code></div>
              <div><strong>Target:</strong> <code>email_address</code></div>
              <div><strong>Transform:</strong> <code>value.toLowerCase().trim()</code></div>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowFieldModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveField}>
              {editingField ? 'Update Field' : 'Add Field'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};