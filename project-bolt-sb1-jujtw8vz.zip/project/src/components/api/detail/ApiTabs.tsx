import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Settings, GitBranch, Filter, Code, Database, Zap, Play } from 'lucide-react';
import { Card } from '../../ui/Card';

interface Tab {
  id: string;
  label: string;
  icon: React.ReactNode;
  description?: string;
}

interface ApiTabsProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export const ApiTabs: React.FC<ApiTabsProps> = ({ activeTab, onTabChange }) => {
  const tabs: Tab[] = [
    { id: 'flow', label: 'Flow Diagram', icon: <Eye className="w-4 h-4" />, description: 'Visual flow' },
    { id: 'settings', label: 'API Settings', icon: <Settings className="w-4 h-4" />, description: 'Variables & headers' },
    { id: 'upstream', label: 'Upstream APIs', icon: <GitBranch className="w-4 h-4" />, description: 'External API calls' },
    { id: 'rules', label: 'Rules & Conditions', icon: <Filter className="w-4 h-4" />, description: 'Conditional logic' },
    { id: 'transformations', label: 'Transformations', icon: <Code className="w-4 h-4" />, description: 'Data transforms' },
    { id: 'storage', label: 'Storage', icon: <Database className="w-4 h-4" />, description: 'Database config' },
    { id: 'queue', label: 'Queue Config', icon: <Zap className="w-4 h-4" />, description: 'Async processing' },
    { id: 'test', label: 'Test & Debug', icon: <Play className="w-4 h-4" />, description: 'Test API' },
  ];

  return (
    <Card padding="sm">
      <div className="border-b border-gray-700">
        <nav className="flex space-x-6 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`
                flex flex-col items-center space-y-1 py-4 px-3 border-b-2 font-medium text-sm min-w-max
                ${activeTab === tab.id
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
                }
              `}
            >
              <div className="flex items-center space-x-2">
                {tab.icon}
                <span>{tab.label}</span>
              </div>
              {tab.description && (
                <span className="text-xs opacity-75">{tab.description}</span>
              )}
            </button>
          ))}
        </nav>
      </div>
    </Card>
  );
};