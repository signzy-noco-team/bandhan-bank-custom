import React, { useState } from 'react';
import { Play, CheckCircle } from 'lucide-react';
import { Button } from '../../ui/Button';
import { Input } from '../../ui/Input';
import { Select } from '../../ui/Select';
import { MonacoEditor } from '../MonacoEditor';

interface ApiTestSectionProps {
  onTest: () => Promise<void>;
  testResponse: string;
}

export const ApiTestSection: React.FC<ApiTestSectionProps> = ({
  onTest,
  testResponse,
}) => {
  const [testData, setTestData] = useState('{\n  "example": "test data",\n  "timestamp": "2024-01-15T10:00:00Z"\n}');

  return (
    <div className="space-y-8">
      {/* Test Environment Selection */}
      <div>
        <h3 className="text-lg font-medium text-white mb-4">Test Environment</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Test Environment"
            placeholder="development"
            defaultValue="development"
          />
          <Select
            label="Log Level"
            options={[
              { value: 'debug', label: 'Debug' },
              { value: 'info', label: 'Info' },
              { value: 'warn', label: 'Warning' },
              { value: 'error', label: 'Error' },
            ]}
            defaultValue="debug"
          />
        </div>
      </div>

      {/* Test Request Configuration */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-md font-medium text-white">Test Request Body</h4>
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setTestData('{\n  "userId": "123",\n  "amount": 100,\n  "currency": "USD"\n}')}
            >
              Load Example
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setTestData('{}')}
            >
              Clear
            </Button>
          </div>
        </div>
        <MonacoEditor
          value={testData}
          onChange={setTestData}
          language="json"
          height="200px"
        />
      </div>

      {/* Test Button */}
      <div className="flex justify-center">
        <Button onClick={onTest} size="lg" className="px-8">
          <Play className="w-5 h-5 mr-2" />
          Run API Test
        </Button>
      </div>

      {testResponse && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-md font-medium text-white">Test Response</h4>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <span className="text-green-400 text-sm">Test Successful</span>
            </div>
          </div>
          <MonacoEditor
            value={testResponse}
            onChange={() => {}}
            language="json"
            height="400px"
            readOnly
          />
        </div>
      )}
    </div>
  );
};