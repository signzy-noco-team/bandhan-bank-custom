import React from 'react';
import { Copy, ExternalLink, Activity, FileText, CheckCircle, Clock, BarChart3 } from 'lucide-react';
import { Card } from '../../ui/Card';
import { Button } from '../../ui/Button';
import { ApiEndpoint } from '../../../types';

interface ApiHeaderProps {
  api: ApiEndpoint;
  apiStats: {
    totalCalls: number;
    successRate: number;
    avgResponseTime: number;
    lastCall: string;
  };
  onCopyPath: (path: string) => void;
  onNavigateToExecutions: () => void;
  onNavigateToLogs: () => void;
  onOpenDocs: () => void;
}

export const ApiHeader: React.FC<ApiHeaderProps> = ({
  api,
  apiStats,
  onCopyPath,
  onNavigateToExecutions,
  onNavigateToLogs,
  onOpenDocs,
}) => {
  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'bg-green-600 text-green-100';
      case 'POST': return 'bg-blue-600 text-blue-100';
      case 'PUT': return 'bg-yellow-600 text-yellow-100';
      case 'DELETE': return 'bg-red-600 text-red-100';
      case 'PATCH': return 'bg-purple-600 text-purple-100';
      default: return 'bg-gray-600 text-gray-100';
    }
  };

  return (
    <Card>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <span className={`px-3 py-1 text-sm font-semibold rounded-lg ${getMethodColor(api.method)}`}>
              {api.method}
            </span>
            <div className="flex items-center space-x-2">
              <code className="text-sm text-gray-300 bg-gray-900 px-3 py-1 rounded-lg font-mono">
                {api.path}
              </code>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onCopyPath(api.path)}
                title="Copy path"
              >
                <Copy className="w-3 h-3" />
              </Button>
            </div>
            <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs ${
              api.status === 'active' 
                ? 'bg-green-900 text-green-300 border border-green-700' 
                : 'bg-gray-900 text-gray-400 border border-gray-700'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                api.status === 'active' ? 'bg-green-400' : 'bg-gray-500'
              }`} />
              <span>{api.status}</span>
            </div>
          </div>
          <p className="text-gray-400 mb-4">{api.description}</p>
          
          {/* API Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gray-900 p-3 rounded-lg">
              <div className="flex items-center space-x-2 mb-1">
                <BarChart3 className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-gray-400">Total Calls</span>
              </div>
              <div className="text-lg font-semibold text-white">{apiStats.totalCalls.toLocaleString()}</div>
            </div>
            <div className="bg-gray-900 p-3 rounded-lg">
              <div className="flex items-center space-x-2 mb-1">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-xs text-gray-400">Success Rate</span>
              </div>
              <div className="text-lg font-semibold text-green-400">{apiStats.successRate}%</div>
            </div>
            <div className="bg-gray-900 p-3 rounded-lg">
              <div className="flex items-center space-x-2 mb-1">
                <Clock className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-gray-400">Avg Response</span>
              </div>
              <div className="text-lg font-semibold text-purple-400">{apiStats.avgResponseTime}ms</div>
            </div>
            <div className="bg-gray-900 p-3 rounded-lg">
              <div className="flex items-center space-x-2 mb-1">
                <Activity className="w-4 h-4 text-orange-400" />
                <span className="text-xs text-gray-400">Last Call</span>
              </div>
              <div className="text-sm font-medium text-orange-400">
                {new Date(apiStats.lastCall).toLocaleTimeString()}
              </div>
            </div>
          </div>
        </div>
        
        {/* Quick Actions */}
        <div className="flex flex-col space-y-2 ml-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={onNavigateToExecutions}
            className="justify-start"
          >
            <Activity className="w-4 h-4 mr-2" />
            View Executions
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onNavigateToLogs}
            className="justify-start"
          >
            <FileText className="w-4 h-4 mr-2" />
            View Logs
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onOpenDocs}
            className="justify-start"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            API Docs
          </Button>
        </div>
      </div>
    </Card>
  );
};