import React from 'react';
import { motion } from 'framer-motion';
import { ApiFlowDiagram } from '../ApiFlowDiagram';
import { ApiSettings } from '../ApiSettings';
import { UpstreamApiConfig } from '../UpstreamApiConfig';
import { RuleConfig } from '../RuleConfig';
import { TransformationConfig } from '../TransformationConfig';
import { StorageConfig } from '../StorageConfig';
import { QueueConfig } from '../QueueConfig';
import { ApiTestSection } from './ApiTestSection';
import { ApiEndpoint } from '../../../types';

interface ApiTabContentProps {
  activeTab: string;
  api: ApiEndpoint;
  apiVariables: any[];
  apiHeaders: any[];
  requestBody: string;
  testResponse: string;
  onApiChange: (api: ApiEndpoint) => void;
  onVariablesChange: (variables: any[]) => void;
  onHeadersChange: (headers: any[]) => void;
  onRequestBodyChange: (body: string) => void;
  onTest: () => Promise<void>;
  onMarkUnsaved: () => void;
}

export const ApiTabContent: React.FC<ApiTabContentProps> = ({
  activeTab,
  api,
  apiVariables,
  apiHeaders,
  requestBody,
  testResponse,
  onApiChange,
  onVariablesChange,
  onHeadersChange,
  onRequestBodyChange,
  onTest,
  onMarkUnsaved,
}) => {
  return (
    <motion.div
      key={activeTab}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
    >
      {activeTab === 'flow' && (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-white mb-4">API Flow Diagram</h3>
            <p className="text-gray-400 text-sm mb-6">
              Visual representation of your API orchestration flow
            </p>
          </div>
          <ApiFlowDiagram
            upstreamApis={api.configuration.upstreamApis}
            rules={api.configuration.rules}
          />
        </div>
      )}

      {activeTab === 'settings' && (
        <ApiSettings
          variables={apiVariables}
          headers={apiHeaders}
          requestBody={requestBody}
          onVariablesChange={onVariablesChange}
          onHeadersChange={onHeadersChange}
          onRequestBodyChange={onRequestBodyChange}
        />
      )}

      {activeTab === 'upstream' && (
        <UpstreamApiConfig
          apis={api.configuration.upstreamApis}
          onChange={(apis) => {
            onMarkUnsaved();
            onApiChange({
              ...api,
              configuration: { ...api.configuration, upstreamApis: apis }
            });
          }}
        />
      )}

      {activeTab === 'rules' && (
        <RuleConfig
          rules={api.configuration.rules}
          onChange={(rules) => {
            onMarkUnsaved();
            onApiChange({
              ...api,
              configuration: { ...api.configuration, rules }
            });
          }}
        />
      )}

      {activeTab === 'transformations' && (
        <TransformationConfig
          transformations={api.configuration.transformations}
          onChange={(transformations) => {
            onMarkUnsaved();
            onApiChange({
              ...api,
              configuration: { ...api.configuration, transformations }
            });
          }}
        />
      )}

      {activeTab === 'storage' && (
        <StorageConfig
          config={api.configuration.storage}
          onChange={(storage) => {
            onMarkUnsaved();
            onApiChange({
              ...api,
              configuration: { ...api.configuration, storage }
            });
          }}
        />
      )}

      {activeTab === 'queue' && (
        <QueueConfig
          config={api.configuration.queueConfig}
          onChange={(queueConfig) => {
            onMarkUnsaved();
            onApiChange({
              ...api,
              configuration: { ...api.configuration, queueConfig }
            });
          }}
        />
      )}

      {activeTab === 'test' && (
        <ApiTestSection
          onTest={onTest}
          testResponse={testResponse}
        />
      )}
    </motion.div>
  );
};