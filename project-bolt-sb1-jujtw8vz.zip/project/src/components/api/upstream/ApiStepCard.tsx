import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronRight, Edit, Trash2 } from 'lucide-react';
import { Card } from '../../ui/Card';
import { Button } from '../../ui/Button';
import { Select } from '../../ui/Select';
import { UpstreamApi } from '../../../types';
import { AvailableApiEndpoint } from './types';
import { methodColors, getApiEndpointById } from './utils';

interface ApiStepCardProps {
  upstreamCall: UpstreamApi;
  level: number;
  isExpanded: boolean;
  hasNextSteps: boolean;
  availableApiEndpoints: AvailableApiEndpoint[];
  usedApiIds: string[];
  onToggleExpanded: (stepId: string) => void;
  onEdit: (api: UpstreamApi) => void;
  onDelete: (id: string) => void;
  onAddNextStep: (apiId: string, nextApiId: string) => void;
}

export const ApiStepCard: React.FC<ApiStepCardProps> = ({
  upstreamCall,
  level,
  isExpanded,
  hasNextSteps,
  availableApiEndpoints,
  usedApiIds,
  onToggleExpanded,
  onEdit,
  onDelete,
  onAddNextStep,
}) => {
  const marginLeft = level * 40;
  const apiEndpoint = getApiEndpointById(availableApiEndpoints, upstreamCall.apiEndpointId);
  
  if (!apiEndpoint) return null;

  return (
    <div style={{ marginLeft: `${marginLeft}px` }}>
      <Card className="relative group mb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              {hasNextSteps && (
                <button
                  onClick={() => onToggleExpanded(upstreamCall.id)}
                  className="text-gray-400 hover:text-white"
                >
                  {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </button>
              )}
              <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${methodColors[apiEndpoint.method]}`}>
                {apiEndpoint.method}
              </span>
              <h4 className="text-white font-medium">{apiEndpoint.name}</h4>
              <span className="text-xs text-blue-400 bg-blue-900 px-2 py-1 rounded">EXTERNAL</span>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <span className="text-gray-400">URL:</span>
                <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs">
                  {apiEndpoint.url}
                </code>
              </div>
              
              {upstreamCall.condition && (
                <div className="flex items-center space-x-2">
                  <span className="text-gray-400">Condition:</span>
                  <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs">
                    {upstreamCall.condition.length > 50 ? `${upstreamCall.condition.substring(0, 50)}...` : upstreamCall.condition}
                  </code>
                </div>
              )}
              
              <div className="flex items-center space-x-4 text-gray-500">
                <span>Timeout: {upstreamCall.customTimeout || 5000}ms</span>
                <span>Retries: {upstreamCall.customRetries || 3}</span>
                {hasNextSteps && <span>Next Steps: {upstreamCall.nextSteps.length}</span>}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(upstreamCall)}
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(upstreamCall.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Add Next Step Section */}
        <div className="mt-4 pt-4 border-t border-gray-700">
          <div className="flex items-center space-x-2">
            <Select
              options={[
                { value: '', label: 'Select next API to call...' },
                ...availableApiEndpoints
                  .filter(availableEndpoint => !usedApiIds.includes(availableEndpoint.id))
                  .map(availableEndpoint => ({
                    value: availableEndpoint.id,
                    label: `${availableEndpoint.name} (${availableEndpoint.method})`
                  }))
              ]}
              value=""
              onChange={(e) => {
                if (e.target.value) {
                  onAddNextStep(upstreamCall.id, e.target.value);
                }
              }}
            />
            <span className="text-gray-400 text-sm">or end the flow</span>
          </div>
        </div>
      </Card>
    </div>
  );
};