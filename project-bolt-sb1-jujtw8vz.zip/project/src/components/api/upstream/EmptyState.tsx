import React from 'react';
import { Globe } from 'lucide-react';
import { Card } from '../../ui/Card';

export const EmptyState: React.FC = () => {
  return (
    <Card className="text-center py-12">
      <Globe className="w-12 h-12 text-gray-500 mx-auto mb-4" />
      <p className="text-gray-400 mb-4">No API flow configured</p>
      <p className="text-gray-500 text-sm">Select an API from the dropdown above to start building your flow</p>
    </Card>
  );
};