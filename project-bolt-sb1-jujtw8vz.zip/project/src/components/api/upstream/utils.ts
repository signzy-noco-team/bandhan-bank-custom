import { UpstreamApi } from '../../../types';
import { AvailableApiEndpoint } from './types';

export const methodColors = {
  GET: 'bg-green-600',
  POST: 'bg-blue-600',
  PUT: 'bg-yellow-600',
  DELETE: 'bg-red-600',
  PATCH: 'bg-purple-600',
};

export const getApiById = (apis: UpstreamApi[], id: string): UpstreamApi | undefined => {
  return apis.find(api => api.id === id);
};

export const getApiEndpointById = (availableApis: AvailableApiEndpoint[], id: string): AvailableApiEndpoint | undefined => {
  return availableApis.find(api => api.id === id);
};

export const getRootApis = (apis: UpstreamApi[]): UpstreamApi[] => {
  return apis.filter(api => 
    !apis.some(otherCall => otherCall.nextSteps.includes(api.id))
  );
};

export const generateUniqueId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};