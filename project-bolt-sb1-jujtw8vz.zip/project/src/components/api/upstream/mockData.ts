import { AvailableApiEndpoint } from './types';

export const availableApiEndpoints: AvailableApiEndpoint[] = [
  {
    id: 'user-service-api-1',
    name: 'User Service API',
    path: '/api/users/:id',
    method: 'GET',
    url: 'https://user-service.example.com/api/users/{id}',
    description: 'Retrieve user information and profile data'
  },
  {
    id: 'payment-gateway-api-1',
    name: 'Payment Gateway API',
    path: '/api/charge',
    method: 'POST',
    url: 'https://payments.example.com/api/charge',
    description: 'Process payments and handle transactions'
  },
  {
    id: 'notification-service-api-1',
    name: 'Notification Service API',
    path: '/api/send',
    method: 'POST',
    url: 'https://notifications.example.com/api/send',
    description: 'Send emails, SMS, and push notifications'
  },
  {
    id: 'inventory-service-api-1',
    name: 'Inventory Service API',
    path: '/api/products/:id',
    method: 'GET',
    url: 'https://inventory.example.com/api/products/{id}',
    description: 'Check product availability and stock levels'
  },
  {
    id: 'order-service-api-1',
    name: 'Order Service API',
    path: '/api/orders',
    method: 'POST',
    url: 'https://orders.example.com/api/orders',
    description: 'Create and manage customer orders'
  },
  {
    id: 'analytics-service-api-1',
    name: 'Analytics Service API',
    path: '/api/track',
    method: 'POST',
    url: 'https://analytics.example.com/api/track',
    description: 'Track user events and analytics data'
  }
];