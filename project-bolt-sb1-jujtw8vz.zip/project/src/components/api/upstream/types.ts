export interface AvailableApiEndpoint {
  id: string;
  name: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  url: string;
  description: string;
}

export interface UpstreamApiFormData {
  apiEndpointId: string;
  condition: string;
  customHeaders: Record<string, string>;
  customBody: string;
  customTimeout: number;
  customRetries: number;
}