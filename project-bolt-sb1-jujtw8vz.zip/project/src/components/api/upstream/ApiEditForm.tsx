import React, { useState } from 'react';
import { Button } from '../../ui/Button';
import { Input } from '../../ui/Input';
import { MonacoEditor } from '../MonacoEditor';
import { UpstreamApi } from '../../../types';
import { AvailableApiEndpoint, UpstreamApiFormData } from './types';
import { getApiEndpointById } from './utils';

interface ApiEditFormProps {
  api: UpstreamApi;
  onSave: (api: UpstreamApi) => void;
  onCancel: () => void;
  availableApis: AvailableApiEndpoint[];
}

export const ApiEditForm: React.FC<ApiEditFormProps> = ({ 
  api, 
  onSave, 
  onCancel, 
  availableApis 
}) => {
  const [formData, setFormData] = useState<UpstreamApiFormData>({
    apiEndpointId: api.apiEndpointId,
    condition: api.condition || '',
    customHeaders: api.customHeaders || {},
    customBody: api.customBody || '',
    customTimeout: api.customTimeout || 5000,
    customRetries: api.customRetries || 3,
  });

  const selectedApiEndpoint = getApiEndpointById(availableApis, formData.apiEndpointId);

  const handleSave = () => {
    const updatedApi: UpstreamApi = {
      ...api,
      ...formData,
    };
    onSave(updatedApi);
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-900 p-4 rounded-lg border border-blue-700">
        <h4 className="text-sm font-medium text-blue-300 mb-2">API Configuration</h4>
        <p className="text-sm text-blue-200">
          Configure the external API call settings and response conditions.
        </p>
      </div>

      {selectedApiEndpoint && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="API Name"
            value={selectedApiEndpoint.name}
            disabled
          />
          <Input
            label="HTTP Method"
            value={selectedApiEndpoint.method}
            disabled
          />
        </div>
      )}

      {selectedApiEndpoint && (
        <Input
          label="API URL"
          value={selectedApiEndpoint.url}
          disabled
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Custom Timeout (ms)"
          type="number"
          value={formData.customTimeout}
          onChange={(e) => setFormData({ 
            ...formData, 
            customTimeout: parseInt(e.target.value) || 5000 
          })}
        />
        <Input
          label="Custom Retry Count"
          type="number"
          value={formData.customRetries}
          onChange={(e) => setFormData({ 
            ...formData, 
            customRetries: parseInt(e.target.value) || 3 
          })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Custom Request Headers (JSON)
        </label>
        <MonacoEditor
          value={JSON.stringify(formData.customHeaders, null, 2)}
          onChange={(value) => {
            try {
              setFormData({ ...formData, customHeaders: JSON.parse(value) });
            } catch (e) {
              // Invalid JSON, keep previous value
            }
          }}
          language="json"
          height="150px"
        />
      </div>

      {selectedApiEndpoint && (selectedApiEndpoint.method === 'POST' || selectedApiEndpoint.method === 'PUT' || selectedApiEndpoint.method === 'PATCH') && (
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Custom Request Body (JSON)
          </label>
          <MonacoEditor
            value={formData.customBody}
            onChange={(value) => setFormData({ ...formData, customBody: value })}
            language="json"
            height="150px"
          />
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Response Condition (JavaScript)
        </label>
        <p className="text-sm text-gray-400 mb-2">
          Define when to proceed to next steps based on this API's response
        </p>
        <MonacoEditor
          value={formData.condition}
          onChange={(value) => setFormData({ ...formData, condition: value })}
          language="javascript"
          height="150px"
        />
      </div>

      <div className="bg-gray-900 p-4 rounded-lg">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Response Condition Examples:</h4>
        <div className="space-y-1 text-xs text-gray-400">
          <div><code>response.status === 200</code> - Check HTTP status</div>
          <div><code>response.data.success === true</code> - Check response data</div>
          <div><code>response.data.user.role === "premium"</code> - Check user role</div>
          <div><code>response.data.balance 100</code> - Check numeric values</div>
        </div>
      </div>

      <div className="flex justify-end space-x-4">
        <Button variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSave}>
          Save Configuration
        </Button>
      </div>
    </div>
  );
};