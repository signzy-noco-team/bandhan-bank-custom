import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '../ui/Card';
import { Select } from '../ui/Select';
import { Modal } from '../ui/Modal';
import { UpstreamApi } from '../../types';
import { availableApiEndpoints } from './upstream/mockData';
import { ApiEditForm } from './upstream/ApiEditForm';
import { ApiStepCard } from './upstream/ApiStepCard';
import { EmptyState } from './upstream/EmptyState';
import { 
  getApiById, 
  getApiEndpointById, 
  getRootApis, 
  generateUniqueId 
} from './upstream/utils';

interface UpstreamApiConfigProps {
  apis: UpstreamApi[];
  onChange: (apis: UpstreamApi[]) => void;
}

export const UpstreamApiConfig: React.FC<UpstreamApiConfigProps> = ({
  apis,
  onChange,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [editingApi, setEditingApi] = useState<UpstreamApi | null>(null);
  const [selectedApiId, setSelectedApiId] = useState<string>('');
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());

  const handleAddApi = () => {
    if (!selectedApiId) return;
    
    const selectedApiEndpoint = getApiEndpointById(availableApiEndpoints, selectedApiId);
    if (!selectedApiEndpoint) return;

    const newUpstreamCall: UpstreamApi = {
      id: generateUniqueId(),
      apiEndpointId: selectedApiEndpoint.id,
      order: apis.length + 1,
      condition: '',
      nextSteps: [],
    };

    onChange([...apis, newUpstreamCall]);
    setSelectedApiId('');
  };

  const handleEditApi = (api: UpstreamApi) => {
    setEditingApi(api);
    setShowModal(true);
  };

  const handleSaveApi = (updatedApi: UpstreamApi) => {
    onChange(apis.map(api => api.id === editingApi?.id ? updatedApi : api));
    setShowModal(false);
    setEditingApi(null);
  };

  const handleDeleteApi = (id: string) => {
    // Remove the API and any references to it in nextSteps
    const updatedApis = apis
      .filter(api => api.id !== id)
      .map(api => ({
        ...api,
        nextSteps: api.nextSteps.filter(stepId => stepId !== id)
      }));
    onChange(updatedApis);
  };

  const handleAddNextStep = (apiId: string, nextApiId: string) => {
    const selectedApiEndpoint = getApiEndpointById(availableApiEndpoints, nextApiId);
    if (!selectedApiEndpoint) return;

    const newUpstreamCall: UpstreamApi = {
      id: generateUniqueId(),
      apiEndpointId: selectedApiEndpoint.id,
      order: apis.length + 1,
      condition: '',
      nextSteps: [],
    };

    // Update the parent API to include this new step
    const updatedApis = apis.map(api => {
      if (api.id === apiId) {
        return { ...api, nextSteps: [...api.nextSteps, newUpstreamCall.id] };
      }
      return api;
    });

    // Add the new upstream call to the main list
    onChange([...updatedApis, newUpstreamCall]);
  };

  const toggleExpanded = (stepId: string) => {
    const newExpanded = new Set(expandedSteps);
    if (newExpanded.has(stepId)) {
      newExpanded.delete(stepId);
    } else {
      newExpanded.add(stepId);
    }
    setExpandedSteps(newExpanded);
  };

  const renderApiStep = (upstreamCall: UpstreamApi, level: number = 0): React.ReactNode => {
    const isExpanded = expandedSteps.has(upstreamCall.id);
    const hasNextSteps = upstreamCall.nextSteps && upstreamCall.nextSteps.length > 0;
    const usedApiIds = apis.map(api => api.apiEndpointId);

    return (
      <div key={upstreamCall.id}>
        <ApiStepCard
          upstreamCall={upstreamCall}
          level={level}
          isExpanded={isExpanded}
          hasNextSteps={hasNextSteps}
          availableApiEndpoints={availableApiEndpoints}
          usedApiIds={usedApiIds}
          onToggleExpanded={toggleExpanded}
          onEdit={handleEditApi}
          onDelete={handleDeleteApi}
          onAddNextStep={handleAddNextStep}
        />

        {/* Render Next Steps */}
        {isExpanded && hasNextSteps && (
          <AnimatePresence>
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="ml-6"
            >
              {upstreamCall.nextSteps.map(nextStepId => {
                const nextApi = getApiById(apis, nextStepId);
                return nextApi ? renderApiStep(nextApi, level + 1) : null;
              })}
            </motion.div>
          </AnimatePresence>
        )}
      </div>
    );
  };

  // Get root level APIs (those not referenced as next steps)
  const rootApis = getRootApis(apis);
  const usedApiIds = apis.map(api => api.apiEndpointId);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-white">Upstream API Flow</h3>
          <p className="text-gray-400 text-sm">Select external APIs and configure conditional logic for orchestration</p>
        </div>
      </div>

      {/* Add First API */}
      <Card>
        <div className="flex items-center space-x-4">
          <Select
            options={[
              { value: '', label: 'Select an API to start the flow...' },
              ...availableApiEndpoints
                .filter(availableApi => !usedApiIds.includes(availableApi.id))
                .map(availableApi => ({
                  value: availableApi.id,
                  label: `${availableApi.name} (${availableApi.method}) - ${availableApi.description}`
                }))
            ]}
            value={selectedApiId}
            onChange={(e) => setSelectedApiId(e.target.value)}
          />
          <button
            onClick={handleAddApi}
            disabled={!selectedApiId}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-700 transition-colors"
          >
            Add API
          </button>
        </div>
      </Card>

      {/* API Flow Visualization */}
      {rootApis.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="space-y-4">
          <h4 className="text-md font-medium text-white">API Execution Flow</h4>
          {rootApis.map(api => renderApiStep(api))}
        </div>
      )}

      {/* Edit API Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Configure API Settings"
        size="xl"
      >
        {editingApi && (
          <ApiEditForm
            api={editingApi}
            onSave={handleSaveApi}
            onCancel={() => setShowModal(false)}
            availableApis={availableApiEndpoints}
          />
        )}
      </Modal>
    </div>
  );
};