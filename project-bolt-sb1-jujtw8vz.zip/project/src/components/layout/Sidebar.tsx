import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Home, 
  FolderOpen, 
  Settings, 
  Activity, 
  Database,
  GitBranch,
  Layers,
  Zap,
  BarChart3
} from 'lucide-react';

interface SidebarItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  path: string;
  active?: boolean;
}

interface SidebarProps {
  // Remove props as we'll use router navigation
}

export const Sidebar: React.FC<SidebarProps> = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems: SidebarItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <Home className="w-5 h-5" />, path: '/' },
    { id: 'projects', label: 'Projects', icon: <FolderOpen className="w-5 h-5" />, path: '/projects' },
    { id: 'api-stats', label: 'API Statistics', icon: <BarChart3 className="w-5 h-5" />, path: '/api-stats' },
    { id: 'queue-manager', label: 'Queue Manager', icon: <Zap className="w-5 h-5" />, path: '/queue-manager' },
    { id: 'monitoring', label: 'Monitoring', icon: <Activity className="w-5 h-5" />, path: '/monitoring' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <motion.aside
      initial={{ x: -250 }}
      animate={{ x: 0 }}
      className="w-64 bg-gray-900 border-r border-gray-700 min-h-screen"
    >
      <div className="p-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-white">API Orchestrator</span>
        </div>
      </div>

      <nav className="mt-8">
        <div className="space-y-1 px-3">
          {menuItems.map((item) => (
            <motion.button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`
                w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg
                transition-colors duration-200
                ${isActive(item.path)
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                }
              `}
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="mr-3">{item.icon}</span>
              {item.label}
            </motion.button>
          ))}
        </div>
      </nav>
    </motion.aside>
  );
};