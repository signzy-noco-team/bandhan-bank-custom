import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';

interface RadioOption {
  value: string;
  label: string;
  description?: string;
  disabled?: boolean;
}

interface RadioProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  options: RadioOption[];
  orientation?: 'vertical' | 'horizontal';
}

export const Radio = forwardRef<HTMLInputElement, RadioProps>(({
  options,
  orientation = 'vertical',
  name,
  value,
  onChange,
  className = '',
  ...props
}, ref) => {
  return (
    <div className={`space-${orientation === 'vertical' ? 'y' : 'x'}-4 ${orientation === 'horizontal' ? 'flex flex-wrap' : ''}`}>
      {options.map((option, index) => (
        <div key={option.value} className="flex items-start">
          <div className="flex items-center h-5">
            <div className="relative">
              <input
                ref={index === 0 ? ref : undefined}
                type="radio"
                name={name}
                value={option.value}
                checked={value === option.value}
                disabled={option.disabled}
                onChange={onChange}
                className="sr-only"
                {...props}
              />
              <motion.div
                className={`
                  w-5 h-5 border-2 rounded-full cursor-pointer flex items-center justify-center
                  ${value === option.value 
                    ? 'bg-blue-600 border-blue-600' 
                    : 'bg-gray-800 border-gray-600 hover:border-gray-500'
                  }
                  ${option.disabled ? 'opacity-50 cursor-not-allowed' : ''}
                  ${className}
                `}
                whileHover={!option.disabled ? { scale: 1.05 } : {}}
                whileTap={!option.disabled ? { scale: 0.95 } : {}}
                onClick={() => {
                  if (!option.disabled && onChange) {
                    onChange({
                      target: { value: option.value, name }
                    } as React.ChangeEvent<HTMLInputElement>);
                  }
                }}
              >
                {value === option.value && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-2 h-2 bg-white rounded-full"
                  />
                )}
              </motion.div>
            </div>
          </div>
          <div className="ml-3">
            <label className="text-sm font-medium text-gray-300 cursor-pointer">
              {option.label}
            </label>
            {option.description && (
              <p className="text-sm text-gray-400">{option.description}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
});