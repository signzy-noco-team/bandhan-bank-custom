import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Edit, Settings, Globe, Key, Database } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { Checkbox } from '../ui/Checkbox';
import { Modal } from '../ui/Modal';
import { MonacoEditor } from '../api/MonacoEditor';

interface GlobalVariable {
  id: string;
  name: string;
  value: string;
  type: 'string' | 'number' | 'boolean' | 'json';
  description?: string;
  encrypted?: boolean;
}

interface DatabaseConnection {
  id: string;
  name: string;
  type: 'mongodb' | 'postgresql' | 'mysql' | 'redis';
  connectionString: string;
  database: string;
  encrypted: boolean;
}

interface ProjectConfig {
  globalVariables: GlobalVariable[];
  databaseConnections: DatabaseConnection[];
  defaultTimeout: number;
  defaultRetries: number;
  enableLogging: boolean;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  rateLimiting: {
    enabled: boolean;
    requestsPerMinute: number;
  };
  authentication: {
    enabled: boolean;
    type: 'apikey' | 'jwt' | 'oauth';
    config: Record<string, any>;
  };
}

interface ProjectConfigFormProps {
  config: ProjectConfig;
  onChange: (config: ProjectConfig) => void;
}

export const ProjectConfigForm: React.FC<ProjectConfigFormProps> = ({
  config,
  onChange,
}) => {
  const [activeTab, setActiveTab] = useState('variables');
  const [showVariableModal, setShowVariableModal] = useState(false);
  const [showDbModal, setShowDbModal] = useState(false);
  const [editingVariable, setEditingVariable] = useState<GlobalVariable | null>(null);
  const [editingDb, setEditingDb] = useState<DatabaseConnection | null>(null);
  const [variableData, setVariableData] = useState<Partial<GlobalVariable>>({});
  const [dbData, setDbData] = useState<Partial<DatabaseConnection>>({});

  const tabs = [
    { id: 'variables', label: 'Global Variables', icon: <Key className="w-4 h-4" /> },
    { id: 'databases', label: 'Database Connections', icon: <Database className="w-4 h-4" /> },
    { id: 'defaults', label: 'Default Settings', icon: <Settings className="w-4 h-4" /> },
    { id: 'security', label: 'Security & Auth', icon: <Globe className="w-4 h-4" /> },
  ];

  const handleAddVariable = () => {
    setEditingVariable(null);
    setVariableData({ type: 'string', encrypted: false });
    setShowVariableModal(true);
  };

  const handleEditVariable = (variable: GlobalVariable) => {
    setEditingVariable(variable);
    setVariableData(variable);
    setShowVariableModal(true);
  };

  const handleSaveVariable = () => {
    if (!variableData.name || !variableData.value) return;

    const newVariable: GlobalVariable = {
      id: editingVariable?.id || Math.random().toString(36).substr(2, 9),
      name: variableData.name!,
      value: variableData.value!,
      type: variableData.type || 'string',
      description: variableData.description,
      encrypted: variableData.encrypted || false,
    };

    const updatedVariables = editingVariable
      ? config.globalVariables.map(v => v.id === editingVariable.id ? newVariable : v)
      : [...config.globalVariables, newVariable];

    onChange({ ...config, globalVariables: updatedVariables });
    setShowVariableModal(false);
  };

  const handleDeleteVariable = (id: string) => {
    onChange({
      ...config,
      globalVariables: config.globalVariables.filter(v => v.id !== id)
    });
  };

  const handleAddDatabase = () => {
    setEditingDb(null);
    setDbData({ type: 'mongodb', encrypted: true });
    setShowDbModal(true);
  };

  const handleEditDatabase = (db: DatabaseConnection) => {
    setEditingDb(db);
    setDbData(db);
    setShowDbModal(true);
  };

  const handleSaveDatabase = () => {
    if (!dbData.name || !dbData.connectionString) return;

    const newDb: DatabaseConnection = {
      id: editingDb?.id || Math.random().toString(36).substr(2, 9),
      name: dbData.name!,
      type: dbData.type || 'mongodb',
      connectionString: dbData.connectionString!,
      database: dbData.database || '',
      encrypted: dbData.encrypted || true,
    };

    const updatedDbs = editingDb
      ? config.databaseConnections.map(db => db.id === editingDb.id ? newDb : db)
      : [...config.databaseConnections, newDb];

    onChange({ ...config, databaseConnections: updatedDbs });
    setShowDbModal(false);
  };

  const handleDeleteDatabase = (id: string) => {
    onChange({
      ...config,
      databaseConnections: config.databaseConnections.filter(db => db.id !== id)
    });
  };

  const variableTypeColors = {
    string: 'bg-blue-600',
    number: 'bg-green-600',
    boolean: 'bg-purple-600',
    json: 'bg-orange-600',
  };

  const dbTypeColors = {
    mongodb: 'bg-green-600',
    postgresql: 'bg-blue-600',
    mysql: 'bg-orange-600',
    redis: 'bg-red-600',
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <Card padding="sm">
        <div className="border-b border-gray-700">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm
                  ${activeTab === tab.id
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
                  }
                `}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'variables' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium text-white">Global Variables</h3>
                    <p className="text-gray-400 text-sm">Define variables accessible across all APIs in this project</p>
                  </div>
                  <Button onClick={handleAddVariable} icon={<Plus className="w-4 h-4" />}>
                    Add Variable
                  </Button>
                </div>

                {config.globalVariables.length === 0 ? (
                  <Card className="text-center py-12">
                    <Key className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No global variables defined</p>
                    <Button onClick={handleAddVariable}>Add Your First Variable</Button>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {config.globalVariables.map((variable) => (
                      <Card key={variable.id} padding="sm">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${variableTypeColors[variable.type]}`}>
                                {variable.type.toUpperCase()}
                              </span>
                              <h4 className="text-white font-medium">{variable.name}</h4>
                              {variable.encrypted && (
                                <span className="px-2 py-1 text-xs bg-yellow-600 text-white rounded">
                                  ENCRYPTED
                                </span>
                              )}
                            </div>
                            <div className="flex items-center space-x-4 text-sm">
                              <span className="text-gray-400">Value:</span>
                              <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs">
                                {variable.encrypted ? '••••••••' : variable.value}
                              </code>
                            </div>
                            {variable.description && (
                              <p className="text-gray-400 text-sm mt-1">{variable.description}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => handleEditVariable(variable)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteVariable(variable.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'databases' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium text-white">Database Connections</h3>
                    <p className="text-gray-400 text-sm">Configure database connections for storage operations</p>
                  </div>
                  <Button onClick={handleAddDatabase} icon={<Plus className="w-4 h-4" />}>
                    Add Connection
                  </Button>
                </div>

                {config.databaseConnections.length === 0 ? (
                  <Card className="text-center py-12">
                    <Database className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No database connections configured</p>
                    <Button onClick={handleAddDatabase}>Add Your First Connection</Button>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {config.databaseConnections.map((db) => (
                      <Card key={db.id} padding="sm">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <span className={`px-2 py-1 text-xs font-semibold text-white rounded ${dbTypeColors[db.type]}`}>
                                {db.type.toUpperCase()}
                              </span>
                              <h4 className="text-white font-medium">{db.name}</h4>
                              {db.encrypted && (
                                <span className="px-2 py-1 text-xs bg-green-600 text-white rounded">
                                  ENCRYPTED
                                </span>
                              )}
                            </div>
                            <div className="space-y-1 text-sm">
                              <div className="flex items-center space-x-2">
                                <span className="text-gray-400">Connection:</span>
                                <code className="text-gray-300 bg-gray-900 px-2 py-1 rounded text-xs">
                                  {db.encrypted ? '••••••••' : db.connectionString}
                                </code>
                              </div>
                              {db.database && (
                                <div className="flex items-center space-x-2">
                                  <span className="text-gray-400">Database:</span>
                                  <span className="text-gray-300">{db.database}</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => handleEditDatabase(db)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteDatabase(db.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'defaults' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-white">Default Settings</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Default Timeout (ms)"
                    type="number"
                    value={config.defaultTimeout}
                    onChange={(e) => onChange({ ...config, defaultTimeout: parseInt(e.target.value) || 5000 })}
                  />
                  <Input
                    label="Default Retries"
                    type="number"
                    value={config.defaultRetries}
                    onChange={(e) => onChange({ ...config, defaultRetries: parseInt(e.target.value) || 3 })}
                  />
                </div>

                <div className="space-y-4">
                  <Checkbox
                    label="Enable Logging"
                    description="Enable detailed logging for all API calls"
                    checked={config.enableLogging}
                    onChange={(e) => onChange({ ...config, enableLogging: e.target.checked })}
                  />

                  {config.enableLogging && (
                    <Select
                      label="Log Level"
                      options={[
                        { value: 'debug', label: 'Debug - All messages' },
                        { value: 'info', label: 'Info - General information' },
                        { value: 'warn', label: 'Warning - Important notices' },
                        { value: 'error', label: 'Error - Only errors' },
                      ]}
                      value={config.logLevel}
                      onChange={(e) => onChange({ ...config, logLevel: e.target.value as any })}
                    />
                  )}
                </div>

                <Card>
                  <h4 className="text-md font-medium text-white mb-4">Rate Limiting</h4>
                  <div className="space-y-4">
                    <Checkbox
                      label="Enable Rate Limiting"
                      description="Limit the number of requests per minute"
                      checked={config.rateLimiting.enabled}
                      onChange={(e) => onChange({
                        ...config,
                        rateLimiting: { ...config.rateLimiting, enabled: e.target.checked }
                      })}
                    />
                    {config.rateLimiting.enabled && (
                      <Input
                        label="Requests per Minute"
                        type="number"
                        value={config.rateLimiting.requestsPerMinute}
                        onChange={(e) => onChange({
                          ...config,
                          rateLimiting: { ...config.rateLimiting, requestsPerMinute: parseInt(e.target.value) || 60 }
                        })}
                      />
                    )}
                  </div>
                </Card>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-white">Security & Authentication</h3>
                
                <Card>
                  <div className="space-y-4">
                    <Checkbox
                      label="Enable Authentication"
                      description="Require authentication for API access"
                      checked={config.authentication.enabled}
                      onChange={(e) => onChange({
                        ...config,
                        authentication: { ...config.authentication, enabled: e.target.checked }
                      })}
                    />

                    {config.authentication.enabled && (
                      <>
                        <Select
                          label="Authentication Type"
                          options={[
                            { value: 'apikey', label: 'API Key' },
                            { value: 'jwt', label: 'JWT Token' },
                            { value: 'oauth', label: 'OAuth 2.0' },
                          ]}
                          value={config.authentication.type}
                          onChange={(e) => onChange({
                            ...config,
                            authentication: { ...config.authentication, type: e.target.value as any }
                          })}
                        />

                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Authentication Configuration
                          </label>
                          <MonacoEditor
                            value={JSON.stringify(config.authentication.config, null, 2)}
                            onChange={(value) => {
                              try {
                                onChange({
                                  ...config,
                                  authentication: { ...config.authentication, config: JSON.parse(value) }
                                });
                              } catch (e) {
                                // Invalid JSON, keep previous value
                              }
                            }}
                            language="json"
                            height="200px"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </Card>
              </div>
            )}
          </motion.div>
        </div>
      </Card>

      {/* Variable Modal */}
      <Modal
        isOpen={showVariableModal}
        onClose={() => setShowVariableModal(false)}
        title={editingVariable ? 'Edit Variable' : 'Add Variable'}
        size="lg"
      >
        <div className="space-y-4">
          <Input
            label="Variable Name"
            placeholder="API_BASE_URL"
            value={variableData.name || ''}
            onChange={(e) => setVariableData({ ...variableData, name: e.target.value })}
          />

          <Select
            label="Variable Type"
            options={[
              { value: 'string', label: 'String' },
              { value: 'number', label: 'Number' },
              { value: 'boolean', label: 'Boolean' },
              { value: 'json', label: 'JSON Object' },
            ]}
            value={variableData.type || 'string'}
            onChange={(e) => setVariableData({ ...variableData, type: e.target.value as any })}
          />

          {variableData.type === 'json' ? (
            <MonacoEditor
              label="Variable Value"
              value={variableData.value || '{}'}
              onChange={(value) => setVariableData({ ...variableData, value })}
              language="json"
              height="150px"
            />
          ) : (
            <Input
              label="Variable Value"
              placeholder="https://api.example.com"
              value={variableData.value || ''}
              onChange={(e) => setVariableData({ ...variableData, value: e.target.value })}
            />
          )}

          <Textarea
            label="Description (Optional)"
            placeholder="Base URL for external API calls"
            value={variableData.description || ''}
            onChange={(e) => setVariableData({ ...variableData, description: e.target.value })}
          />

          <Checkbox
            label="Encrypt Value"
            description="Store this value encrypted for security"
            checked={variableData.encrypted || false}
            onChange={(e) => setVariableData({ ...variableData, encrypted: e.target.checked })}
          />

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowVariableModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveVariable}>
              {editingVariable ? 'Update Variable' : 'Add Variable'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Database Modal */}
      <Modal
        isOpen={showDbModal}
        onClose={() => setShowDbModal(false)}
        title={editingDb ? 'Edit Database Connection' : 'Add Database Connection'}
        size="lg"
      >
        <div className="space-y-4">
          <Input
            label="Connection Name"
            placeholder="Main Database"
            value={dbData.name || ''}
            onChange={(e) => setDbData({ ...dbData, name: e.target.value })}
          />

          <Select
            label="Database Type"
            options={[
              { value: 'mongodb', label: 'MongoDB' },
              { value: 'postgresql', label: 'PostgreSQL' },
              { value: 'mysql', label: 'MySQL' },
              { value: 'redis', label: 'Redis' },
            ]}
            value={dbData.type || 'mongodb'}
            onChange={(e) => setDbData({ ...dbData, type: e.target.value as any })}
          />

          <Textarea
            label="Connection String"
            placeholder="mongodb://localhost:27017"
            value={dbData.connectionString || ''}
            onChange={(e) => setDbData({ ...dbData, connectionString: e.target.value })}
          />

          <Input
            label="Database Name (Optional)"
            placeholder="myapp"
            value={dbData.database || ''}
            onChange={(e) => setDbData({ ...dbData, database: e.target.value })}
          />

          <Checkbox
            label="Encrypt Connection String"
            description="Store connection string encrypted"
            checked={dbData.encrypted || true}
            onChange={(e) => setDbData({ ...dbData, encrypted: e.target.checked })}
          />

          <div className="flex justify-end space-x-4">
            <Button variant="ghost" onClick={() => setShowDbModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveDatabase}>
              {editingDb ? 'Update Connection' : 'Add Connection'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};