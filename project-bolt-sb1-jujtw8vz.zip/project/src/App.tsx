import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Dashboard } from './pages/Dashboard';
import { Projects } from './pages/Projects';
import { ProjectDetail } from './pages/ProjectDetail';
import { ApiDetail } from './pages/ApiDetail';
import { ApiExecution } from './pages/ApiExecution';
import { ApiLogs } from './pages/ApiLogs';
import { ApiStats } from './pages/ApiStats';
import { QueueManager } from './pages/QueueManager';
import { Monitoring } from './pages/Monitoring';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-900">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/projects/:projectId" element={<ProjectDetail />} />
          <Route path="/projects/:projectId/apis/:apiId" element={<ApiDetail />} />
          <Route path="/projects/:projectId/apis/:apiId/executions" element={<ApiExecution />} />
          <Route path="/projects/:projectId/apis/:apiId/logs" element={<ApiLogs />} />
          <Route path="/api-stats" element={<ApiStats />} />
          <Route path="/queue-manager" element={<QueueManager />} />
          <Route path="/monitoring" element={<Monitoring />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;