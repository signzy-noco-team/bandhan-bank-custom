export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  status: 'active' | 'inactive';
  apiCount: number;
}

export interface ApiEndpoint {
  id: string;
  projectId: string;
  name: string;
  slug: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  description: string;
  configuration: ApiConfiguration;
  createdAt: string;
  updatedAt: string;
  status: 'active' | 'inactive';
}

export interface ApiConfiguration {
  upstreamApis: UpstreamApi[];
  rules: Rule[];
  transformations: Transformation[];
  storage: StorageConfig;
  queueConfig?: QueueConfig;
}

export interface UpstreamApi {
  id: string;
  apiEndpointId: string;
  condition?: string;
  nextSteps: string[];
  order: number;
  customHeaders?: Record<string, string>;
  customBody?: string;
  customTimeout?: number;
  customRetries?: number;
}

export interface Rule {
  id: string;
  name: string;
  condition: string;
  action: 'continue' | 'stop' | 'redirect' | 'transform';
  parameters: Record<string, any>;
}

export interface Transformation {
  id: string;
  name: string;
  type: 'xml-to-json' | 'text-to-json' | 'json-to-xml' | 'custom';
  configuration: Record<string, any>;
}

export interface StorageConfig {
  enabled: boolean;
  database: string;
  collection: string;
  fields: StorageField[];
  condition?: string;
}

export interface StorageField {
  id: string;
  sourceField: string;
  targetField: string;
  transform?: string;
}

export interface QueueConfig {
  enabled: boolean;
  queueName: string;
  priority: number;
  delay?: number;
}

export interface ToastProps {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  duration?: number;
}