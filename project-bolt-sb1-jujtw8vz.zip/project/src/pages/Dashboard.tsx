import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FolderOpen, Activity, Globe, TrendingUp } from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { projectService, apiService } from '../services/api';
import { Project } from '../types';

const StatCard: React.FC<{
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
  color: string;
}> = ({ title, value, icon, trend, color }) => (
  <Card className="relative overflow-hidden">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-400">{title}</p>
        <p className="text-2xl font-bold text-white mt-1">{value}</p>
        {trend && (
          <p className="text-sm text-green-400 mt-1 flex items-center">
            <TrendingUp className="w-3 h-3 mr-1" />
            {trend}
          </p>
        )}
      </div>
      <div className={`w-12 h-12 rounded-lg ${color} flex items-center justify-center`}>
        {icon}
      </div>
    </div>
  </Card>
);

export const Dashboard: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const loadData = async () => {
      try {
        const projectsData = await projectService.getAll();
        setProjects(projectsData);
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const activeProjects = projects.filter(p => p.status === 'active').length;
  const totalApis = projects.reduce((sum, p) => sum + p.apiCount, 0);

  return (
    <Layout title="Dashboard">
      <div className="space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total Projects"
            value={projects.length.toString()}
            icon={<FolderOpen className="w-6 h-6 text-white" />}
            trend="+12% from last month"
            color="bg-blue-600"
          />
          <StatCard
            title="Active Projects"
            value={activeProjects.toString()}
            icon={<Activity className="w-6 h-6 text-white" />}
            trend="+8% from last month"
            color="bg-green-600"
          />
          <StatCard
            title="Total APIs"
            value={totalApis.toString()}
            icon={<Globe className="w-6 h-6 text-white" />}
            trend="+24% from last month"
            color="bg-purple-600"
          />
          <StatCard
            title="API Calls Today"
            value="2,543"
            icon={<TrendingUp className="w-6 h-6 text-white" />}
            trend="+15% from yesterday"
            color="bg-orange-600"
          />
        </div>

        {/* Recent Projects */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Recent Projects</h2>
            <Button variant="ghost" size="sm" onClick={() => navigate('/projects')}>
              View All
            </Button>
          </div>
          
          {loading ? (
            <div className="text-gray-400 text-center py-8">Loading projects...</div>
          ) : (
            <div className="space-y-4">
              {projects.slice(0, 5).map((project) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-3 h-3 rounded-full ${
                      project.status === 'active' ? 'bg-green-500' : 'bg-gray-500'
                    }`} />
                    <div>
                      <h3 className="text-white font-medium">{project.name}</h3>
                      <p className="text-gray-400 text-sm">{project.apiCount} APIs</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-400 text-sm">
                      {new Date(project.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </Card>

        {/* Quick Actions */}
        <Card>
          <h2 className="text-xl font-semibold text-white mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Button variant="primary" className="justify-start p-4 h-auto" onClick={() => navigate('/projects')}>
              <FolderOpen className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">Create New Project</div>
                <div className="text-sm opacity-75">Start a new API orchestration project</div>
              </div>
            </Button>
            <Button variant="secondary" className="justify-start p-4 h-auto" onClick={() => navigate('/api-stats')}>
              <Globe className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">View API Statistics</div>
                <div className="text-sm opacity-75">Monitor API performance and usage</div>
              </div>
            </Button>
            <Button variant="ghost" className="justify-start p-4 h-auto" onClick={() => navigate('/monitoring')}>
              <Activity className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">View Monitoring</div>
                <div className="text-sm opacity-75">Check API performance metrics</div>
              </div>
            </Button>
          </div>
        </Card>
      </div>
    </Layout>
  );
};