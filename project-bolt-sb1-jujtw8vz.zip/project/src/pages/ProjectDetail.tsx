import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Plus, 
  Search, 
  Settings, 
  Activity,
  Globe,
  Calendar,
  Cog
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card } from '../components/ui/Card';
import { Modal } from '../components/ui/Modal';
import { ApiCard } from '../components/api/ApiCard';
import { ApiForm } from '../components/api/ApiForm';
import { ProjectConfigForm } from '../components/project/ProjectConfigForm';
import { projectService, apiService } from '../services/api';
import { Project, ApiEndpoint } from '../types';
import { ApiEndpointFormData } from '../utils/validation';
import { useToast } from '../hooks/useToast';

export const ProjectDetail: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const { success, error } = useToast();
  
  const [project, setProject] = useState<Project | null>(null);
  const [apis, setApis] = useState<ApiEndpoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingApi, setEditingApi] = useState<ApiEndpoint | null>(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [projectConfig, setProjectConfig] = useState({
    globalVariables: [],
    databaseConnections: [],
    defaultTimeout: 5000,
    defaultRetries: 3,
    enableLogging: true,
    logLevel: 'info' as const,
    rateLimiting: {
      enabled: false,
      requestsPerMinute: 60,
    },
    authentication: {
      enabled: false,
      type: 'apikey' as const,
      config: {},
    },
  });

  useEffect(() => {
    if (projectId) {
      loadProjectData();
    }
  }, [projectId]);

  const loadProjectData = async () => {
    try {
      setLoading(true);
      const [projectData, apisData] = await Promise.all([
        projectService.getById(projectId!),
        apiService.getByProjectId(projectId!)
      ]);
      
      if (!projectData) {
        error('Project not found');
        navigate('/projects');
        return;
      }
      
      setProject(projectData);
      setApis(apisData);
    } catch (err) {
      error('Failed to load project data');
      navigate('/projects');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateApi = async (data: ApiEndpointFormData) => {
    try {
      setSubmitting(true);
      const newApi = await apiService.create({
        ...data,
        projectId: projectId!,
        configuration: {
          upstreamApis: [],
          rules: [],
          transformations: [],
          storage: {
            enabled: false,
            database: '',
            collection: '',
            fields: [],
          },
        },
      });
      setApis([newApi, ...apis]);
      setShowCreateModal(false);
      success('API created successfully');
    } catch (err) {
      error('Failed to create API');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditApi = async (data: ApiEndpointFormData) => {
    if (!editingApi) return;
    
    try {
      setSubmitting(true);
      const updatedApi = await apiService.update(editingApi.id, data);
      setApis(apis.map(api => api.id === editingApi.id ? updatedApi : api));
      setEditingApi(null);
      success('API updated successfully');
    } catch (err) {
      error('Failed to update API');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteApi = async (api: ApiEndpoint) => {
    if (!confirm(`Are you sure you want to delete "${api.name}"?`)) return;
    
    try {
      await apiService.delete(api.id);
      setApis(apis.filter(a => a.id !== api.id));
      success('API deleted successfully');
    } catch (err) {
      error('Failed to delete API');
    }
  };

  const handleViewApi = (api: ApiEndpoint) => {
    navigate(`/projects/${projectId}/apis/${api.id}`);
  };

  const filteredApis = apis.filter(api =>
    api.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    api.path.toLowerCase().includes(searchTerm.toLowerCase()) ||
    api.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <Layout title="Loading...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      </Layout>
    );
  }

  if (!project) {
    return (
      <Layout title="Project Not Found">
        <div className="text-center py-12">
          <p className="text-gray-400 mb-4">Project not found</p>
          <Button onClick={() => navigate('/projects')}>
            Back to Projects
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout
      title={project.name}
      actions={
        <div className="flex space-x-2">
          <Button variant="ghost" onClick={() => navigate('/projects')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Projects
          </Button>
          <Button variant="secondary" onClick={() => setShowConfigModal(true)}>
            <Cog className="w-4 h-4 mr-2" />
            Project Config
          </Button>
          <Button
            icon={<Plus className="w-4 h-4" />}
            onClick={() => setShowCreateModal(true)}
          >
            Add API
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* Project Info */}
        <Card>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <p className="text-gray-400 mb-4">{project.description}</p>
              <div className="flex items-center space-x-6 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <Globe className="w-4 h-4" />
                  <span>{apis.length} APIs</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Activity className="w-4 h-4" />
                  <span className={project.status === 'active' ? 'text-green-400' : 'text-gray-400'}>
                    {project.status}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>Created {new Date(project.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </Card>

        {/* Search */}
        <div className="max-w-md">
          <Input
            placeholder="Search APIs..."
            icon={<Search className="w-4 h-4" />}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* APIs Grid */}
        {filteredApis.length === 0 ? (
          <Card className="text-center py-12">
            <Globe className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">
              {searchTerm ? 'No APIs found matching your search' : 'No APIs created yet'}
            </p>
            <Button onClick={() => setShowCreateModal(true)}>
              Create Your First API
            </Button>
          </Card>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredApis.map((api) => (
              <ApiCard
                key={api.id}
                api={api}
                onEdit={setEditingApi}
                onDelete={handleDeleteApi}
                onView={handleViewApi}
              />
            ))}
          </motion.div>
        )}
      </div>

      {/* Create API Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New API"
        size="lg"
      >
        <ApiForm
          onSubmit={handleCreateApi}
          onCancel={() => setShowCreateModal(false)}
          loading={submitting}
        />
      </Modal>

      {/* Edit API Modal */}
      <Modal
        isOpen={!!editingApi}
        onClose={() => setEditingApi(null)}
        title="Edit API"
        size="lg"
      >
        {editingApi && (
          <ApiForm
            api={editingApi}
            onSubmit={handleEditApi}
            onCancel={() => setEditingApi(null)}
            loading={submitting}
          />
        )}
      </Modal>

      {/* Project Config Modal */}
      <Modal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        title="Project Configuration"
        size="xl"
      >
        <ProjectConfigForm
          config={projectConfig}
          onChange={setProjectConfig}
        />
      </Modal>
    </Layout>
  );
};