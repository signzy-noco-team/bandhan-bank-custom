import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Play, 
  Clock, 
  CheckCircle, 
  XCircle,
  AlertTriangle,
  RefreshCw,
  Eye,
  Download,
  Filter
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Table } from '../components/ui/Table';
import { Modal } from '../components/ui/Modal';
import { MonacoEditor } from '../components/api/MonacoEditor';

interface ApiExecution {
  id: string;
  executionId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'timeout';
  success: boolean;
  startedAt: string;
  completedAt?: string;
  totalExecutionTime: number;
  upstreamCallsCount: number;
  rulesExecutedCount: number;
  transformationsCount: number;
  requestData: any;
  responseData: any;
  error?: string;
}

export const ApiExecution: React.FC = () => {
  const { projectId, apiId } = useParams<{ projectId: string; apiId: string }>();
  const navigate = useNavigate();
  
  const [executions, setExecutions] = useState<ApiExecution[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedExecution, setSelectedExecution] = useState<ApiExecution | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadExecutions();
  }, [apiId, statusFilter]);

  const loadExecutions = async () => {
    try {
      setLoading(true);
      // Mock data - replace with actual API call
      const mockExecutions: ApiExecution[] = [
        {
          id: '1',
          executionId: 'exec-2024-001',
          status: 'completed',
          success: true,
          startedAt: '2024-01-15T10:30:00Z',
          completedAt: '2024-01-15T10:30:02Z',
          totalExecutionTime: 2150,
          upstreamCallsCount: 3,
          rulesExecutedCount: 2,
          transformationsCount: 1,
          requestData: { userId: '123', amount: 100 },
          responseData: { orderId: 'order-456', status: 'success' }
        },
        {
          id: '2',
          executionId: 'exec-2024-002',
          status: 'failed',
          success: false,
          startedAt: '2024-01-15T10:25:00Z',
          completedAt: '2024-01-15T10:25:05Z',
          totalExecutionTime: 5000,
          upstreamCallsCount: 2,
          rulesExecutedCount: 1,
          transformationsCount: 0,
          requestData: { userId: '456', amount: 200 },
          responseData: null,
          error: 'Upstream API timeout after 5000ms'
        },
        {
          id: '3',
          executionId: 'exec-2024-003',
          status: 'processing',
          success: false,
          startedAt: '2024-01-15T10:32:00Z',
          totalExecutionTime: 0,
          upstreamCallsCount: 1,
          rulesExecutedCount: 0,
          transformationsCount: 0,
          requestData: { userId: '789', amount: 150 },
          responseData: null
        }
      ];
      setExecutions(mockExecutions);
    } catch (error) {
      console.error('Failed to load executions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (execution: ApiExecution) => {
    setSelectedExecution(execution);
    setShowDetailsModal(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'processing': return <RefreshCw className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'timeout': return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'processing': return 'text-blue-400';
      case 'completed': return 'text-green-400';
      case 'failed': return 'text-red-400';
      case 'timeout': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  };

  const filteredExecutions = executions.filter(execution => {
    const matchesStatus = statusFilter === 'all' || execution.status === statusFilter;
    const matchesSearch = execution.executionId.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const columns = [
    {
      key: 'executionId',
      header: 'Execution ID',
      render: (value: string) => (
        <code className="text-xs bg-gray-900 px-2 py-1 rounded">{value}</code>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (value: string) => (
        <div className="flex items-center space-x-2">
          {getStatusIcon(value)}
          <span className={getStatusColor(value)}>{value}</span>
        </div>
      ),
    },
    {
      key: 'totalExecutionTime',
      header: 'Duration',
      render: (value: number) => (
        <span className="text-gray-300">{value}ms</span>
      ),
    },
    {
      key: 'upstreamCallsCount',
      header: 'Upstream Calls',
      render: (value: number) => (
        <span className="text-gray-300">{value}</span>
      ),
    },
    {
      key: 'startedAt',
      header: 'Started At',
      render: (value: string) => (
        <span className="text-gray-400 text-sm">
          {new Date(value).toLocaleString()}
        </span>
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (_: any, row: ApiExecution) => (
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleViewDetails(row)}
          >
            <Eye className="w-3 h-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {/* Download execution data */}}
          >
            <Download className="w-3 h-3" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <Layout
      title="API Execution History"
      actions={
        <div className="flex space-x-2">
          <Button variant="ghost" onClick={() => navigate(`/projects/${projectId}/apis/${apiId}`)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to API
          </Button>
          <Button onClick={loadExecutions}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* Filters */}
        <Card>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <div className="w-full md:w-64">
                <Input
                  placeholder="Search executions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select
                options={[
                  { value: 'all', label: 'All Statuses' },
                  { value: 'pending', label: 'Pending' },
                  { value: 'processing', label: 'Processing' },
                  { value: 'completed', label: 'Completed' },
                  { value: 'failed', label: 'Failed' },
                  { value: 'timeout', label: 'Timeout' },
                ]}
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              />
            </div>
          </div>
        </Card>

        {/* Executions Table */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Execution History</h2>
            <div className="text-sm text-gray-400">
              Showing {filteredExecutions.length} of {executions.length} executions
            </div>
          </div>
          
          <Table
            columns={columns}
            data={filteredExecutions}
            loading={loading}
            emptyMessage="No executions found"
            onRowClick={handleViewDetails}
          />
        </Card>
      </div>

      {/* Execution Details Modal */}
      <Modal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        title={`Execution Details: ${selectedExecution?.executionId}`}
        size="xl"
      >
        {selectedExecution && (
          <div className="space-y-6">
            {/* Status and Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card padding="sm">
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    {getStatusIcon(selectedExecution.status)}
                  </div>
                  <div className={`font-medium ${getStatusColor(selectedExecution.status)}`}>
                    {selectedExecution.status.toUpperCase()}
                  </div>
                </div>
              </Card>
              <Card padding="sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{selectedExecution.totalExecutionTime}ms</div>
                  <div className="text-sm text-gray-400">Total Duration</div>
                </div>
              </Card>
              <Card padding="sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{selectedExecution.upstreamCallsCount}</div>
                  <div className="text-sm text-gray-400">Upstream Calls</div>
                </div>
              </Card>
            </div>

            {/* Request Data */}
            <div>
              <h3 className="text-lg font-medium text-white mb-3">Request Data</h3>
              <MonacoEditor
                value={JSON.stringify(selectedExecution.requestData, null, 2)}
                onChange={() => {}}
                language="json"
                height="200px"
                readOnly
              />
            </div>

            {/* Response Data */}
            <div>
              <h3 className="text-lg font-medium text-white mb-3">Response Data</h3>
              <MonacoEditor
                value={JSON.stringify(selectedExecution.responseData || {}, null, 2)}
                onChange={() => {}}
                language="json"
                height="200px"
                readOnly
              />
            </div>

            {/* Error Details */}
            {selectedExecution.error && (
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Error Details</h3>
                <Card className="bg-red-900 border-red-700">
                  <p className="text-red-200">{selectedExecution.error}</p>
                </Card>
              </div>
            )}
          </div>
        )}
      </Modal>
    </Layout>
  );
};