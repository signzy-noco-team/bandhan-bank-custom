import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Trash2, 
  RefreshCw, 
  Clock, 
  CheckCircle, 
  XCircle,
  AlertTriangle,
  Filter,
  Search
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Table } from '../components/ui/Table';

interface QueueJob {
  id: string;
  queueName: string;
  jobType: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'retrying';
  priority: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  attempts: number;
  maxAttempts: number;
  data: any;
  error?: string;
  processingTime?: number;
}

interface QueueStats {
  queueName: string;
  pending: number;
  processing: number;
  completed: number;
  failed: number;
  totalJobs: number;
  avgProcessingTime: number;
}

export const QueueManager: React.FC = () => {
  const [jobs, setJobs] = useState<QueueJob[]>([]);
  const [stats, setStats] = useState<QueueStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [queueFilter, setQueueFilter] = useState('all');

  useEffect(() => {
    loadQueueData();
    const interval = setInterval(loadQueueData, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const loadQueueData = async () => {
    try {
      // Mock data - replace with actual API calls
      const mockJobs: QueueJob[] = [
        {
          id: '1',
          queueName: 'api-processing',
          jobType: 'API_CALL',
          status: 'processing',
          priority: 5,
          createdAt: '2024-01-15T10:00:00Z',
          startedAt: '2024-01-15T10:01:00Z',
          attempts: 1,
          maxAttempts: 3,
          data: { apiId: 'api-123', payload: { userId: 'user-456' } },
        },
        {
          id: '2',
          queueName: 'data-transformation',
          jobType: 'TRANSFORM',
          status: 'completed',
          priority: 3,
          createdAt: '2024-01-15T09:45:00Z',
          startedAt: '2024-01-15T09:46:00Z',
          completedAt: '2024-01-15T09:47:30Z',
          attempts: 1,
          maxAttempts: 3,
          data: { transformId: 'trans-789' },
          processingTime: 90000,
        },
        {
          id: '3',
          queueName: 'api-processing',
          jobType: 'API_CALL',
          status: 'failed',
          priority: 1,
          createdAt: '2024-01-15T09:30:00Z',
          startedAt: '2024-01-15T09:31:00Z',
          attempts: 3,
          maxAttempts: 3,
          data: { apiId: 'api-456' },
          error: 'Connection timeout after 5000ms',
        },
        {
          id: '4',
          queueName: 'storage-operations',
          jobType: 'STORE_DATA',
          status: 'pending',
          priority: 2,
          createdAt: '2024-01-15T10:05:00Z',
          attempts: 0,
          maxAttempts: 3,
          data: { collection: 'users', document: { id: 'user-789' } },
        },
        {
          id: '5',
          queueName: 'api-processing',
          jobType: 'API_CALL',
          status: 'retrying',
          priority: 4,
          createdAt: '2024-01-15T09:55:00Z',
          startedAt: '2024-01-15T09:56:00Z',
          attempts: 2,
          maxAttempts: 3,
          data: { apiId: 'api-789' },
          error: 'HTTP 500 - Internal Server Error',
        },
      ];

      const mockStats: QueueStats[] = [
        {
          queueName: 'api-processing',
          pending: 12,
          processing: 3,
          completed: 156,
          failed: 8,
          totalJobs: 179,
          avgProcessingTime: 2500,
        },
        {
          queueName: 'data-transformation',
          pending: 5,
          processing: 1,
          completed: 89,
          failed: 2,
          totalJobs: 97,
          avgProcessingTime: 1800,
        },
        {
          queueName: 'storage-operations',
          pending: 8,
          processing: 2,
          completed: 234,
          failed: 5,
          totalJobs: 249,
          avgProcessingTime: 800,
        },
      ];

      setJobs(mockJobs);
      setStats(mockStats);
    } catch (error) {
      console.error('Failed to load queue data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRetryJob = async (jobId: string) => {
    // Mock retry logic
    setJobs(jobs.map(job => 
      job.id === jobId 
        ? { ...job, status: 'pending' as const, attempts: 0, error: undefined }
        : job
    ));
  };

  const handleDeleteJob = async (jobId: string) => {
    if (!confirm('Are you sure you want to delete this job?')) return;
    setJobs(jobs.filter(job => job.id !== jobId));
  };

  const handlePauseQueue = async (queueName: string) => {
    console.log('Pausing queue:', queueName);
  };

  const handleResumeQueue = async (queueName: string) => {
    console.log('Resuming queue:', queueName);
  };

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.jobType.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.queueName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || job.status === statusFilter;
    const matchesQueue = queueFilter === 'all' || job.queueName === queueFilter;
    
    return matchesSearch && matchesStatus && matchesQueue;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'processing': return <RefreshCw className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'retrying': return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'processing': return 'text-blue-400';
      case 'completed': return 'text-green-400';
      case 'failed': return 'text-red-400';
      case 'retrying': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  };

  const columns = [
    {
      key: 'id',
      header: 'Job ID',
      width: '120px',
      render: (value: string) => (
        <code className="text-xs bg-gray-900 px-2 py-1 rounded">{value}</code>
      ),
    },
    {
      key: 'queueName',
      header: 'Queue',
      render: (value: string) => (
        <span className="px-2 py-1 bg-blue-600 text-white text-xs rounded">{value}</span>
      ),
    },
    {
      key: 'jobType',
      header: 'Type',
      render: (value: string) => (
        <span className="text-gray-300">{value}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (value: string) => (
        <div className="flex items-center space-x-2">
          {getStatusIcon(value)}
          <span className={getStatusColor(value)}>{value}</span>
        </div>
      ),
    },
    {
      key: 'priority',
      header: 'Priority',
      render: (value: number) => (
        <span className={`px-2 py-1 text-xs rounded ${
          value >= 8 ? 'bg-red-600 text-white' :
          value >= 5 ? 'bg-yellow-600 text-white' :
          'bg-gray-600 text-white'
        }`}>
          {value}
        </span>
      ),
    },
    {
      key: 'attempts',
      header: 'Attempts',
      render: (value: number, row: QueueJob) => (
        <span className="text-gray-300">{value}/{row.maxAttempts}</span>
      ),
    },
    {
      key: 'createdAt',
      header: 'Created',
      render: (value: string) => (
        <span className="text-gray-400 text-sm">
          {new Date(value).toLocaleTimeString()}
        </span>
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (_: any, row: QueueJob) => (
        <div className="flex items-center space-x-2">
          {row.status === 'failed' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleRetryJob(row.id)}
            >
              <RefreshCw className="w-3 h-3" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleDeleteJob(row.id)}
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <Layout title="Queue Manager">
      <div className="space-y-6">
        {/* Queue Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat) => (
            <Card key={stat.queueName}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">{stat.queueName}</h3>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm" onClick={() => handlePauseQueue(stat.queueName)}>
                    <Pause className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleResumeQueue(stat.queueName)}>
                    <Play className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">{stat.pending}</div>
                  <div className="text-sm text-gray-400">Pending</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{stat.processing}</div>
                  <div className="text-sm text-gray-400">Processing</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">{stat.completed}</div>
                  <div className="text-sm text-gray-400">Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-400">{stat.failed}</div>
                  <div className="text-sm text-gray-400">Failed</div>
                </div>
              </div>
              
              <div className="text-center text-sm text-gray-400">
                Avg: {stat.avgProcessingTime}ms
              </div>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <div className="w-full md:w-64">
                <Input
                  placeholder="Search jobs..."
                  icon={<Search className="w-4 h-4" />}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select
                options={[
                  { value: 'all', label: 'All Statuses' },
                  { value: 'pending', label: 'Pending' },
                  { value: 'processing', label: 'Processing' },
                  { value: 'completed', label: 'Completed' },
                  { value: 'failed', label: 'Failed' },
                  { value: 'retrying', label: 'Retrying' },
                ]}
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              />
              
              <Select
                options={[
                  { value: 'all', label: 'All Queues' },
                  ...stats.map(stat => ({ value: stat.queueName, label: stat.queueName }))
                ]}
                value={queueFilter}
                onChange={(e) => setQueueFilter(e.target.value)}
              />
            </div>
            
            <Button onClick={loadQueueData} icon={<RefreshCw className="w-4 h-4" />}>
              Refresh
            </Button>
          </div>
        </Card>

        {/* Jobs Table */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Queue Jobs</h2>
            <div className="text-sm text-gray-400">
              Showing {filteredJobs.length} of {jobs.length} jobs
            </div>
          </div>
          
          <Table
            columns={columns}
            data={filteredJobs}
            loading={loading}
            emptyMessage="No jobs found"
          />
        </Card>
      </div>
    </Layout>
  );
};