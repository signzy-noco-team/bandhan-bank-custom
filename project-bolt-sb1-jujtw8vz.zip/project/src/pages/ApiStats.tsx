import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  CheckCircle, 
  XCircle,
  Activity,
  Globe,
  Calendar,
  Filter,
  RefreshCw
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Select } from '../components/ui/Select';
import { Table } from '../components/ui/Table';

interface ApiStat {
  id: string;
  name: string;
  project: string;
  totalCalls: number;
  successRate: number;
  avgResponseTime: number;
  errorRate: number;
  lastCall: string;
  status: 'healthy' | 'warning' | 'error';
  trend: 'up' | 'down' | 'stable';
}

interface MetricCard {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ReactNode;
  color: string;
}

export const ApiStats: React.FC = () => {
  const [stats, setStats] = useState<ApiStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('24h');

  useEffect(() => {
    loadStats();
  }, [timeRange]);

  const loadStats = async () => {
    try {
      setLoading(true);
      // Mock data
      const mockStats: ApiStat[] = [
        {
          id: '1',
          name: 'User Authentication',
          project: 'E-commerce API',
          totalCalls: 15420,
          successRate: 99.2,
          avgResponseTime: 245,
          errorRate: 0.8,
          lastCall: '2024-01-15T10:30:00Z',
          status: 'healthy',
          trend: 'up',
        },
        {
          id: '2',
          name: 'Payment Processing',
          project: 'Payment Gateway',
          totalCalls: 8934,
          successRate: 97.8,
          avgResponseTime: 1200,
          errorRate: 2.2,
          lastCall: '2024-01-15T10:28:00Z',
          status: 'warning',
          trend: 'down',
        },
        {
          id: '3',
          name: 'Order Management',
          project: 'E-commerce API',
          totalCalls: 12567,
          successRate: 98.5,
          avgResponseTime: 380,
          errorRate: 1.5,
          lastCall: '2024-01-15T10:29:00Z',
          status: 'healthy',
          trend: 'stable',
        },
        {
          id: '4',
          name: 'Inventory Check',
          project: 'Inventory System',
          totalCalls: 23456,
          successRate: 95.2,
          avgResponseTime: 150,
          errorRate: 4.8,
          lastCall: '2024-01-15T10:25:00Z',
          status: 'error',
          trend: 'down',
        },
      ];
      setStats(mockStats);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const metrics: MetricCard[] = [
    {
      title: 'Total API Calls',
      value: '60,377',
      change: '+12.5%',
      trend: 'up',
      icon: <Globe className="w-6 h-6" />,
      color: 'bg-blue-600',
    },
    {
      title: 'Success Rate',
      value: '97.8%',
      change: '+0.3%',
      trend: 'up',
      icon: <CheckCircle className="w-6 h-6" />,
      color: 'bg-green-600',
    },
    {
      title: 'Avg Response Time',
      value: '494ms',
      change: '-15ms',
      trend: 'up',
      icon: <Clock className="w-6 h-6" />,
      color: 'bg-purple-600',
    },
    {
      title: 'Error Rate',
      value: '2.2%',
      change: '-0.5%',
      trend: 'up',
      icon: <XCircle className="w-6 h-6" />,
      color: 'bg-red-600',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'API Name',
      render: (value: string, row: ApiStat) => (
        <div>
          <div className="text-white font-medium">{value}</div>
          <div className="text-gray-400 text-sm">{row.project}</div>
        </div>
      ),
    },
    {
      key: 'totalCalls',
      header: 'Total Calls',
      render: (value: number) => (
        <span className="text-gray-300">{value.toLocaleString()}</span>
      ),
    },
    {
      key: 'successRate',
      header: 'Success Rate',
      render: (value: number) => (
        <span className={value >= 98 ? 'text-green-400' : value >= 95 ? 'text-yellow-400' : 'text-red-400'}>
          {value}%
        </span>
      ),
    },
    {
      key: 'avgResponseTime',
      header: 'Avg Response',
      render: (value: number) => (
        <span className="text-gray-300">{value}ms</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (value: string) => (
        <span className={getStatusColor(value)}>{value}</span>
      ),
    },
    {
      key: 'trend',
      header: 'Trend',
      render: (value: string) => getTrendIcon(value),
    },
    {
      key: 'lastCall',
      header: 'Last Call',
      render: (value: string) => (
        <span className="text-gray-400 text-sm">
          {new Date(value).toLocaleTimeString()}
        </span>
      ),
    },
  ];

  return (
    <Layout
      title="API Statistics"
      actions={
        <div className="flex space-x-2">
          <Select
            options={[
              { value: '1h', label: 'Last Hour' },
              { value: '24h', label: 'Last 24 Hours' },
              { value: '7d', label: 'Last 7 Days' },
              { value: '30d', label: 'Last 30 Days' },
            ]}
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
          />
          <Button onClick={loadStats} icon={<RefreshCw className="w-4 h-4" />}>
            Refresh
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                    <p className="text-2xl font-bold text-white mt-1">{metric.value}</p>
                    <div className="flex items-center mt-1">
                      {metric.trend === 'up' ? (
                        <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-400 mr-1" />
                      )}
                      <span className={`text-sm ${metric.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                        {metric.change}
                      </span>
                    </div>
                  </div>
                  <div className={`w-12 h-12 rounded-lg ${metric.color} flex items-center justify-center text-white`}>
                    {metric.icon}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* API Performance Chart Placeholder */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">API Performance Over Time</h2>
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
          <div className="h-64 bg-gray-900 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Activity className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">Performance chart will be displayed here</p>
              <p className="text-gray-500 text-sm">Integration with charting library needed</p>
            </div>
          </div>
        </Card>

        {/* API Statistics Table */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">API Performance Details</h2>
            <div className="text-sm text-gray-400">
              Showing {stats.length} APIs
            </div>
          </div>
          
          <Table
            columns={columns}
            data={stats}
            loading={loading}
            emptyMessage="No API statistics available"
          />
        </Card>
      </div>
    </Layout>
  );
};