import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Download, 
  RefreshCw,
  AlertTriangle,
  Info,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Table } from '../components/ui/Table';
import { Modal } from '../components/ui/Modal';
import { MonacoEditor } from '../components/api/MonacoEditor';

interface LogEntry {
  id: string;
  timestamp: string;
  level: 'debug' | 'info' | 'warn' | 'error';
  message: string;
  executionId?: string;
  upstreamApi?: string;
  responseTime?: number;
  statusCode?: number;
  details?: any;
}

export const ApiLogs: React.FC = () => {
  const { projectId, apiId } = useParams<{ projectId: string; apiId: string }>();
  const navigate = useNavigate();
  
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [levelFilter, setLevelFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [timeRange, setTimeRange] = useState('1h');

  useEffect(() => {
    loadLogs();
  }, [apiId, levelFilter, timeRange]);

  const loadLogs = async () => {
    try {
      setLoading(true);
      // Mock data - replace with actual API call
      const mockLogs: LogEntry[] = [
        {
          id: '1',
          timestamp: '2024-01-15T10:30:15.123Z',
          level: 'info',
          message: 'API execution started',
          executionId: 'exec-2024-001',
          details: { requestId: 'req-123', userId: '456' }
        },
        {
          id: '2',
          timestamp: '2024-01-15T10:30:15.456Z',
          level: 'debug',
          message: 'Calling upstream API: User Service',
          executionId: 'exec-2024-001',
          upstreamApi: 'User Service API',
          details: { url: 'https://user-service.example.com/api/users/456', method: 'GET' }
        },
        {
          id: '3',
          timestamp: '2024-01-15T10:30:16.789Z',
          level: 'info',
          message: 'Upstream API call completed successfully',
          executionId: 'exec-2024-001',
          upstreamApi: 'User Service API',
          responseTime: 1333,
          statusCode: 200,
          details: { responseSize: 1024 }
        },
        {
          id: '4',
          timestamp: '2024-01-15T10:30:17.012Z',
          level: 'warn',
          message: 'Response time exceeded threshold',
          executionId: 'exec-2024-001',
          upstreamApi: 'Payment Gateway API',
          responseTime: 2500,
          statusCode: 200,
          details: { threshold: 2000, actual: 2500 }
        },
        {
          id: '5',
          timestamp: '2024-01-15T10:30:17.345Z',
          level: 'error',
          message: 'Upstream API call failed',
          executionId: 'exec-2024-002',
          upstreamApi: 'Notification Service API',
          responseTime: 5000,
          statusCode: 500,
          details: { error: 'Internal Server Error', retryAttempt: 3 }
        }
      ];
      setLogs(mockLogs);
    } catch (error) {
      console.error('Failed to load logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (log: LogEntry) => {
    setSelectedLog(log);
    setShowDetailsModal(true);
  };

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'debug': return <Info className="w-4 h-4 text-gray-500" />;
      case 'info': return <CheckCircle className="w-4 h-4 text-blue-500" />;
      case 'warn': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return null;
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'debug': return 'text-gray-400';
      case 'info': return 'text-blue-400';
      case 'warn': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesLevel = levelFilter === 'all' || log.level === levelFilter;
    const matchesSearch = log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.executionId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.upstreamApi?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  const columns = [
    {
      key: 'timestamp',
      header: 'Timestamp',
      width: '180px',
      render: (value: string) => (
        <span className="text-gray-400 text-xs font-mono">
          {new Date(value).toLocaleTimeString()}.{new Date(value).getMilliseconds().toString().padStart(3, '0')}
        </span>
      ),
    },
    {
      key: 'level',
      header: 'Level',
      width: '80px',
      render: (value: string) => (
        <div className="flex items-center space-x-2">
          {getLevelIcon(value)}
          <span className={`text-xs font-medium ${getLevelColor(value)}`}>
            {value.toUpperCase()}
          </span>
        </div>
      ),
    },
    {
      key: 'message',
      header: 'Message',
      render: (value: string, row: LogEntry) => (
        <div>
          <div className="text-white text-sm">{value}</div>
          {row.executionId && (
            <div className="text-gray-400 text-xs mt-1">
              Execution: <code className="bg-gray-900 px-1 rounded">{row.executionId}</code>
            </div>
          )}
          {row.upstreamApi && (
            <div className="text-blue-400 text-xs">
              API: {row.upstreamApi}
            </div>
          )}
        </div>
      ),
    },
    {
      key: 'responseTime',
      header: 'Response Time',
      width: '120px',
      render: (value: number | undefined) => (
        value ? (
          <span className={`text-sm ${value > 2000 ? 'text-red-400' : value > 1000 ? 'text-yellow-400' : 'text-green-400'}`}>
            {value}ms
          </span>
        ) : null
      ),
    },
    {
      key: 'statusCode',
      header: 'Status',
      width: '80px',
      render: (value: number | undefined) => (
        value ? (
          <span className={`text-xs px-2 py-1 rounded ${
            value >= 200 && value < 300 ? 'bg-green-600 text-white' :
            value >= 400 && value < 500 ? 'bg-yellow-600 text-white' :
            value >= 500 ? 'bg-red-600 text-white' : 'bg-gray-600 text-white'
          }`}>
            {value}
          </span>
        ) : null
      ),
    },
  ];

  return (
    <Layout
      title="API Logs"
      actions={
        <div className="flex space-x-2">
          <Button variant="ghost" onClick={() => navigate(`/projects/${projectId}/apis/${apiId}`)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to API
          </Button>
          <Button variant="ghost" onClick={() => {/* Export logs */}}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={loadLogs}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* Filters */}
        <Card>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <div className="w-full md:w-64">
                <Input
                  placeholder="Search logs..."
                  icon={<Search className="w-4 h-4" />}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select
                options={[
                  { value: 'all', label: 'All Levels' },
                  { value: 'debug', label: 'Debug' },
                  { value: 'info', label: 'Info' },
                  { value: 'warn', label: 'Warning' },
                  { value: 'error', label: 'Error' },
                ]}
                value={levelFilter}
                onChange={(e) => setLevelFilter(e.target.value)}
              />

              <Select
                options={[
                  { value: '1h', label: 'Last Hour' },
                  { value: '24h', label: 'Last 24 Hours' },
                  { value: '7d', label: 'Last 7 Days' },
                  { value: '30d', label: 'Last 30 Days' },
                ]}
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
              />
            </div>
          </div>
        </Card>

        {/* Logs Table */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Log Entries</h2>
            <div className="text-sm text-gray-400">
              Showing {filteredLogs.length} of {logs.length} entries
            </div>
          </div>
          
          <Table
            columns={columns}
            data={filteredLogs}
            loading={loading}
            emptyMessage="No log entries found"
            onRowClick={handleViewDetails}
          />
        </Card>
      </div>

      {/* Log Details Modal */}
      <Modal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        title="Log Entry Details"
        size="lg"
      >
        {selectedLog && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Timestamp</label>
                <p className="text-white font-mono text-sm">{new Date(selectedLog.timestamp).toLocaleString()}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Level</label>
                <div className="flex items-center space-x-2">
                  {getLevelIcon(selectedLog.level)}
                  <span className={getLevelColor(selectedLog.level)}>{selectedLog.level.toUpperCase()}</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Message</label>
              <p className="text-white">{selectedLog.message}</p>
            </div>

            {selectedLog.executionId && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Execution ID</label>
                <code className="text-blue-400 bg-gray-900 px-2 py-1 rounded">{selectedLog.executionId}</code>
              </div>
            )}

            {selectedLog.upstreamApi && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Upstream API</label>
                <p className="text-white">{selectedLog.upstreamApi}</p>
              </div>
            )}

            {selectedLog.details && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Details</label>
                <MonacoEditor
                  value={JSON.stringify(selectedLog.details, null, 2)}
                  onChange={() => {}}
                  language="json"
                  height="200px"
                  readOnly
                />
              </div>
            )}
          </div>
        )}
      </Modal>
    </Layout>
  );
};