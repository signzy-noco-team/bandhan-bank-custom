import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Save, 
  Play,
  Activity,
  FileText,
  AlertCircle
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Button } from '../components/ui/Button';
import { ApiHeader } from '../components/api/detail/ApiHeader';
import { ApiTabs } from '../components/api/detail/ApiTabs';
import { ApiTabContent } from '../components/api/detail/ApiTabContent';
import { apiService } from '../services/api';
import { ApiEndpoint } from '../types';
import { useToast } from '../hooks/useToast';

export const ApiDetail: React.FC = () => {
  const { projectId, apiId } = useParams<{ projectId: string; apiId: string }>();
  const navigate = useNavigate();
  const { success, error } = useToast();
  
  const [api, setApi] = useState<ApiEndpoint | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('upstream');
  const [testResponse, setTestResponse] = useState('');
  const [apiVariables, setApiVariables] = useState([]);
  const [apiHeaders, setApiHeaders] = useState([]);
  const [requestBody, setRequestBody] = useState('');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [apiStats] = useState({
    totalCalls: 1247,
    successRate: 98.2,
    avgResponseTime: 245,
    lastCall: '2024-01-15T10:30:00Z'
  });

  useEffect(() => {
    if (apiId) {
      loadApi();
    }
  }, [apiId]);

  const loadApi = async () => {
    try {
      setLoading(true);
      const data = await apiService.getById(apiId!);
      setApi(data);
    } catch (err) {
      error('Failed to load API details');
      navigate(`/projects/${projectId}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!api) return;
    
    try {
      setSaving(true);
      await apiService.update(api.id, api);
      setHasUnsavedChanges(false);
      success('API configuration saved successfully');
    } catch (err) {
      error('Failed to save API configuration');
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    try {
      const mockResponse = {
        status: 200,
        data: {
          message: 'API test successful',
          timestamp: new Date().toISOString(),
          executionTime: '245ms',
          upstreamCalls: 3,
          transformations: 1,
          storageOperations: 1
        }
      };
      setTestResponse(JSON.stringify(mockResponse, null, 2));
      success('API test completed successfully');
    } catch (err) {
      error('API test failed');
    }
  };

  const handleCopyPath = (path: string) => {
    navigator.clipboard.writeText(path);
    success('Copied to clipboard');
  };

  const handleNavigateToExecutions = () => {
    navigate(`/projects/${projectId}/apis/${apiId}/executions`);
  };

  const handleNavigateToLogs = () => {
    navigate(`/projects/${projectId}/apis/${apiId}/logs`);
  };

  const handleOpenDocs = () => {
    window.open(`/api/docs/${api?.id}`, '_blank');
  };

  const handleMarkUnsaved = () => {
    setHasUnsavedChanges(true);
  };

  if (loading) {
    return (
      <Layout title="Loading...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      </Layout>
    );
  }

  if (!api) {
    return (
      <Layout title="API Not Found">
        <div className="text-center py-12">
          <p className="text-gray-400 mb-4">API not found</p>
          <Button onClick={() => navigate(`/projects/${projectId}`)}>
            Back to Project
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout
      title={
        <div className="flex items-center space-x-3">
          <span>Configure API: {api.name}</span>
          {hasUnsavedChanges && (
            <span className="flex items-center space-x-1 text-yellow-400 text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>Unsaved changes</span>
            </span>
          )}
        </div>
      }
      actions={
        <div className="flex space-x-2">
          <Button variant="ghost" onClick={() => navigate(`/projects/${projectId}`)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Project
          </Button>
          <Button variant="secondary" onClick={handleTest}>
            <Play className="w-4 h-4 mr-2" />
            Test API
          </Button>
          <Button variant="ghost" onClick={handleNavigateToExecutions}>
            <Activity className="w-4 h-4 mr-2" />
            Executions
          </Button>
          <Button variant="ghost" onClick={handleNavigateToLogs}>
            <FileText className="w-4 h-4 mr-2" />
            Logs
          </Button>
          <Button 
            onClick={handleSave} 
            loading={saving}
            variant={hasUnsavedChanges ? "primary" : "secondary"}
          >
            <Save className="w-4 h-4 mr-2" />
            {hasUnsavedChanges ? 'Save Changes' : 'Saved'}
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* API Header */}
        <ApiHeader
          api={api}
          apiStats={apiStats}
          onCopyPath={handleCopyPath}
          onNavigateToExecutions={handleNavigateToExecutions}
          onNavigateToLogs={handleNavigateToLogs}
          onOpenDocs={handleOpenDocs}
        />

        {/* Configuration Tabs */}
        <ApiTabs
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />

        {/* Tab Content */}
        <div className="p-6">
          <ApiTabContent
            activeTab={activeTab}
            api={api}
            apiVariables={apiVariables}
            apiHeaders={apiHeaders}
            requestBody={requestBody}
            testResponse={testResponse}
            onApiChange={setApi}
            onVariablesChange={setApiVariables}
            onHeadersChange={setApiHeaders}
            onRequestBodyChange={setRequestBody}
            onTest={handleTest}
            onMarkUnsaved={handleMarkUnsaved}
          />
        </div>
      </div>
    </Layout>
  );
};