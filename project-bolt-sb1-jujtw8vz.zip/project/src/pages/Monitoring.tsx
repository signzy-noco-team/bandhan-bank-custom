import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Bell,
  Settings
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Select } from '../components/ui/Select';

interface SystemHealth {
  status: 'healthy' | 'warning' | 'critical';
  uptime: string;
  totalApis: number;
  activeApis: number;
  queueJobs: number;
  avgResponseTime: number;
}

interface Alert {
  id: string;
  type: 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: string;
  apiName?: string;
  resolved: boolean;
}

interface MetricCard {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ReactNode;
  color: string;
}

export const Monitoring: React.FC = () => {
  const [systemHealth, setSystemHealth] = useState<SystemHealth | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('1h');

  useEffect(() => {
    loadMonitoringData();
    const interval = setInterval(loadMonitoringData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [timeRange]);

  const loadMonitoringData = async () => {
    try {
      setLoading(true);
      
      // Mock system health data
      const mockHealth: SystemHealth = {
        status: 'healthy',
        uptime: '5d 12h 34m',
        totalApis: 24,
        activeApis: 22,
        queueJobs: 156,
        avgResponseTime: 245
      };

      // Mock alerts data
      const mockAlerts: Alert[] = [
        {
          id: '1',
          type: 'warning',
          title: 'High Response Time',
          message: 'Payment API response time exceeded 2000ms threshold',
          timestamp: '2024-01-15T10:30:00Z',
          apiName: 'Payment Gateway API',
          resolved: false
        },
        {
          id: '2',
          type: 'error',
          title: 'API Failure',
          message: 'User Service API returned 500 error for 3 consecutive requests',
          timestamp: '2024-01-15T10:25:00Z',
          apiName: 'User Service API',
          resolved: true
        },
        {
          id: '3',
          type: 'info',
          title: 'Queue Processing',
          message: 'Queue processing completed successfully for batch job #1234',
          timestamp: '2024-01-15T10:20:00Z',
          resolved: true
        }
      ];

      setSystemHealth(mockHealth);
      setAlerts(mockAlerts);
    } catch (error) {
      console.error('Failed to load monitoring data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getHealthColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getHealthIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
      case 'critical': return <AlertTriangle className="w-6 h-6 text-red-500" />;
      default: return <Activity className="w-6 h-6 text-gray-500" />;
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'info': return <CheckCircle className="w-4 h-4 text-blue-500" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  const metrics: MetricCard[] = systemHealth ? [
    {
      title: 'System Uptime',
      value: systemHealth.uptime,
      change: '+99.9%',
      trend: 'up',
      icon: <Clock className="w-6 h-6" />,
      color: 'bg-green-600',
    },
    {
      title: 'Active APIs',
      value: `${systemHealth.activeApis}/${systemHealth.totalApis}`,
      change: '+2 today',
      trend: 'up',
      icon: <Activity className="w-6 h-6" />,
      color: 'bg-blue-600',
    },
    {
      title: 'Queue Jobs',
      value: systemHealth.queueJobs.toString(),
      change: '-12 processed',
      trend: 'down',
      icon: <TrendingUp className="w-6 h-6" />,
      color: 'bg-purple-600',
    },
    {
      title: 'Avg Response Time',
      value: `${systemHealth.avgResponseTime}ms`,
      change: '-15ms',
      trend: 'up',
      icon: <TrendingDown className="w-6 h-6" />,
      color: 'bg-orange-600',
    },
  ] : [];

  const unresolvedAlerts = alerts.filter(alert => !alert.resolved);

  return (
    <Layout
      title="System Monitoring"
      actions={
        <div className="flex space-x-2">
          <Select
            options={[
              { value: '1h', label: 'Last Hour' },
              { value: '24h', label: 'Last 24 Hours' },
              { value: '7d', label: 'Last 7 Days' },
              { value: '30d', label: 'Last 30 Days' },
            ]}
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
          />
          <Button onClick={loadMonitoringData}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {/* System Health Status */}
        {systemHealth && (
          <Card>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {getHealthIcon(systemHealth.status)}
                <div>
                  <h2 className="text-xl font-semibold text-white">System Status</h2>
                  <p className={`text-sm ${getHealthColor(systemHealth.status)}`}>
                    {systemHealth.status.charAt(0).toUpperCase() + systemHealth.status.slice(1)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-400">Last Updated</p>
                <p className="text-white">{new Date().toLocaleTimeString()}</p>
              </div>
            </div>
          </Card>
        )}

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-400">{metric.title}</p>
                    <p className="text-2xl font-bold text-white mt-1">{metric.value}</p>
                    <div className="flex items-center mt-1">
                      {metric.trend === 'up' ? (
                        <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-400 mr-1" />
                      )}
                      <span className={`text-sm ${metric.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                        {metric.change}
                      </span>
                    </div>
                  </div>
                  <div className={`w-12 h-12 rounded-lg ${metric.color} flex items-center justify-center text-white`}>
                    {metric.icon}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Active Alerts */}
        <Card>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Active Alerts</h2>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">
                {unresolvedAlerts.length} unresolved
              </span>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {unresolvedAlerts.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <p className="text-gray-400">No active alerts</p>
              <p className="text-gray-500 text-sm">All systems are running normally</p>
            </div>
          ) : (
            <div className="space-y-4">
              {unresolvedAlerts.map((alert) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-start space-x-4 p-4 bg-gray-700 rounded-lg"
                >
                  <div className="flex-shrink-0 mt-1">
                    {getAlertIcon(alert.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-white font-medium">{alert.title}</h3>
                      <span className="text-xs text-gray-400">
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-gray-300 text-sm mt-1">{alert.message}</p>
                    {alert.apiName && (
                      <p className="text-blue-400 text-xs mt-2">API: {alert.apiName}</p>
                    )}
                  </div>
                  <Button variant="ghost" size="sm">
                    Resolve
                  </Button>
                </motion.div>
              ))}
            </div>
          )}
        </Card>

        {/* Recent Activity */}
        <Card>
          <h2 className="text-xl font-semibold text-white mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {alerts.slice(0, 5).map((alert) => (
              <div key={alert.id} className="flex items-center space-x-4 p-3 bg-gray-800 rounded-lg">
                <div className="flex-shrink-0">
                  {getAlertIcon(alert.type)}
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm">{alert.title}</p>
                  <p className="text-gray-400 text-xs">{alert.message}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-400">
                    {new Date(alert.timestamp).toLocaleString()}
                  </p>
                  {alert.resolved && (
                    <span className="text-xs text-green-400">Resolved</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Layout>
  );
};