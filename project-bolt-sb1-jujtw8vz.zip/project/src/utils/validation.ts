import { z } from 'zod';

export const projectSchema = z.object({
  name: z.string().min(1, 'Project name is required').max(100, 'Name too long'),
  slug: z.string()
    .min(1, 'Project slug is required')
    .max(50, 'Slug too long')
    .regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  description: z.string().max(500, 'Description too long').optional(),
  status: z.enum(['active', 'inactive']).default('active'),
});

export const apiEndpointSchema = z.object({
  name: z.string().min(1, 'API name is required').max(100, 'Name too long'),
  slug: z.string()
    .min(1, 'API slug is required')
    .max(50, 'Slug too long')
    .regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  path: z.string().min(1, 'API path is required').regex(/^\//, 'Path must start with /'),
  method: z.enum(['GET', 'POST', 'PUT', 'DELETE', 'PATCH']),
  description: z.string().max(500, 'Description too long').optional(),
  status: z.enum(['active', 'inactive']).default('active'),
});

export const upstreamApiSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  url: z.string().url('Invalid URL'),
  method: z.enum(['GET', 'POST', 'PUT', 'DELETE', 'PATCH']),
  timeout: z.number().min(1000).max(60000),
  retries: z.number().min(0).max(5),
  condition: z.string().optional(),
});

export const ruleSchema = z.object({
  name: z.string().min(1, 'Rule name is required'),
  condition: z.string().min(1, 'Condition is required'),
  action: z.enum(['continue', 'stop', 'redirect', 'transform']),
});

export const storageConfigSchema = z.object({
  enabled: z.boolean(),
  database: z.string().min(1, 'Database name is required'),
  collection: z.string().min(1, 'Collection name is required'),
  condition: z.string().optional(),
});

export type ProjectFormData = z.infer<typeof projectSchema>;
export type ApiEndpointFormData = z.infer<typeof apiEndpointSchema>;
export type UpstreamApiFormData = z.infer<typeof upstreamApiSchema>;
export type RuleFormData = z.infer<typeof ruleSchema>;
export type StorageConfigFormData = z.infer<typeof storageConfigSchema>;